/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: admin_
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` char(36) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `balance_pending` decimal(24,2) NOT NULL DEFAULT 0.00,
  `received_balance` decimal(24,2) NOT NULL DEFAULT 0.00,
  `account_payable` decimal(24,2) NOT NULL DEFAULT 0.00,
  `account_receivable` decimal(24,2) NOT NULL DEFAULT 0.00,
  `total_withdrawn` decimal(24,2) NOT NULL DEFAULT 0.00,
  `total_expense` decimal(24,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES
('13747162-e7cf-4d32-82a1-401fad29f59e','285b9aa7-a211-4887-b91e-346f0406259a',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-16 22:42:03','2024-12-16 22:42:03'),
('2386b3b1-6a3f-4fa5-a7d0-68a3dfd4f5f9','38796f59-825e-4f25-ac9f-ddfc61effa61',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-08 19:01:28','2024-12-08 19:01:28'),
('298fcfb3-d3ba-48d0-ab07-4e800dba2cf7','ee31292a-0476-4374-a840-ed7ed8bc48c5',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-03 13:38:57','2024-12-03 13:38:57'),
('37c30f5a-8a74-446c-875c-ff67b7a9488e','8bd675db-2e78-46e9-8b1c-516f0728c2e8',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-09 13:17:31','2024-12-09 13:17:31'),
('792c2dc8-b7a7-46d8-9b07-5cda3a6c3665','32412c11-ca45-47e4-905d-27e05d69c1b5',0.00,0.00,0.00,0.00,0.00,0.00,'2024-11-24 18:44:03','2024-11-24 18:44:03'),
('8204f6f6-0b0d-42f9-b8c4-c49b1664f8eb','b4e84651-b572-4a42-96c7-7d1a0cf89918',0.00,0.00,0.00,0.00,0.00,0.00,'2025-01-02 16:00:07','2025-01-02 16:00:07'),
('820bef12-9b24-41a1-af86-a6b20147189b','70d1a7c8-14f0-486f-b4d3-26e8f2fadd7d',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-18 14:08:49','2024-12-18 14:08:49'),
('82c4f82b-cb0b-4779-95c5-085d8b1ca51a','27dfaf27-c88f-4c34-82f6-6b27e3436873',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-08 20:29:04','2024-12-08 20:29:04'),
('86044626-f182-4c9f-bbf5-db179e53f203','c40a44fe-7292-4620-822f-7ee5b69b78a9',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-10 17:17:18','2024-12-10 17:17:18'),
('8a52f08f-2581-4f04-a14a-bc850b3019e8','85be7d65-be37-4565-96f8-bd74857b6cfe',0.00,0.00,0.00,0.00,0.00,0.00,'2024-11-16 10:34:17','2024-11-16 10:34:17'),
('8c757fbd-9c0c-474b-841b-b73c3cbb45e3','ba1b42a7-d2e6-4a62-84d6-2f804341664b',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-12 16:17:04','2024-12-12 16:17:04'),
('bb6661e4-e65d-40f0-8d3c-de74cafec5a1','813240f0-88a5-4d07-93ca-ad6592204768',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-26 19:05:55','2024-12-26 19:05:55'),
('cf37077d-bbec-4880-a434-29bb5a941b71','b511c056-1b6f-447c-89e0-13a49eb7adcd',0.00,0.00,0.00,0.00,0.00,0.00,'2024-12-08 01:07:38','2024-12-08 01:07:38');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `added_to_carts`
--

DROP TABLE IF EXISTS `added_to_carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `added_to_carts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) NOT NULL,
  `service_id` char(36) NOT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `added_to_carts`
--

LOCK TABLES `added_to_carts` WRITE;
/*!40000 ALTER TABLE `added_to_carts` DISABLE KEYS */;
INSERT INTO `added_to_carts` VALUES
(1,'696b1360-b8ae-11ef-9411-c10a15e80c62','f4d44b69-9b28-4c3c-8956-1c223367dd3a',1,'2024-12-12 18:31:03','2024-12-12 18:31:03',1),
(2,'43ee3110-bbd0-11ef-941b-fdb6f9dab86c','f4d44b69-9b28-4c3c-8956-1c223367dd3a',4,'2024-12-16 18:10:34','2024-12-17 14:16:12',1),
(3,'813240f0-88a5-4d07-93ca-ad6592204768','f4d44b69-9b28-4c3c-8956-1c223367dd3a',1,'2024-12-26 19:07:19','2024-12-26 19:07:19',0);
/*!40000 ALTER TABLE `added_to_carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addon_settings`
--

DROP TABLE IF EXISTS `addon_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addon_settings` (
  `id` char(36) NOT NULL,
  `key_name` varchar(191) DEFAULT NULL,
  `live_values` longtext DEFAULT NULL,
  `test_values` longtext DEFAULT NULL,
  `settings_type` varchar(255) DEFAULT NULL,
  `mode` varchar(20) NOT NULL DEFAULT 'live',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `additional_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_settings_id_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addon_settings`
--

LOCK TABLES `addon_settings` WRITE;
/*!40000 ALTER TABLE `addon_settings` DISABLE KEYS */;
INSERT INTO `addon_settings` VALUES
('070c6bbd-d777-11ed-96f4-0c7a158e4469','twilio','{\"gateway\":\"twilio\",\"mode\":\"live\",\"status\":0,\"sid\":\"data\",\"messaging_service_sid\":\"data\",\"token\":\"data\",\"from\":\"data\",\"otp_template\":\"data\"}','{\"gateway\":\"twilio\",\"mode\":\"live\",\"status\":0,\"sid\":\"data\",\"messaging_service_sid\":\"data\",\"token\":\"data\",\"from\":\"data\",\"otp_template\":\"data\"}','sms_config','live',0,NULL,'2024-11-27 04:38:20',NULL),
('070c766c-d777-11ed-96f4-0c7a158e4469','2factor','{\"gateway\":\"2factor\",\"mode\":\"live\",\"status\":0,\"api_key\":\"data\"}','{\"gateway\":\"2factor\",\"mode\":\"live\",\"status\":0,\"api_key\":\"data\"}','sms_config','live',0,NULL,'2024-11-27 04:38:20',NULL),
('0d8a9308-d6a5-11ed-962c-0c7a158e4469','mercadopago','{\"gateway\":\"mercadopago\",\"mode\":\"test\",\"status\":\"0\",\"access_token\":\"data\",\"public_key\":\"data\"}','{\"gateway\":\"mercadopago\",\"mode\":\"test\",\"status\":\"0\",\"access_token\":\"data\",\"public_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-27 11:57:11','{\"gateway_title\":null,\"gateway_image\":\"2023-04-12-64367be3b7b6a.png\"}'),
('0d8a9e49-d6a5-11ed-962c-0c7a158e4469','liqpay','{\"gateway\":\"liqpay\",\"mode\":\"test\",\"status\":\"0\",\"private_key\":\"data\",\"public_key\":\"data\"}','{\"gateway\":\"liqpay\",\"mode\":\"test\",\"status\":\"0\",\"private_key\":\"data\",\"public_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:32:31','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('101befdf-d44b-11ed-8564-0c7a158e4469','paypal','{\"gateway\":\"paypal\",\"mode\":\"test\",\"status\":\"0\",\"client_id\":\"data\",\"client_secret\":\"data\"}','{\"gateway\":\"paypal\",\"mode\":\"test\",\"status\":\"0\",\"client_id\":\"data\",\"client_secret\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 03:41:32','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('133d9647-cabb-11ed-8fec-0c7a158e4469','hyper_pay','{\"gateway\":\"hyper_pay\",\"mode\":\"test\",\"status\":\"0\",\"entity_id\":\"data\",\"access_code\":\"data\"}','{\"gateway\":\"hyper_pay\",\"mode\":\"test\",\"status\":\"0\",\"entity_id\":\"data\",\"access_code\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:32:42','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('1821029f-d776-11ed-96f4-0c7a158e4469','msg91','{\"gateway\":\"msg91\",\"mode\":\"live\",\"status\":0,\"template_id\":\"data\",\"auth_key\":\"data\"}','{\"gateway\":\"msg91\",\"mode\":\"live\",\"status\":0,\"template_id\":\"data\",\"auth_key\":\"data\"}','sms_config','live',0,NULL,'2024-11-27 04:38:20',NULL),
('18210f2b-d776-11ed-96f4-0c7a158e4469','nexmo','{\"gateway\":\"nexmo\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\",\"api_secret\":\"\",\"token\":\"\",\"from\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"nexmo\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\",\"api_secret\":\"\",\"token\":\"\",\"from\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,'2024-11-27 04:38:20',NULL),
('18fbb21f-d6ad-11ed-962c-0c7a158e4469','foloosi','{\"gateway\":\"foloosi\",\"mode\":\"test\",\"status\":\"0\",\"merchant_key\":\"data\"}','{\"gateway\":\"foloosi\",\"mode\":\"test\",\"status\":\"0\",\"merchant_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:34:33','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('2767d142-d6a1-11ed-962c-0c7a158e4469','paytm','{\"gateway\":\"paytm\",\"mode\":\"test\",\"status\":\"0\",\"merchant_key\":\"data\",\"merchant_id\":\"data\",\"merchant_website_link\":\"data\"}','{\"gateway\":\"paytm\",\"mode\":\"test\",\"status\":\"0\",\"merchant_key\":\"data\",\"merchant_id\":\"data\",\"merchant_website_link\":\"data\"}','payment_config','test',0,NULL,'2023-08-22 06:30:55','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('3201d2e6-c937-11ed-a424-0c7a158e4469','amazon_pay','{\"gateway\":\"amazon_pay\",\"mode\":\"test\",\"status\":\"0\",\"pass_phrase\":\"data\",\"access_code\":\"data\",\"merchant_identifier\":\"data\"}','{\"gateway\":\"amazon_pay\",\"mode\":\"test\",\"status\":\"0\",\"pass_phrase\":\"data\",\"access_code\":\"data\",\"merchant_identifier\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:36:07','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('4593b25c-d6a1-11ed-962c-0c7a158e4469','paytabs','{\"gateway\":\"paytabs\",\"mode\":\"test\",\"status\":\"0\",\"profile_id\":\"data\",\"server_key\":\"data\",\"base_url\":\"data\"}','{\"gateway\":\"paytabs\",\"mode\":\"test\",\"status\":\"0\",\"profile_id\":\"data\",\"server_key\":\"data\",\"base_url\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:34:51','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('4e9b8dfb-e7d1-11ed-a559-0c7a158e4469','bkash','{\"gateway\":\"bkash\",\"mode\":\"test\",\"status\":\"0\",\"app_key\":\"data\",\"app_secret\":\"data\",\"username\":\"data\",\"password\":\"data\"}','{\"gateway\":\"bkash\",\"mode\":\"test\",\"status\":\"0\",\"app_key\":\"data\",\"app_secret\":\"data\",\"username\":\"data\",\"password\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:39:42','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('544a24a4-c872-11ed-ac7a-0c7a158e4469','fatoorah','{\"gateway\":\"fatoorah\",\"mode\":\"test\",\"status\":\"0\",\"api_key\":\"data\"}','{\"gateway\":\"fatoorah\",\"mode\":\"test\",\"status\":\"0\",\"api_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:36:24','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('58c1bc8a-d6ac-11ed-962c-0c7a158e4469','ccavenue','{\"gateway\":\"ccavenue\",\"mode\":\"test\",\"status\":\"0\",\"merchant_id\":\"data\",\"working_key\":\"data\",\"access_code\":\"data\"}','{\"gateway\":\"ccavenue\",\"mode\":\"test\",\"status\":\"0\",\"merchant_id\":\"data\",\"working_key\":\"data\",\"access_code\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 03:42:38','{\"gateway_title\":null,\"gateway_image\":\"2023-04-13-643783f01d386.png\"}'),
('5e2d2ef9-d6ab-11ed-962c-0c7a158e4469','thawani','{\"gateway\":\"thawani\",\"mode\":\"test\",\"status\":\"0\",\"public_key\":\"data\",\"private_key\":\"data\"}','{\"gateway\":\"thawani\",\"mode\":\"test\",\"status\":\"0\",\"public_key\":\"data\",\"private_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:50:40','{\"gateway_title\":null,\"gateway_image\":\"2023-04-13-64378f9856f29.png\"}'),
('60cc83cc-d5b9-11ed-b56f-0c7a158e4469','sixcash','{\"gateway\":\"sixcash\",\"mode\":\"test\",\"status\":\"0\",\"public_key\":\"data\",\"secret_key\":\"data\",\"merchant_number\":\"data\",\"base_url\":\"data\"}','{\"gateway\":\"sixcash\",\"mode\":\"test\",\"status\":\"0\",\"public_key\":\"data\",\"secret_key\":\"data\",\"merchant_number\":\"data\",\"base_url\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:16:17','{\"gateway_title\":null,\"gateway_image\":\"2023-04-12-6436774e77ff9.png\"}'),
('68579846-d8e8-11ed-8249-0c7a158e4469','alphanet_sms','{\"gateway\":\"alphanet_sms\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"alphanet_sms\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,NULL,NULL),
('6857a2e8-d8e8-11ed-8249-0c7a158e4469','sms_to','{\"gateway\":\"sms_to\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\",\"sender_id\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"sms_to\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\",\"sender_id\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,NULL,NULL),
('74c30c00-d6a6-11ed-962c-0c7a158e4469','hubtel','{\"gateway\":\"hubtel\",\"mode\":\"test\",\"status\":\"0\",\"account_number\":\"data\",\"api_id\":\"data\",\"api_key\":\"data\"}','{\"gateway\":\"hubtel\",\"mode\":\"test\",\"status\":\"0\",\"account_number\":\"data\",\"api_id\":\"data\",\"api_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:37:43','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('74e46b0a-d6aa-11ed-962c-0c7a158e4469','tap','{\"gateway\":\"tap\",\"mode\":\"test\",\"status\":\"0\",\"secret_key\":\"data\"}','{\"gateway\":\"tap\",\"mode\":\"test\",\"status\":\"0\",\"secret_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:50:09','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('761ca96c-d1eb-11ed-87ca-0c7a158e4469','swish','{\"gateway\":\"swish\",\"mode\":\"test\",\"status\":\"0\",\"number\":\"data\"}','{\"gateway\":\"swish\",\"mode\":\"test\",\"status\":\"0\",\"number\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:17:02','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('7b1c3c5f-d2bd-11ed-b485-0c7a158e4469','payfast','{\"gateway\":\"payfast\",\"mode\":\"test\",\"status\":\"0\",\"merchant_id\":\"data\",\"secured_key\":\"data\"}','{\"gateway\":\"payfast\",\"mode\":\"test\",\"status\":\"0\",\"merchant_id\":\"data\",\"secured_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:18:13','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('8592417b-d1d1-11ed-a984-0c7a158e4469','esewa','{\"gateway\":\"esewa\",\"mode\":\"test\",\"status\":\"0\",\"merchantCode\":\"data\"}','{\"gateway\":\"esewa\",\"mode\":\"test\",\"status\":\"0\",\"merchantCode\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:17:38','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('9162a1dc-cdf1-11ed-affe-0c7a158e4469','viva_wallet','{\"gateway\":\"viva_wallet\",\"mode\":\"test\",\"status\":\"0\",\"client_id\": \"\",\"client_secret\": \"\"}\n','{\"gateway\":\"viva_wallet\",\"mode\":\"test\",\"status\":\"0\",\"client_id\": \"\",\"client_secret\": \"\"}','payment_config','test',0,NULL,NULL,NULL),
('998ccc62-d6a0-11ed-962c-0c7a158e4469','stripe','{\"gateway\":\"stripe\",\"mode\":\"live\",\"status\":\"1\",\"api_key\":\"data\",\"published_key\":\"data\"}','{\"gateway\":\"stripe\",\"mode\":\"live\",\"status\":\"1\",\"api_key\":\"data\",\"published_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:18:55','{\"gateway_title\":\"Stripe\",\"gateway_image\":null}'),
('a3313755-c95d-11ed-b1db-0c7a158e4469','iyzi_pay','{\"gateway\":\"iyzi_pay\",\"mode\":\"test\",\"status\":\"0\",\"api_key\":\"data\",\"secret_key\":\"data\",\"base_url\":\"data\"}','{\"gateway\":\"iyzi_pay\",\"mode\":\"test\",\"status\":\"0\",\"api_key\":\"data\",\"secret_key\":\"data\",\"base_url\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:20:02','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('a76c8993-d299-11ed-b485-0c7a158e4469','momo','{\"gateway\":\"momo\",\"mode\":\"live\",\"status\":\"0\",\"api_key\":\"data\",\"api_user\":\"data\",\"subscription_key\":\"data\"}','{\"gateway\":\"momo\",\"mode\":\"live\",\"status\":\"0\",\"api_key\":\"data\",\"api_user\":\"data\",\"subscription_key\":\"data\"}','payment_config','live',0,NULL,'2023-08-30 04:19:28','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('a8608119-cc76-11ed-9bca-0c7a158e4469','moncash','{\"gateway\":\"moncash\",\"mode\":\"test\",\"status\":\"0\",\"client_id\":\"data\",\"secret_key\":\"data\"}','{\"gateway\":\"moncash\",\"mode\":\"test\",\"status\":\"0\",\"client_id\":\"data\",\"secret_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:47:34','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('ad5af1c1-d6a2-11ed-962c-0c7a158e4469','razor_pay','{\"gateway\":\"razor_pay\",\"mode\":\"live\",\"status\":\"1\",\"api_key\":\"data\",\"api_secret\":\"data\"}','{\"gateway\":\"razor_pay\",\"mode\":\"live\",\"status\":\"1\",\"api_key\":\"data\",\"api_secret\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:47:00','{\"gateway_title\":\"Razor pay\",\"gateway_image\":null}'),
('ad5b02a0-d6a2-11ed-962c-0c7a158e4469','senang_pay','{\"gateway\":\"senang_pay\",\"mode\":\"live\",\"status\":\"0\",\"callback_url\":\"https:\\/\\/url\\/return-senang-pay\",\"secret_key\":\"data\",\"merchant_id\":\"data\"}','{\"gateway\":\"senang_pay\",\"mode\":\"live\",\"status\":\"0\",\"callback_url\":\"https:\\/\\/url\\/return-senang-pay\",\"secret_key\":\"data\",\"merchant_id\":\"data\"}','payment_config','test',0,NULL,'2023-08-27 09:58:57','{\"gateway_title\":\"Senang pay\",\"gateway_image\":null}'),
('b6c333f6-d8e9-11ed-8249-0c7a158e4469','akandit_sms','{\"gateway\":\"akandit_sms\",\"mode\":\"live\",\"status\":0,\"username\":\"\",\"password\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"akandit_sms\",\"mode\":\"live\",\"status\":0,\"username\":\"\",\"password\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,NULL,NULL),
('b6c33c87-d8e9-11ed-8249-0c7a158e4469','global_sms','{\"gateway\":\"global_sms\",\"mode\":\"live\",\"status\":0,\"user_name\":\"\",\"password\":\"\",\"from\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"global_sms\",\"mode\":\"live\",\"status\":0,\"user_name\":\"\",\"password\":\"\",\"from\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,NULL,NULL),
('b8992bd4-d6a0-11ed-962c-0c7a158e4469','paymob_accept','{\"gateway\":\"paymob_accept\",\"mode\":\"live\",\"status\":\"0\",\"api_key\":\"\",\"iframe_id\":\"\",\"integration_id\":\"\", \"hmac\": \"\"}','{\"gateway\":\"paymob_accept\",\"mode\":\"test\",\"status\":\"0\",\"api_key\":\"\",\"iframe_id\":\"\",\"integration_id\":\"\", \"hmac\": \"\"}','payment_config','test',0,NULL,NULL,NULL),
('c41c0dcd-d119-11ed-9f67-0c7a158e4469','maxicash','{\"gateway\":\"maxicash\",\"mode\":\"test\",\"status\":\"0\",\"merchantId\":\"data\",\"merchantPassword\":\"data\"}','{\"gateway\":\"maxicash\",\"mode\":\"test\",\"status\":\"0\",\"merchantId\":\"data\",\"merchantPassword\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:49:15','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('c9249d17-cd60-11ed-b879-0c7a158e4469','pvit','{\"gateway\":\"pvit\",\"mode\":\"test\",\"status\":\"0\",\"mc_tel_merchant\": \"\",\"access_token\": \"\", \"mc_merchant_code\": \"\"}','{\"gateway\":\"pvit\",\"mode\":\"test\",\"status\":\"0\",\"mc_tel_merchant\": \"\",\"access_token\": \"\", \"mc_merchant_code\": \"\"}','payment_config','test',0,NULL,NULL,NULL),
('cb0081ce-d775-11ed-96f4-0c7a158e4469','releans','{\"gateway\":\"releans\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\",\"from\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"releans\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\",\"from\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,'2023-04-10 02:14:44',NULL),
('d4f3f5f1-d6a0-11ed-962c-0c7a158e4469','flutterwave','{\"gateway\":\"flutterwave\",\"mode\":\"live\",\"status\":\"1\",\"secret_key\":\"data\",\"public_key\":\"data\",\"hash\":\"data\"}','{\"gateway\":\"flutterwave\",\"mode\":\"live\",\"status\":\"1\",\"secret_key\":\"data\",\"public_key\":\"data\",\"hash\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:41:03','{\"gateway_title\":\"Flutterwave\",\"gateway_image\":null}'),
('d822f1a5-c864-11ed-ac7a-0c7a158e4469','paystack','{\"gateway\":\"paystack\",\"mode\":\"live\",\"status\":\"1\",\"callback_url\":\"https:\\/\\/api.paystack.co\",\"public_key\":\"data\",\"secret_key\":\"data\",\"merchant_email\":\"data\"}','{\"gateway\":\"paystack\",\"mode\":\"live\",\"status\":\"1\",\"callback_url\":\"https:\\/\\/api.paystack.co\",\"public_key\":\"data\",\"secret_key\":\"data\",\"merchant_email\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 04:20:45','{\"gateway_title\":\"Paystack\",\"gateway_image\":null}'),
('daec8d59-c893-11ed-ac7a-0c7a158e4469','xendit','{\"gateway\":\"xendit\",\"mode\":\"test\",\"status\":\"0\",\"api_key\":\"data\"}','{\"gateway\":\"xendit\",\"mode\":\"test\",\"status\":\"0\",\"api_key\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:35:46','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('dc0f5fc9-d6a5-11ed-962c-0c7a158e4469','worldpay','{\"gateway\":\"worldpay\",\"mode\":\"test\",\"status\":\"0\",\"OrgUnitId\":\"data\",\"jwt_issuer\":\"data\",\"mac\":\"data\",\"merchantCode\":\"data\",\"xml_password\":\"data\"}','{\"gateway\":\"worldpay\",\"mode\":\"test\",\"status\":\"0\",\"OrgUnitId\":\"data\",\"jwt_issuer\":\"data\",\"mac\":\"data\",\"merchantCode\":\"data\",\"xml_password\":\"data\"}','payment_config','test',0,NULL,'2023-08-12 06:35:26','{\"gateway_title\":null,\"gateway_image\":\"\"}'),
('e0450278-d8eb-11ed-8249-0c7a158e4469','signal_wire','{\"gateway\":\"signal_wire\",\"mode\":\"live\",\"status\":0,\"project_id\":\"\",\"token\":\"\",\"space_url\":\"\",\"from\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"signal_wire\",\"mode\":\"live\",\"status\":0,\"project_id\":\"\",\"token\":\"\",\"space_url\":\"\",\"from\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,'2024-11-27 04:38:20',NULL),
('e0450b40-d8eb-11ed-8249-0c7a158e4469','paradox','{\"gateway\":\"paradox\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\"}','{\"gateway\":\"paradox\",\"mode\":\"live\",\"status\":0,\"api_key\":\"\"}','sms_config','live',0,NULL,NULL,NULL),
('ea346efe-cdda-11ed-affe-0c7a158e4469','ssl_commerz','{\"gateway\":\"ssl_commerz\",\"mode\":\"live\",\"status\":\"1\",\"store_id\":\"data\",\"store_password\":\"data\"}','{\"gateway\":\"ssl_commerz\",\"mode\":\"live\",\"status\":\"1\",\"store_id\":\"data\",\"store_password\":\"data\"}','payment_config','test',0,NULL,'2023-08-30 03:43:49','{\"gateway_title\":\"Ssl commerz\",\"gateway_image\":null}'),
('eed88336-d8ec-11ed-8249-0c7a158e4469','hubtel','{\"gateway\":\"hubtel\",\"mode\":\"live\",\"status\":0,\"sender_id\":\"\",\"client_id\":\"\",\"client_secret\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"hubtel\",\"mode\":\"live\",\"status\":0,\"sender_id\":\"\",\"client_id\":\"\",\"client_secret\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,NULL,NULL),
('f149c546-d8ea-11ed-8249-0c7a158e4469','viatech','{\"gateway\":\"viatech\",\"mode\":\"live\",\"status\":0,\"api_url\":\"\",\"api_key\":\"\",\"sender_id\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"viatech\",\"mode\":\"live\",\"status\":0,\"api_url\":\"\",\"api_key\":\"\",\"sender_id\":\"\",\"otp_template\":\"\"}','sms_config','live',0,NULL,NULL,NULL),
('f149cd9c-d8ea-11ed-8249-0c7a158e4469','019_sms','{\"gateway\":\"019_sms\",\"mode\":\"live\",\"status\":0,\"password\":\"\",\"username\":\"\",\"username_for_token\":\"\",\"sender\":\"\",\"otp_template\":\"\"}','{\"gateway\":\"019_sms\",\"mode\":\"live\",\"status\":0,\"password\":\"\",\"username\":\"\",\"username_for_token\":\"\",\"sender\":\"\",\"otp_template\":\"\"}','sms_config','live',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `addon_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertisement_attachments`
--

DROP TABLE IF EXISTS `advertisement_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertisement_attachments` (
  `id` char(36) NOT NULL,
  `advertisement_id` char(36) DEFAULT NULL,
  `file_extension_type` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL COMMENT 'promotional_video, provider_profile_image, provider_cover_image',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisement_attachments`
--

LOCK TABLES `advertisement_attachments` WRITE;
/*!40000 ALTER TABLE `advertisement_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertisement_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertisement_notes`
--

DROP TABLE IF EXISTS `advertisement_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertisement_notes` (
  `id` char(36) NOT NULL,
  `advertisement_id` char(36) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL COMMENT 'paused, denied',
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisement_notes`
--

LOCK TABLES `advertisement_notes` WRITE;
/*!40000 ALTER TABLE `advertisement_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertisement_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertisement_settings`
--

DROP TABLE IF EXISTS `advertisement_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertisement_settings` (
  `id` char(36) NOT NULL,
  `advertisement_id` char(36) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisement_settings`
--

LOCK TABLES `advertisement_settings` WRITE;
/*!40000 ALTER TABLE `advertisement_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertisement_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertisements`
--

DROP TABLE IF EXISTS `advertisements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertisements` (
  `id` char(36) NOT NULL,
  `readable_id` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL COMMENT 'video_promotion, profile_promotion',
  `is_paid` tinyint(4) NOT NULL DEFAULT 0,
  `start_date` datetime NOT NULL DEFAULT '2024-05-20 20:36:19',
  `end_date` datetime NOT NULL DEFAULT '2024-05-20 20:36:19',
  `status` varchar(255) NOT NULL DEFAULT 'pending' COMMENT 'pending, approved, running, expired, denied, paused, canceled',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_updated` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisements`
--

LOCK TABLES `advertisements` WRITE;
/*!40000 ALTER TABLE `advertisements` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertisements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_details`
--

DROP TABLE IF EXISTS `bank_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_details` (
  `id` char(36) NOT NULL,
  `provider_id` char(36) NOT NULL,
  `bank_name` varchar(191) DEFAULT NULL,
  `branch_name` varchar(191) DEFAULT NULL,
  `acc_no` varchar(191) DEFAULT NULL,
  `acc_holder_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `routing_number` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_details`
--

LOCK TABLES `bank_details` WRITE;
/*!40000 ALTER TABLE `bank_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` char(36) NOT NULL,
  `banner_title` varchar(191) DEFAULT NULL,
  `resource_type` varchar(191) DEFAULT NULL,
  `resource_id` char(36) DEFAULT NULL,
  `redirect_link` varchar(191) DEFAULT NULL,
  `banner_image` varchar(255) NOT NULL DEFAULT 'def.png',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bonuses`
--

DROP TABLE IF EXISTS `bonuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bonuses` (
  `id` char(36) NOT NULL,
  `bonus_title` varchar(255) NOT NULL,
  `short_description` text NOT NULL,
  `bonus_amount_type` varchar(255) NOT NULL,
  `bonus_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `minimum_add_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `maximum_bonus_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bonuses`
--

LOCK TABLES `bonuses` WRITE;
/*!40000 ALTER TABLE `bonuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `bonuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_additional_information`
--

DROP TABLE IF EXISTS `booking_additional_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_additional_information` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` char(36) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_additional_information`
--

LOCK TABLES `booking_additional_information` WRITE;
/*!40000 ALTER TABLE `booking_additional_information` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_additional_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_details`
--

DROP TABLE IF EXISTS `booking_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` char(36) DEFAULT NULL,
  `service_id` char(36) DEFAULT NULL,
  `service_name` varchar(255) DEFAULT NULL,
  `variant_key` varchar(255) DEFAULT NULL,
  `service_cost` decimal(24,3) NOT NULL DEFAULT 0.000,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `discount_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `tax_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `total_cost` decimal(24,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `campaign_discount_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `overall_coupon_discount_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_details`
--

LOCK TABLES `booking_details` WRITE;
/*!40000 ALTER TABLE `booking_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_details_amounts`
--

DROP TABLE IF EXISTS `booking_details_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_details_amounts` (
  `id` char(36) NOT NULL,
  `booking_details_id` char(36) NOT NULL,
  `booking_id` char(36) NOT NULL,
  `service_unit_cost` decimal(24,2) NOT NULL DEFAULT 0.00,
  `service_quantity` int(11) NOT NULL DEFAULT 0,
  `service_tax` decimal(24,2) NOT NULL DEFAULT 0.00,
  `discount_by_admin` decimal(24,2) NOT NULL DEFAULT 0.00,
  `discount_by_provider` decimal(24,2) NOT NULL DEFAULT 0.00,
  `coupon_discount_by_admin` decimal(24,2) NOT NULL DEFAULT 0.00,
  `coupon_discount_by_provider` decimal(24,2) NOT NULL DEFAULT 0.00,
  `campaign_discount_by_admin` decimal(24,2) NOT NULL DEFAULT 0.00,
  `campaign_discount_by_provider` decimal(24,2) NOT NULL DEFAULT 0.00,
  `admin_commission` decimal(24,2) NOT NULL DEFAULT 0.00,
  `provider_earning` decimal(24,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_details_amounts`
--

LOCK TABLES `booking_details_amounts` WRITE;
/*!40000 ALTER TABLE `booking_details_amounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_details_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_offline_payments`
--

DROP TABLE IF EXISTS `booking_offline_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_offline_payments` (
  `id` char(36) NOT NULL,
  `booking_id` char(36) NOT NULL,
  `method_name` text DEFAULT NULL,
  `customer_information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_offline_payments`
--

LOCK TABLES `booking_offline_payments` WRITE;
/*!40000 ALTER TABLE `booking_offline_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_offline_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_partial_payments`
--

DROP TABLE IF EXISTS `booking_partial_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_partial_payments` (
  `id` char(36) NOT NULL,
  `booking_id` varchar(255) NOT NULL,
  `paid_with` varchar(255) NOT NULL,
  `paid_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `due_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_partial_payments`
--

LOCK TABLES `booking_partial_payments` WRITE;
/*!40000 ALTER TABLE `booking_partial_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_partial_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_schedule_histories`
--

DROP TABLE IF EXISTS `booking_schedule_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_schedule_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` char(36) NOT NULL,
  `changed_by` char(36) NOT NULL,
  `schedule` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_schedule_histories`
--

LOCK TABLES `booking_schedule_histories` WRITE;
/*!40000 ALTER TABLE `booking_schedule_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_schedule_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_status_histories`
--

DROP TABLE IF EXISTS `booking_status_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_status_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` char(36) NOT NULL,
  `changed_by` char(36) NOT NULL,
  `booking_status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_status_histories`
--

LOCK TABLES `booking_status_histories` WRITE;
/*!40000 ALTER TABLE `booking_status_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_status_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` char(36) NOT NULL,
  `readable_id` bigint(20) NOT NULL,
  `customer_id` char(36) DEFAULT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `zone_id` char(36) DEFAULT NULL,
  `booking_status` varchar(255) NOT NULL DEFAULT 'pending',
  `is_paid` tinyint(1) NOT NULL DEFAULT 0,
  `payment_method` varchar(255) NOT NULL DEFAULT 'cash',
  `transaction_id` varchar(255) DEFAULT NULL,
  `total_booking_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `total_tax_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `total_discount_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `service_schedule` datetime DEFAULT NULL,
  `service_address_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` char(36) DEFAULT NULL,
  `sub_category_id` char(36) DEFAULT NULL,
  `serviceman_id` char(36) DEFAULT NULL,
  `total_campaign_discount_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `total_coupon_discount_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `coupon_code` varchar(255) DEFAULT NULL,
  `is_checked` tinyint(1) NOT NULL DEFAULT 0,
  `additional_charge` decimal(24,2) NOT NULL DEFAULT 0.00,
  `additional_tax_amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `additional_discount_amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `additional_campaign_discount_amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `removed_coupon_amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `evidence_photos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `booking_otp` varchar(255) DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `extra_fee` decimal(24,3) NOT NULL DEFAULT 0.000,
  `total_referral_discount_amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_settings`
--

DROP TABLE IF EXISTS `business_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_settings` (
  `id` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `key_name` varchar(191) DEFAULT NULL,
  `live_values` longtext DEFAULT NULL,
  `test_values` longtext DEFAULT NULL,
  `settings_type` varchar(255) DEFAULT NULL,
  `mode` varchar(20) NOT NULL DEFAULT 'live',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_settings`
--

LOCK TABLES `business_settings` WRITE;
/*!40000 ALTER TABLE `business_settings` DISABLE KEYS */;
INSERT INTO `business_settings` VALUES
('0098459d-9115-4c58-a6f8-becc65d3cb97','service_section_image','\"2024-11-18-673b20a654e49.png\"','\"2024-11-18-673b20a654e49.png\"','landing_images','live',0,'2022-10-03 17:37:21','2024-11-18 12:10:30'),
('01b2c108-18fe-4ad0-8693-04be1bfa59aa','cancellation_policy','\"<p>Demo cancellation policy<\\/p>\"',NULL,'pages_setup','live',1,'2022-08-06 03:54:38','2024-10-08 12:42:37'),
('03840466-ae1f-429f-90f1-6b724953f4e4','referral_discount_validity','0','0','customer_config','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('053c7a7b-75f0-4e01-9961-5e81fdd001f6','email_verification','1','1','service_setup','live',1,'2022-07-21 11:59:22','2022-08-13 07:35:03'),
('078c60ff-a05f-4386-88c4-9b48e98dc7dd','releans','{\"gateway\":\"releans\",\"mode\":\"live\",\"status\":\"1\",\"api_key\":\"data\",\"from\":\"data\",\"otp_template\":\"data\"}','{\"gateway\":\"releans\",\"mode\":\"live\",\"status\":\"1\",\"api_key\":\"data\",\"from\":\"data\",\"otp_template\":\"data\"}','sms_config','live',1,'2022-06-08 06:44:58','2022-10-04 16:26:11'),
('08aa2f9f-e830-4190-87a0-1d57267ab023','booking_edit_service_quantity_increase','{\"booking_edit_service_quantity_increase_status\":\"1\",\"booking_edit_service_quantity_increase_message\":\"Booking Edit Service Quantity Increase\"}','{\"booking_edit_service_quantity_increase_status\":\"1\",\"booking_edit_service_quantity_increase_message\":\"Booking Edit Service Quantity Increase\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('0a2e5ef2-4e4e-40b1-8ea6-9455a3549891','forget_password_verification_method','\"email\"','\"email\"','business_information','live',1,'2023-05-29 16:22:38','2023-05-29 16:22:38'),
('0b0ac068-a661-4e13-ab25-858b9f9bab9d','currency_code','\"USD\"','\"USD\"','business_information','live',1,'2022-06-14 09:39:24','2022-10-04 16:21:24'),
('0bb540c9-9ec6-4977-9284-be250d5b2fc5','maintenance_message_setup','{\"business_number\":1,\"business_email\":1,\"maintenance_message\":\"We are Cooking Up Something Special!\",\"message_body\":\"Sorry for the inconvenience! We are currently undergoing scheduled maintenance to improve our services. We will be back shortly. Thank you for your patience.\"}',NULL,'maintenance_mode','live',1,'2024-08-25 14:24:01','2024-08-25 14:24:01'),
('0c1bcdd4-d93e-4b4a-9ef9-4b5a15153bdb','bidding_post_validity','0','0','bidding_system','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('0d08217a-f52d-4ce2-a63c-88cd1445193f','provider_can_cancel_booking','\"0\"','\"0\"','provider_config','live',0,'2022-07-20 06:04:17','2023-08-30 13:09:23'),
('0d4fea8e-aafd-4fc1-8698-0069e2005b72','booking_notification_type','\"manual\"','\"manual\"','business_information','live',1,'2024-10-08 12:42:37','2024-11-18 02:26:55'),
('0d9bcbac-b423-4052-914a-ede9e7a19197','booking_notification','\"1\"','\"1\"','business_information','live',1,'2024-10-08 12:42:37','2024-11-18 02:26:55'),
('0e2d1635-6f80-4ea0-876b-11f09f16abb8','referral_earning','{\"referral_earning_status\":\"1\",\"referral_earning_message\":\"Refferal Earning\"}','{\"referral_earning_status\":\"1\",\"referral_earning_message\":\"Refferal Earning\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('0f993fad-b7ba-4fdc-b394-5c34fd37ed68','widthdraw_request_deny','{\"widthdraw_request_deny_status\":\"1\",\"widthdraw_request_deny_message\":\"Withdraw Request Deny\"}','{\"widthdraw_request_deny_status\":\"1\",\"widthdraw_request_deny_message\":\"Withdraw Request Deny\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('11c73e6c-f776-49f5-8857-f46fd08f5bcd','additional_charge_fee_amount','0','0','booking_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('11d4f10d-2881-4c7d-baa6-e00ff603bc4b','social_media','[{\"id\":\"c96083cd-cbb0-415b-a215-b77da4c293c9\",\"media\":\"facebook\",\"link\":\"https:\\/\\/www.facebook.com\"},{\"id\":\"8cc641e5-019d-4760-b912-efa39d937635\",\"media\":\"instagram\",\"link\":\"https:\\/\\/www.instagram.com\"},{\"id\":\"0f104f7c-f0cb-4933-b35b-c04f829a682d\",\"media\":\"linkedin\",\"link\":\"https:\\/\\/www.linkedin.com\"},{\"id\":\"793d22b1-aa6a-48c3-a654-47dc799532a7\",\"media\":\"youtube\",\"link\":\"https:\\/\\/www.youtube.com\"}]','[{\"id\":\"c96083cd-cbb0-415b-a215-b77da4c293c9\",\"media\":\"facebook\",\"link\":\"https:\\/\\/www.facebook.com\"},{\"id\":\"8cc641e5-019d-4760-b912-efa39d937635\",\"media\":\"instagram\",\"link\":\"https:\\/\\/www.instagram.com\"},{\"id\":\"0f104f7c-f0cb-4933-b35b-c04f829a682d\",\"media\":\"linkedin\",\"link\":\"https:\\/\\/www.linkedin.com\"},{\"id\":\"793d22b1-aa6a-48c3-a654-47dc799532a7\",\"media\":\"youtube\",\"link\":\"https:\\/\\/www.youtube.com\"}]','landing_social_media','live',0,'2023-08-30 19:27:38','2023-08-30 19:28:46'),
('11dddc2e-2b89-4bcc-9d48-1d3071dc37d6','booking_complete','{\"booking_complete_status\":\"1\",\"booking_complete_message\":\"Booking Complete\"}','{\"booking_complete_status\":\"1\",\"booking_complete_message\":\"Booking Complete\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('14290db3-1876-44a3-a70d-1410d753d673','campaign_cost_bearer','{\"bearer\":\"provider\",\"admin_percentage\":0,\"provider_percentage\":100,\"type\":\"campaign\"}','{\"bearer\":\"provider\",\"admin_percentage\":0,\"provider_percentage\":100,\"type\":\"campaign\"}','promotional_setup','live',1,'2023-01-22 17:33:48','2023-01-22 17:33:48'),
('14eaf75b-68f2-412b-8062-189cff9582cc','app_url_appstore','\"\\/\"','\"\\/\"','landing_button_and_links','live',1,'2022-10-03 16:00:01','2022-10-04 16:22:24'),
('16212625-a1cb-428e-b201-1975495a32cc','provider_self_registration','\"0\"','\"0\"','provider_config','live',0,'2022-07-21 11:59:22','2023-08-30 13:09:23'),
('16ee9973-8d7f-4984-9357-3490fdb8fe04','otp','{\"otp_status\":\"1\",\"otp_message\":\"Confirmation OTP\"}','{\"otp_status\":\"1\",\"otp_message\":\"Confirmation OTP\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('18ff5091-1416-4b68-8a11-4a4db54d94bc','rating_review','{\"push_notification_rating_review\":\"1\",\"email_rating_review\":\"1\"}','{\"push_notification_rating_review\":\"1\",\"email_rating_review\":\"1\"}','notification_settings','live',1,'2022-06-06 12:41:28','2022-08-16 07:43:35'),
('193e005b-a715-4f6f-97cc-2554377b1f28','app_url_playstore','\"\\/\"','\"\\/\"','landing_button_and_links','live',1,'2022-10-03 16:00:01','2022-10-04 16:22:24'),
('1a4ff5aa-2956-458d-96e6-e0847635910c','referral_earning_first_booking','{\"referral_earning_first_booking_status\":\"1\",\"referral_earning_first_booking_message\":\"Referral Earning First Booking\"}','{\"referral_earning_first_booking_status\":\"1\",\"referral_earning_first_booking_message\":\"Referral Earning First Booking\"}','customer_notification','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('1acfd678-38f4-4aab-8431-7f066e8de7f2','phone_verification','0','0','service_setup','live',1,'2023-05-29 16:22:38','2023-05-29 16:22:38'),
('1bb8c72b-20b2-4b89-82d3-c2ead7cf0675','serviceman_can_edit_booking','0','0','serviceman_config','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('1bc292a4-4244-4eb2-8760-5c0bd4d5e236','default_commission','\"20\"','\"20\"','business_information','live',1,'2022-08-18 09:14:58','2022-08-24 02:53:43'),
('1bfbbb5c-5786-491e-89ed-d366b2a84e30','customer_notification_for_provider_bid_withdraw','{\"customer_notification_for_provider_bid_withdraw_status\":\"1\",\"customer_notification_for_provider_bid_withdraw_message\":\"Customer notification for provider bid withdraw\"}','{\"customer_notification_for_provider_bid_withdraw_status\":\"1\",\"customer_notification_for_provider_bid_withdraw_message\":\"Customer notification for provider bid withdraw\"}','customer_notification','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('1c7e7c69-dd9d-4e7b-9379-b5314bb6ec58','testimonial','[{\"id\":\"94f7a473-e9fb-48ec-8bd3-46a0229b3aef\",\"name\":\"Mike\",\"designation\":\"Designer\",\"review\":\"Thank you! That was very helpful! The Service men were very professionals & very caution about safety\",\"image\":\"2023-08-31-64ef36f7190ba.png\"}]','[{\"id\":\"94f7a473-e9fb-48ec-8bd3-46a0229b3aef\",\"name\":\"Mike\",\"designation\":\"Designer\",\"review\":\"Thank you! That was very helpful! The Service men were very professionals & very caution about safety\",\"image\":\"2023-08-31-64ef36f7190ba.png\"}]','landing_testimonial','live',1,'2022-10-03 16:54:42','2023-08-30 19:33:13'),
('1cbe46a3-9f79-47e1-af47-0868c3da2727','booking_edit_service_quantity_decrease','{\"booking_edit_service_quantity_decrease_status\":\"1\",\"booking_edit_service_quantity_decrease_message\":\"Booking Edit Service Quantity Decrease\"}','{\"booking_edit_service_quantity_decrease_status\":\"1\",\"booking_edit_service_quantity_decrease_message\":\"Booking Edit Service Quantity Decrease\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('1e8316f2-660a-44c5-b24c-97320ae212d0','booking_service_complete','{\"booking_service_complete_status\":\"1\",\"booking_service_complete_message\":\"Booking Service successfully complete done\"}','{\"booking_service_complete_status\":\"1\",\"booking_service_complete_message\":\"Booking Service successfully complete done\"}','notification_messages','live',1,'2022-06-06 12:41:28','2022-09-14 17:44:04'),
('26b9dcd8-b8cd-4cc0-9ab4-2705993c31a4','booking_cancel','{\"booking_cancel_status\":\"1\",\"booking_cancel_message\":\"Booking Cancel\"}','{\"booking_cancel_status\":\"1\",\"booking_cancel_message\":\"Booking Cancel\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('27663114-d661-4eab-9eb5-6852bb3b7c7c','booking_edit_service_remove','{\"booking_edit_service_remove_status\":\"1\",\"booking_edit_service_remove_message\":\"Booking Edit Service Remove\"}','{\"booking_edit_service_remove_status\":\"1\",\"booking_edit_service_remove_message\":\"Booking Edit Service Remove\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('2b0ce7e1-ba62-437c-9f5b-cd9ccd12ea1d','booking_accepted','{\"booking_accepted_status\":\"1\",\"booking_accepted_message\":\"Booking Accepted\"}','{\"booking_accepted_status\":\"1\",\"booking_accepted_message\":\"Booking Accepted\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('2c0c6614-1990-4f6f-9c2d-c4481b8c18ff','service_complete_photo_evidence','0','0','booking_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('2dd9ca52-ebd2-45b4-9d38-30a6a16b44ca','top_title','\"Customer Statisfaciton is our main moto\"','\"Customer Statisfaciton is our main moto\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 15:36:11'),
('2dfa523c-65b0-478b-aa31-cf024151e8d9','serviceman_assign','{\"serviceman_assign_status\":\"1\",\"serviceman_assign_message\":\"Serviceman Assign\"}','{\"serviceman_assign_status\":\"1\",\"serviceman_assign_message\":\"Serviceman Assign\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('303e1187-edf1-4e6c-9a0e-e5f57efe3013','booking_otp','0','0','booking_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('30d0ed00-b027-45bb-aaee-ae5982e8c97b','add_to_fund_wallet','0','0','customer_config','live',1,'2023-12-28 14:00:58','2023-12-28 14:00:58'),
('31c5e759-3d31-4522-8ed7-2a067c623c68','booking_place','{\"booking_place_status\":\"1\",\"booking_place_message\":\"Booking Service successfully placed\"}','{\"booking_place_status\":\"1\",\"booking_place_message\":\"Booking Service successfully placed\"}','notification_messages','live',1,'2022-06-06 12:41:28','2022-10-04 16:23:49'),
('330878fe-66b8-4c86-b9f3-c69d7b7ab394','partial_payment','0','0','service_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('35fdbc13-5505-4f08-a480-9a7922fde375','senang_pay','{\"gateway\":\"senang_pay\",\"mode\":\"live\",\"status\":\"0\",\"callback_url\":\"https:\\/\\/url\\/return-senang-pay\",\"secret_key\":\"data\",\"merchant_id\":\"data\"}','{\"gateway\":\"senang_pay\",\"mode\":\"live\",\"status\":\"0\",\"callback_url\":\"https:\\/\\/url\\/return-senang-pay\",\"secret_key\":\"data\",\"merchant_id\":\"data\"}','payment_config','live',0,'2022-06-09 07:21:16','2022-10-04 16:28:53'),
('382abfc4-4742-4080-9f17-350bbc57d813','booking_cancel','{\"booking_cancel_status\":\"0\",\"booking_cancel_message\":\"Booking Cancel Successfully\"}','{\"booking_cancel_status\":\"0\",\"booking_cancel_message\":\"Booking Cancel Successfully\"}','notification_messages','live',0,'2022-06-06 12:41:28','2022-09-14 20:11:36'),
('38c100f5-dc8c-4cf0-af94-855b607f6504','min_payable_amount','0','0','provider_config','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('3a9cf40c-c7ec-481c-8a79-5f33b154a561','email_config','{\"mailer_name\":\"name\",\"host\":\"mail.host.com\",\"driver\":\"smtp\",\"port\":\"587\",\"user_name\":\"demo@6am.one\",\"email_id\":\"email@email.com\",\"encryption\":\"tls\",\"password\":\"password\"}','{\"mailer_name\":\"name\",\"host\":\"mail.host.com\",\"driver\":\"smtp\",\"port\":\"587\",\"user_name\":\"demo@6am.one\",\"email_id\":\"email@email.com\",\"encryption\":\"tls\",\"password\":\"password\"}','email_config','live',1,'2022-06-07 12:32:47','2022-10-04 16:25:45'),
('3b0b4644-9ba9-48e9-8622-59426198e3b9','time_zone','\"Europe\\/Berlin\"','\"Europe\\/Berlin\"','business_information','live',1,'2022-06-14 09:39:24','2024-11-18 02:28:58'),
('3cee349b-0095-4eec-8da3-5db955242f7b','s3_storage_credentials','\"{\\\"key\\\":\\\"\\\",\\\"secret\\\":\\\"\\\",\\\"region\\\":\\\"\\\",\\\"bucket\\\":\\\"\\\",\\\"url\\\":\\\"\\\",\\\"endpoint\\\":\\\"\\\",\\\"path\\\":\\\"\\\"}\"','\"{\\\"key\\\":\\\"\\\",\\\"secret_credential\\\":\\\"\\\",\\\"region\\\":\\\"\\\",\\\"bucket\\\":\\\"\\\",\\\"url\\\":\\\"\\\",\\\"endpoint\\\":\\\"\\\",\\\"path\\\":\\\"\\\"}\"','storage_settings','live',1,'2024-07-07 16:15:01','2024-07-07 16:15:01'),
('3d51e47f-da99-4757-8392-4d6ab9e37fc3','refund','{\"refund_status\":\"1\",\"refund_message\":\"Refund\"}','{\"refund_status\":\"1\",\"refund_message\":\"Refund\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('3d8dfac5-f187-45ee-a3ba-17fa75224bab','booking_edit_service_quantity_increase','{\"booking_edit_service_quantity_increase_status\":\"1\",\"booking_edit_service_quantity_increase_message\":\"Booking Edit Service Quantity Increase\"}','{\"booking_edit_service_quantity_increase_status\":\"1\",\"booking_edit_service_quantity_increase_message\":\"Booking Edit Service Quantity Increase\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('3dd386b8-066c-48c3-af22-f3f197347ea3','customer_wallet','0','0','customer_config','live',1,'2023-02-23 00:25:16','2023-02-23 00:25:16'),
('3e0fe0fa-e697-437e-a0a9-9ff4316f4d39','about_us_description','\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\"','\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 15:36:11'),
('3e1a01ef-ec49-40a7-93b1-a15499028e32','bidding_status','0','0','bidding_system','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('3e4c8b9f-28a2-4f72-b3b5-8b5808121dc8','recaptcha','{\"party_name\":\"recaptcha\",\"status\":\"0\",\"site_key\":\"apikey\",\"secret_key\":\"apikey\"}','{\"party_name\":\"recaptcha\",\"status\":\"0\",\"site_key\":\"apikey\",\"secret_key\":\"apikey\"}','third_party','live',0,'2022-07-25 10:57:25','2022-10-04 16:24:50'),
('4007291b-5078-42ba-9051-fe9c991b9b2f','mid_title','\"SERVICE WE PROVIDE FOR YOU\"','\"SERVICE WE PROVIDE FOR YOU\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 15:36:11'),
('43c89209-172b-47a1-851a-efb90f848aa0','top_image_1','\"2024-11-17-673a2e7b1f51a.png\"','\"2024-11-17-673a2e7b1f51a.png\"','landing_images','live',0,'2022-10-03 16:06:10','2024-11-17 18:57:15'),
('45721749-c637-498c-ad0b-5d369a2d6425','cookies_text','\"lorem ipsum dollar\"','\"lorem ipsum dollar\"','business_information','live',1,'2023-02-23 00:25:16','2023-08-30 19:38:59'),
('45825020-d72d-4d7c-8444-72b790507705','referral_discount_validity_type','\"day\"','\"day\"','customer_config','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('47817d69-8ec9-4730-b81f-838c4fc9d533','top_image_3','\"2024-11-17-673a2e9a2edf1.png\"','\"2024-11-17-673a2e9a2edf1.png\"','landing_images','live',0,'2022-10-03 16:06:15','2024-11-17 18:57:46'),
('47cbf32d-06bf-40ae-980c-3053e7f1a4ad','ongoing_booking','{\"ongoing_booking_status\":\"1\",\"ongoing_booking_message\":\"Ongoing Booking\"}','{\"ongoing_booking_status\":\"1\",\"ongoing_booking_message\":\"Ongoing Booking\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('49146edb-2e7a-4280-ac19-de35c2f894f9','min_booking_amount','0','0','booking_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('49697d57-c686-4d30-9398-9c5533595b7f','provider_bid_request_denied','{\"provider_bid_request_denied_status\":\"1\",\"provider_bid_request_denied_message\":\"Provider Bid Request Denied\"}','{\"provider_bid_request_denied_status\":\"1\",\"provider_bid_request_denied_message\":\"Provider Bid Request Denied\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('4ad0c0ce-157c-46b2-b93d-261ca4f1a575','top_image_4','\"2024-11-17-673a2f0aa97aa.png\"','\"2024-11-17-673a2f0aa97aa.png\"','landing_images','live',0,'2022-10-03 16:07:26','2024-11-17 18:59:38'),
('4cdc5c2e-054d-485b-a906-f0c6032880db','subscription','{\"push_notification_subscription\":\"1\",\"email_subscription\":\"1\"}','{\"push_notification_subscription\":\"1\",\"email_subscription\":\"1\"}','notification_settings','live',1,'2022-06-06 12:41:28','2022-08-16 07:43:35'),
('4d69c64d-7956-4fd5-bdc0-59062152899d','max_booking_amount','0','0','booking_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('4dc4001c-2294-4ccf-8f02-8e6457cb260e','provider_suspend','{\"provider_suspend_status\":\"1\",\"provider_suspend_message\":\"Provider Suspend\"}','{\"provider_suspend_status\":\"1\",\"provider_suspend_message\":\"Provider Suspend\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('4dcb5aae-3a76-4754-b23a-286726a60d61','business_logo','\"2024-11-27-6746b40088839.png\"','\"2024-11-27-6746b40088839.png\"','business_information','live',1,'2022-06-14 09:39:24','2024-11-27 06:54:08'),
('4ddd1410-e290-4e3f-a66c-ee70f86368db','bottom_title','\"GET ALL UPDATES & EXCITING NEWS\"','\"GET ALL UPDATES & EXCITING NEWS\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 16:14:45'),
('4e1af097-855e-43b8-ae10-0a0039039706','booking_accepted','{\"booking_accepted_status\":\"0\",\"booking_accepted_message\":\"Booking Service successfully complete done\"}','{\"booking_accepted_status\":\"0\",\"booking_accepted_message\":\"Booking Service successfully complete done\"}','notification_messages','live',0,'2022-06-06 12:41:28','2022-10-04 16:23:59'),
('4e6fda04-d5b3-4ddd-a086-3c6567346e5c','tnc_update','{\"push_notification_tnc_update\":\"0\",\"email_tnc_update\":0}','{\"push_notification_tnc_update\":\"0\",\"email_tnc_update\":0}','notification_settings','live',1,'2022-06-06 12:41:28','2022-10-04 16:23:28'),
('4e816e5e-ea8d-4d0e-bb57-5015c57be62a','system_language','[{\"id\":1,\"name\":\"english\",\"direction\":\"ltr\",\"code\":\"en\",\"status\":1,\"default\":true}]','[{\"id\":1,\"name\":\"english\",\"direction\":\"ltr\",\"code\":\"en\",\"status\":1,\"default\":true}]','business_information','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('514c7284-cab8-42a2-9f48-82e779d7afdd','direct_provider_booking','\"0\"','\"0\"','business_information','live',1,'2023-08-30 19:38:42','2023-08-30 19:38:42'),
('539b1d42-0730-418d-83b0-46911e42cc39','privacy_policy','\"\\\"<p>Demo privacy policy<\\/p>\\\"\"',NULL,'pages_setup','live',1,'2022-08-06 04:00:09','2022-09-08 14:37:37'),
('54b42ef4-2f17-4424-aebc-7e5490b97557','bottom_description','\"Subcribe to out newsletters to receive all the latest activty we provide for you\"','\"Subcribe to out newsletters to receive all the latest activty we provide for you\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 16:14:45'),
('54b77f94-c818-41cc-afff-9200213a541f','booking_edit_service_remove','{\"booking_edit_service_remove_status\":\"1\",\"booking_edit_service_remove_message\":\"Booking Edit Service Remove\"}','{\"booking_edit_service_remove_status\":\"1\",\"booking_edit_service_remove_message\":\"Booking Edit Service Remove\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('55f5fcbb-35db-4a57-b962-908cbc174ddf','provider_can_reply_review','1',NULL,'provider_config','live',1,'2024-10-08 12:42:37','2024-10-08 12:42:37'),
('5675c00e-9686-4032-96f9-ce4631b9960a','speciality','[{\"id\":\"c3392f65-51ea-460a-b503-41a6e986971e\",\"title\":\"Speciality\",\"description\":\"Speciality description\",\"image\":\"2023-08-31-64ef3bcbbeb55.png\"}]','[{\"id\":\"c3392f65-51ea-460a-b503-41a6e986971e\",\"title\":\"Speciality\",\"description\":\"Speciality description\",\"image\":\"2023-08-31-64ef3bcbbeb55.png\"}]','landing_speciality','live',1,'2022-10-03 18:13:41','2023-08-30 19:53:45'),
('57b3d923-139a-430b-a7b8-2c0797110cfd','sms_verification','1','1','service_setup','live',1,'2022-07-21 11:59:22','2022-08-13 07:35:03'),
('5961e8be-4f8a-413b-a041-4aad8a4b0f59','email_config_status','1','1','email_config','live',1,'2024-07-13 10:35:13','2024-07-13 10:35:13'),
('59d855e6-06ad-487a-9ca1-bbd8d3db2dfa','stripe','{\"gateway\":\"stripe\",\"mode\":\"test\",\"status\":\"1\",\"api_key\":\"data\",\"published_key\":\"data\"}','{\"gateway\":\"stripe\",\"mode\":\"test\",\"status\":\"1\",\"api_key\":\"data\",\"published_key\":\"data\"}','payment_config','test',1,'2022-06-09 05:41:48','2022-10-04 16:28:57'),
('59f6e3d4-382f-47e6-b973-2c1cb2054016','digital_payment','1','1','service_setup','live',1,'2023-05-29 16:22:38','2023-05-29 16:22:38'),
('5b7601e2-d34f-45ac-9f69-6b01585c5001','advertisement_resumed','{\"advertisement_resumed_status\":\"1\",\"advertisement_resumed_message\":\"Advertisement Resumed\"}','{\"advertisement_resumed_status\":\"1\",\"advertisement_resumed_message\":\"Advertisement Resumed\"}','provider_notification','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('5d8972d5-ae9b-47cd-b76c-011923ea8e54','booking_edit_service_remove','{\"booking_edit_service_remove_status\":\"1\",\"booking_edit_service_remove_message\":\"Booking Edit Service Remove\"}','{\"booking_edit_service_remove_status\":\"1\",\"booking_edit_service_remove_message\":\"Booking Edit Service Remove\"}','serviceman_notification','live',1,'2023-12-28 14:00:58','2023-12-28 14:00:58'),
('5e470acd-7935-4394-ab56-008fdeb65029','third_party','{\"party_name\":\"push_notification\",\"server_key\":\"56789fghjk\"}','{\"party_name\":\"push_notification\",\"server_key\":\"56789fghjk\"}','third_party','live',1,'2022-06-08 10:57:43','2022-06-08 10:57:43'),
('6170b133-2556-4eb0-b5bf-3352566e5c83','booking_ongoing','{\"booking_ongoing_status\":\"0\",\"booking_ongoing_message\":\"Booking Service successfully complete done\"}','{\"booking_ongoing_status\":\"0\",\"booking_ongoing_message\":\"Booking Service successfully complete done\"}','notification_messages','live',0,'2022-10-04 16:24:02','2022-10-04 16:24:02'),
('63eb11ab-b34d-4bfc-a55f-e807c1974f41','advertisement_denied','{\"advertisement_denied_status\":\"1\",\"advertisement_denied_message\":\"Advertisement Denied\"}','{\"advertisement_denied_status\":\"1\",\"advertisement_denied_message\":\"Advertisement Denied\"}','provider_notification','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('65e9c5de-c37d-4dc8-bc6a-011784784176','partial_payment_combinator','\"all\"','\"all\"','service_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('668cdb3b-63a4-4ad4-ac35-407c811576b6','flutterwave','{\"gateway\":\"flutterwave\",\"mode\":\"test\",\"status\":\"1\",\"secret_key\":\"data\",\"public_key\":\"data\",\"hash\":\"data\"}','{\"gateway\":\"flutterwave\",\"mode\":\"test\",\"status\":\"1\",\"secret_key\":\"data\",\"public_key\":\"data\",\"hash\":\"data\"}','payment_config','test',1,'2022-09-03 08:47:46','2022-10-04 16:29:07'),
('694b2b7f-24a9-43b7-abaa-f73736e5873d','serviceman_assign','{\"serviceman_assign_status\":\"1\",\"serviceman_assign_message\":\"Serviceman Assign\"}','{\"serviceman_assign_status\":\"1\",\"serviceman_assign_message\":\"Serviceman Assign\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('698dadfe-91b6-4b1b-9799-c6620f4bb0dc','booking_edit_service_quantity_increase','{\"booking_edit_service_quantity_increase_status\":\"1\",\"booking_edit_service_quantity_increase_message\":\"Booking Edit Service Quantity Increase\"}','{\"booking_edit_service_quantity_increase_status\":\"1\",\"booking_edit_service_quantity_increase_message\":\"Booking Edit Service Quantity Increase\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('6a46c913-5d22-48bb-85ba-161defad284e','add_fund_wallet_bonus','{\"add_fund_wallet_bonus_status\":\"1\",\"add_fund_wallet_bonus_message\":\"Add Fund Wallet Bonus\"}','{\"add_fund_wallet_bonus_status\":\"1\",\"add_fund_wallet_bonus_message\":\"Add Fund Wallet Bonus\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('6b208b3b-b474-4010-ab1c-57a708ef1a0d','customer_notification_for_provider_bid_offer','{\"customer_notification_for_provider_bid_offer_status\":\"1\",\"customer_notification_for_provider_bid_offer_message\":\"customer notification for provider bid offer\"}','{\"customer_notification_for_provider_bid_offer_status\":\"1\",\"customer_notification_for_provider_bid_offer_message\":\"customer notification for provider bid offer\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('6c8aa862-cd24-489c-bcc7-b5d0361c6b18','advanced_booking_restriction_value','3','3','booking_setup','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('6d3c9600-0fd9-4ebe-a740-22c21c90f619','pp_update','{\"push_notification_pp_update\":\"0\",\"email_pp_update\":0}','{\"push_notification_pp_update\":\"0\",\"email_pp_update\":0}','notification_settings','live',1,'2022-06-06 12:41:28','2022-10-04 16:23:30'),
('6f654cb0-3fda-47ff-9084-e2f5db1fcc94','referral_based_new_user_discount','0','0','customer_config','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('6fcf21de-e1c8-4bd4-ab2c-dff708e79277','currency_symbol_position','\"left\"','\"left\"','business_information','live',1,'2022-06-14 09:39:24','2022-09-14 06:07:12'),
('7014ab21-7c89-4f6f-9e63-05806292802f','customer_loyalty_point','0','0','customer_config','live',1,'2023-02-23 00:25:16','2023-02-23 00:25:16'),
('72189cb6-4608-4311-8b0c-25ef39265566','advertisement_approved','{\"advertisement_approved_status\":\"1\",\"advertisement_approved_message\":\"Advertisement Approved\"}','{\"advertisement_approved_status\":\"1\",\"advertisement_approved_message\":\"Advertisement Approved\"}','provider_notification','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('73a38ec7-5b60-402f-a17b-6e308c1b3cf7','provider_can_edit_booking','0','0','provider_config','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('749dc8fa-b2f0-4236-a400-f52fe3b8193b','refund_policy','\"<p>Demo refund policy<\\/p>\"',NULL,'pages_setup','live',1,'2022-08-06 04:02:38','2022-09-08 14:37:27'),
('790b2df0-f099-48b2-999e-b74d48a2fe07','ongoing_booking','{\"ongoing_booking_status\":\"1\",\"ongoing_booking_message\":\"Ongoing Booking\"}','{\"ongoing_booking_status\":\"1\",\"ongoing_booking_message\":\"Ongoing Booking\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('7a097aeb-c48d-4243-9217-85baf4dfdb0d','advertisement_created_by_admin','{\"advertisement_created_by_admin_status\":\"1\",\"advertisement_created_by_admin_message\":\"Advertisement Created By Admin\"}','{\"advertisement_created_by_admin_status\":\"1\",\"advertisement_created_by_admin_message\":\"Advertisement Created By Admin\"}','provider_notification','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('7a2d5afd-8957-41c2-8269-14cdce19f432','privacy_and_policy_update','{\"privacy_and_policy_update_status\":\"1\",\"privacy_and_policy_update_message\":\"Privacy And Policy Update\"}','{\"privacy_and_policy_update_status\":\"1\",\"privacy_and_policy_update_message\":\"Privacy And Policy Update\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('7a834fe4-6d3e-48c9-a707-aa8f4e849375','header_background','\"#e3f2fc\"','\"#e3f2fc\"','landing_background','live',0,'2023-08-30 19:23:47','2023-08-30 19:23:47'),
('7be92742-c947-4786-ae8c-848798da7b08','referral_discount_amount','0','0','customer_config','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('7d347217-930c-4e03-a696-063fd2c80baa','maintenance_system_setup','[]',NULL,'maintenance_mode','live',1,'2024-08-25 14:24:01','2024-08-25 14:24:01'),
('7eb3ac41-7c85-4877-8eae-6580c2ad6daa','subscription_vat','0','0','subscription_Setting','live',1,'2024-07-09 18:57:16','2024-07-09 18:57:16'),
('7f266d17-6867-499f-bad6-9a8b55ab3ff1','order','{\"push_notification_order\":\"1\",\"email_order\":\"1\"}','{\"push_notification_order\":\"1\",\"email_order\":\"1\"}','notification_settings','live',1,'2022-06-06 12:41:28','2022-07-23 07:08:34'),
('7fe3d581-d7c3-46e1-b804-c97efefcfeba','suspend_on_exceed_cash_limit_provider','0','0','provider_config','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('815f1823-9a67-4248-a62c-17eed4388745','service_request_deny','{\"service_request_deny_status\":\"1\",\"service_request_deny_message\":\"Service Request Reject\"}','{\"service_request_deny_status\":\"1\",\"service_request_deny_message\":\"Service Request Reject\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('81fa30e8-24d5-485b-90fc-a4995718b91e','footer_background','\"#001f35\"','\"#001f35\"','landing_background','live',0,'2023-08-30 19:23:47','2023-08-30 19:24:38'),
('843ace86-ec16-46fa-8260-ba1d1e4e0eff','maintenance_mode','0',NULL,'maintenance_mode','live',1,'2024-08-25 14:24:01','2024-08-25 14:24:01'),
('848492c2-b2c9-4fed-b486-77db4ff141ae','msg91','{\"gateway\":\"msg91\",\"mode\":\"live\",\"status\":\"0\",\"template_id\":\"data\",\"auth_key\":\"data\"}','{\"gateway\":\"msg91\",\"mode\":\"live\",\"status\":\"0\",\"template_id\":\"data\",\"auth_key\":\"data\"}','sms_config','live',0,'2022-06-08 09:06:49','2022-10-04 16:26:16'),
('85dc4d4a-d25c-492f-b030-17723bcbf95b','booking_place','{\"booking_place_status\":\"1\",\"booking_place_message\":\"Booking Place\"}','{\"booking_place_status\":\"1\",\"booking_place_message\":\"Booking Place\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('873986dd-541b-4648-bd32-edac7504143e','nexmo','{\"gateway\":\"nexmo\",\"mode\":\"live\",\"status\":\"0\",\"api_key\":\"data\",\"api_secret\":\"data\",\"token\":\"data\",\"from\":\"data\",\"otp_template\":\"data\"}','{\"gateway\":\"nexmo\",\"mode\":\"live\",\"status\":\"0\",\"api_key\":\"data\",\"api_secret\":\"data\",\"token\":\"data\",\"from\":\"data\",\"otp_template\":\"data\"}','sms_config','live',0,'2022-06-08 07:19:18','2022-10-04 16:26:27'),
('894ed562-3c8f-4ff6-9e92-5c524c2e4802','advanced_booking_restriction_type','\"hour\"','\"hour\"','booking_setup','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('89969f42-1340-4e1e-9d78-153495bf5c5f','firebase_otp_verification','{\"party_name\":\"firebase_otp_verification\",\"status\":\"1\",\"web_api_key\":\"AIzaSyAsdITT7h96KsehVpzpw7Ako0cSZ7YAkls\"}','{\"party_name\":\"firebase_otp_verification\",\"status\":\"1\",\"web_api_key\":\"AIzaSyAsdITT7h96KsehVpzpw7Ako0cSZ7YAkls\"}','third_party','live',1,'2024-08-25 14:24:01','2024-11-23 22:21:20'),
('89d237b1-861e-4066-9cb6-c9adfd672726','schedule_booking','1','1','service_setup','live',1,'2022-07-20 06:04:14','2022-08-13 07:35:03'),
('8c296af0-65c5-43f9-aa4a-854cbbf19148','pagination_limit','\"20\"','\"20\"','business_information','live',1,'2022-09-05 10:06:02','2022-10-04 16:21:24'),
('8d6b0e16-f753-4833-8f79-7d049a50deb7','registration_description','\"Become e provider & Start your own business online with on demand service platform\"','\"Become e provider & Start your own business online with on demand service platform\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 15:36:11'),
('8dd69e40-c24d-42f3-916a-a3295a203aab','customer_app_settings','\"{\\\"min_version_for_android\\\":\\\"2.0\\\",\\\"min_version_for_ios\\\":\\\"2.0\\\"}\"','\"{\\\"min_version_for_android\\\":\\\"2.0\\\",\\\"min_version_for_ios\\\":\\\"2.0\\\"}\"','app_settings','live',0,'2024-12-11 06:21:32','2024-12-11 06:21:32'),
('8dddf0eb-2021-4d16-9d84-687603f71285','coupon_cost_bearer','{\"bearer\":\"provider\",\"admin_percentage\":0,\"provider_percentage\":100,\"type\":\"coupon\"}','{\"bearer\":\"provider\",\"admin_percentage\":0,\"provider_percentage\":100,\"type\":\"coupon\"}','promotional_setup','live',1,'2023-01-22 17:33:48','2023-01-22 17:33:48'),
('8e6dfa1d-1b51-456e-a35a-ae58eb81baee','additional_charge_label_name',NULL,NULL,'booking_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('8fa88ebf-5aac-4ea5-b87d-aff994f77d0e','provider_self_delete','1','1','provider_config','live',1,'2023-11-28 15:33:20','2023-11-28 15:33:20'),
('9147e081-8ce5-4981-a943-d99536277be5','','\"def.png\"','\"def.png\"','landing_images','live',0,'2024-11-17 18:56:54','2024-11-17 18:56:54'),
('916547ea-8840-4616-9b52-78f6159b1ca6','schedule_booking_time_restriction','1','1','booking_setup','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('92043fa7-f54f-4733-9dbf-3719970a5b62','paytm','{\"gateway\":\"paytm\",\"mode\":\"test\",\"status\":\"1\",\"merchant_key\":\"data\",\"merchant_id\":\"data\",\"merchant_website_link\":\"data\"}','{\"gateway\":\"paytm\",\"mode\":\"test\",\"status\":\"1\",\"merchant_key\":\"data\",\"merchant_id\":\"data\",\"merchant_website_link\":\"data\"}','payment_config','test',1,'2022-06-09 07:21:49','2022-10-04 16:29:15'),
('925c9c9e-d2a4-41bc-b9d2-ff16fed80ce3','body_background','\"#fcfcfc\"','\"#fcfcfc\"','landing_background','live',0,'2023-08-30 19:23:47','2023-08-30 19:25:22'),
('9288358a-cab7-4c5c-b342-75b7ab17c29a','business_phone','\"+4915142023402\"','\"+4915142023402\"','business_information','live',1,'2022-06-14 09:39:24','2024-11-18 02:28:58'),
('92ba62c6-17e3-4f30-a99b-0ee6dfe46628','booking_edit_service_quantity_decrease','{\"booking_edit_service_quantity_decrease_status\":\"1\",\"booking_edit_service_quantity_decrease_message\":\"Booking Edit Service Quantity Decrease\"}','{\"booking_edit_service_quantity_decrease_status\":\"1\",\"booking_edit_service_quantity_decrease_message\":\"Booking Edit Service Quantity Decrease\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('93670ab4-e54d-46ea-a8ed-101cb968208e','about_us_title','\"WHO WE ARE\"','\"WHO WE ARE\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 15:36:11'),
('94f715e7-164d-4e05-bb64-e3547d94a5e4','business_address','\"Franz-Liszt-Stra\\u00dfe 9\\r\\n50825 Cologne\"','\"Franz-Liszt-Stra\\u00dfe 9\\r\\n50825 Cologne\"','business_information','live',1,'2022-06-14 09:39:24','2024-11-18 02:26:55'),
('973e0fe3-b6ff-4156-aa9a-78e52e069527','booking','{\"push_notification_booking\":1,\"email_booking\":1}','{\"push_notification_booking\":\"0\",\"email_booking\":0}','notification_settings','live',1,'2022-07-28 04:31:15','2024-10-08 12:42:37'),
('98a973f9-0ec8-4fe5-b31d-d04c045bab41','referral_value_per_currency_unit','0','0','customer_config','live',1,'2023-02-23 00:25:16','2023-02-23 00:25:16'),
('98e2f206-5314-4fc6-9625-95568bbc2771','serviceman_can_cancel_booking','0','0','serviceman_config','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('998b0da0-268b-4354-8855-a40f266a2c84','referral_code_used','{\"referral_code_used_status\":\"1\",\"referral_code_used_message\":\"Referral code used\"}','{\"referral_code_used_status\":\"1\",\"referral_code_used_message\":\"Referral code used\"}','customer_notification','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('9a961fd3-b032-4260-a9dd-93ad7c0b76b8','paystack','{\"gateway\":\"paystack\",\"mode\":\"test\",\"status\":\"1\",\"callback_url\":\"https:\\/\\/api.paystack.co\",\"public_key\":\"data\",\"secret_key\":\"data\",\"merchant_email\":\"data\"}','{\"gateway\":\"paystack\",\"mode\":\"test\",\"status\":\"1\",\"callback_url\":\"https:\\/\\/api.paystack.co\",\"public_key\":\"data\",\"secret_key\":\"data\",\"merchant_email\":\"data\"}','payment_config','test',1,'2022-06-09 06:12:45','2022-10-04 16:29:25'),
('9ba99828-e514-4b9a-89f7-a07daad49b2c','free_trial_period','7','7','subscription_Setting','live',1,'2024-07-09 18:57:16','2024-07-09 18:57:16'),
('9ec59242-4fd2-4f54-898c-4b4c60270ecd','business_favicon','\"2024-11-27-6746b4aaef316.png\"','\"2024-11-27-6746b4aaef316.png\"','business_information','live',1,'2022-06-14 09:39:24','2024-11-27 06:56:58'),
('9f9f1855-6566-49d4-8ca8-f033a8a2c107','add_fund_wallet','{\"add_fund_wallet_status\":\"1\",\"add_fund_wallet_message\":\"Add Fund Wallet\"}','{\"add_fund_wallet_status\":\"1\",\"add_fund_wallet_message\":\"Add Fund Wallet\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('9ff4b51f-0edd-4a33-ab15-bc79f7542ecd','about_us','\"<p>hello world hero greatth weh fvaaafawefdsdsdsd<\\/p>\"',NULL,'pages_setup','live',1,'2022-08-04 13:04:19','2022-10-04 11:57:25'),
('a0910af1-fee3-4527-957b-e46b40ad5ed2','bid_offers_visibility_for_providers','0','0','bidding_system','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('a38599a7-fb8f-4f3c-a955-b975cdd8fae5','customer_referral_earning','0','0','customer_config','live',1,'2023-02-23 00:25:16','2023-02-23 00:25:16'),
('a6cd4791-0276-4fa4-b2a1-13d3d5a8f232','twilio','{\"gateway\":\"twilio\",\"mode\":\"live\",\"status\":\"0\",\"sid\":\"data\",\"messaging_service_sid\":\"data\",\"token\":\"data\",\"from\":\"data\",\"otp_template\":\"data\"}','{\"gateway\":\"twilio\",\"mode\":\"live\",\"status\":\"0\",\"sid\":\"data\",\"messaging_service_sid\":\"data\",\"token\":\"data\",\"from\":\"data\",\"otp_template\":\"data\"}','sms_config','live',0,'2022-06-08 07:03:02','2022-10-04 16:26:39'),
('a827df9b-74a4-4944-8804-835026450c92','privacy_and_policy_update',NULL,NULL,'pages_setup','live',1,'2024-10-08 12:42:37','2024-10-08 12:42:37'),
('a8c1f49a-be3b-4609-8242-37142ff05acd','currency_decimal_point','\"2\"','\"2\"','business_information','live',1,'2022-06-14 09:39:24','2022-10-04 16:21:24'),
('a9c93141-a7c9-473b-ac46-b3dadc7b067f','razor_pay','{\"gateway\":\"razor_pay\",\"mode\":\"live\",\"status\":\"1\",\"api_key\":\"data\",\"api_secret\":\"data\"}','{\"gateway\":\"razor_pay\",\"mode\":\"live\",\"status\":\"1\",\"api_key\":\"data\",\"api_secret\":\"data\"}','payment_config','live',1,'2022-06-09 07:46:29','2022-10-04 16:29:32'),
('ab04b341-d3ae-4c45-9e35-813dd01f22b6','max_cash_in_hand_limit_provider','0','0','provider_config','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('aba6da13-a238-4042-97f6-78972dccfdd0','instant_booking','1','1','booking_setup','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('ae03b974-b953-4c6d-98c4-6eb0f231d16d','customized_booking_request_delete','{\"customized_booking_request_delete_status\":\"1\",\"customized_booking_request_delete_message\":\"Customized Booking Request Delete\"}','{\"customized_booking_request_delete_status\":\"1\",\"customized_booking_request_delete_message\":\"Customized Booking Request Delete\"}','customer_notification','live',1,'2024-03-13 09:19:39','2024-03-13 09:19:39'),
('af729332-d8ec-4822-854a-5f54e10a9061','sslcommerz','{\"gateway\":\"sslcommerz\",\"mode\":\"test\",\"status\":\"1\",\"store_id\":\"data\",\"store_password\":\"data\"}','{\"gateway\":\"sslcommerz\",\"mode\":\"test\",\"status\":\"1\",\"store_id\":\"data\",\"store_password\":\"data\"}','payment_config','test',1,'2022-06-09 03:19:38','2022-10-04 16:29:39'),
('afba0ef3-7b60-4638-b2c0-2dac02f2119e','booking_schedule_time_change','{\"booking_schedule_time_change_status\":\"1\",\"booking_schedule_time_change_message\":\"Booking schedule time change\"}','{\"booking_schedule_time_change_status\":\"1\",\"booking_schedule_time_change_message\":\"Booking schedule time change\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('afe56fb4-02b6-4cc7-bec8-752012dd2c87','provider_commision','1','1','provider_config','live',1,'2024-07-09 13:20:42','2024-07-09 13:20:42'),
('aff0213c-bcb2-42e0-98bb-295262683ccf','booking_edit_service_add','{\"booking_edit_service_add_status\":\"1\",\"booking_edit_service_add_message\":\"Booking Edit Service Add\"}','{\"booking_edit_service_add_status\":\"1\",\"booking_edit_service_add_message\":\"Booking Edit Service Add\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('b004a67d-df30-4a85-9ec0-54774cc2e616','min_loyalty_point_to_transfer','0','0','customer_config','live',1,'2023-02-23 00:25:16','2023-02-23 00:25:16'),
('b0bf5be1-183a-4dbe-86f6-bd3ff2b9c68a','push_notification','{\"server_key\":\"apikey\",\"service_file_content\":\"{\\r\\n  \\\"project_info\\\": {\\r\\n    \\\"project_number\\\": \\\"378256963900\\\",\\r\\n    \\\"project_id\\\": \\\"beyondyou-c2149\\\",\\r\\n    \\\"storage_bucket\\\": \\\"beyondyou-c2149.firebasestorage.app\\\"\\r\\n  },\\r\\n  \\\"client\\\": [\\r\\n    {\\r\\n      \\\"client_info\\\": {\\r\\n        \\\"mobilesdk_app_id\\\": \\\"1:378256963900:android:9e73f0455b6b41c6948639\\\",\\r\\n        \\\"android_client_info\\\": {\\r\\n          \\\"package_name\\\": \\\"com.beyondyou.BeyondYou\\\"\\r\\n        }\\r\\n      },\\r\\n      \\\"oauth_client\\\": [\\r\\n        {\\r\\n          \\\"client_id\\\": \\\"378256963900-p9mvgba1iuru7ckg0cjegp2kofe33k17.apps.googleusercontent.com\\\",\\r\\n          \\\"client_type\\\": 1,\\r\\n          \\\"android_info\\\": {\\r\\n            \\\"package_name\\\": \\\"com.beyondyou.BeyondYou\\\",\\r\\n            \\\"certificate_hash\\\": \\\"487e7ab843a22751314d0aa97d82d621490f9e26\\\"\\r\\n          }\\r\\n        },\\r\\n        {\\r\\n          \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n          \\\"client_type\\\": 3\\r\\n        }\\r\\n      ],\\r\\n      \\\"api_key\\\": [\\r\\n        {\\r\\n          \\\"current_key\\\": \\\"AIzaSyDyxZ3ImSaihYd05_ikmR_ht28w3HLyjKA\\\"\\r\\n        }\\r\\n      ],\\r\\n      \\\"services\\\": {\\r\\n        \\\"appinvite_service\\\": {\\r\\n          \\\"other_platform_oauth_client\\\": [\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 3\\r\\n            },\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-7ng55udo4sk04vu5su6s8kof6ejurh1r.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 2,\\r\\n              \\\"ios_info\\\": {\\r\\n                \\\"bundle_id\\\": \\\"com.beyondyounet.BeyondYounet.providerapp\\\"\\r\\n              }\\r\\n            }\\r\\n          ]\\r\\n        }\\r\\n      }\\r\\n    },\\r\\n    {\\r\\n      \\\"client_info\\\": {\\r\\n        \\\"mobilesdk_app_id\\\": \\\"1:378256963900:android:5a1939650afc2896948639\\\",\\r\\n        \\\"android_client_info\\\": {\\r\\n          \\\"package_name\\\": \\\"com.beyondyounet.BeyondYounet.provider\\\"\\r\\n        }\\r\\n      },\\r\\n      \\\"oauth_client\\\": [\\r\\n        {\\r\\n          \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n          \\\"client_type\\\": 3\\r\\n        }\\r\\n      ],\\r\\n      \\\"api_key\\\": [\\r\\n        {\\r\\n          \\\"current_key\\\": \\\"AIzaSyDyxZ3ImSaihYd05_ikmR_ht28w3HLyjKA\\\"\\r\\n        }\\r\\n      ],\\r\\n      \\\"services\\\": {\\r\\n        \\\"appinvite_service\\\": {\\r\\n          \\\"other_platform_oauth_client\\\": [\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 3\\r\\n            },\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-7ng55udo4sk04vu5su6s8kof6ejurh1r.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 2,\\r\\n              \\\"ios_info\\\": {\\r\\n                \\\"bundle_id\\\": \\\"com.beyondyounet.BeyondYounet.providerapp\\\"\\r\\n              }\\r\\n            }\\r\\n          ]\\r\\n        }\\r\\n      }\\r\\n    },\\r\\n    {\\r\\n      \\\"client_info\\\": {\\r\\n        \\\"mobilesdk_app_id\\\": \\\"1:378256963900:android:4e2cd7c1e03e60a5948639\\\",\\r\\n        \\\"android_client_info\\\": {\\r\\n          \\\"package_name\\\": \\\"com.beyondyounet.BeyondYounet.services\\\"\\r\\n        }\\r\\n      },\\r\\n      \\\"oauth_client\\\": [\\r\\n        {\\r\\n          \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n          \\\"client_type\\\": 3\\r\\n        }\\r\\n      ],\\r\\n      \\\"api_key\\\": [\\r\\n        {\\r\\n          \\\"current_key\\\": \\\"AIzaSyDyxZ3ImSaihYd05_ikmR_ht28w3HLyjKA\\\"\\r\\n        }\\r\\n      ],\\r\\n      \\\"services\\\": {\\r\\n        \\\"appinvite_service\\\": {\\r\\n          \\\"other_platform_oauth_client\\\": [\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 3\\r\\n            },\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-7ng55udo4sk04vu5su6s8kof6ejurh1r.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 2,\\r\\n              \\\"ios_info\\\": {\\r\\n                \\\"bundle_id\\\": \\\"com.beyondyounet.BeyondYounet.providerapp\\\"\\r\\n              }\\r\\n            }\\r\\n          ]\\r\\n        }\\r\\n      }\\r\\n    }\\r\\n  ],\\r\\n  \\\"configuration_version\\\": \\\"1\\\"\\r\\n}\"}','{\"server_key\":\"apikey\",\"service_file_content\":\"{\\r\\n  \\\"project_info\\\": {\\r\\n    \\\"project_number\\\": \\\"378256963900\\\",\\r\\n    \\\"project_id\\\": \\\"beyondyou-c2149\\\",\\r\\n    \\\"storage_bucket\\\": \\\"beyondyou-c2149.firebasestorage.app\\\"\\r\\n  },\\r\\n  \\\"client\\\": [\\r\\n    {\\r\\n      \\\"client_info\\\": {\\r\\n        \\\"mobilesdk_app_id\\\": \\\"1:378256963900:android:9e73f0455b6b41c6948639\\\",\\r\\n        \\\"android_client_info\\\": {\\r\\n          \\\"package_name\\\": \\\"com.beyondyou.BeyondYou\\\"\\r\\n        }\\r\\n      },\\r\\n      \\\"oauth_client\\\": [\\r\\n        {\\r\\n          \\\"client_id\\\": \\\"378256963900-p9mvgba1iuru7ckg0cjegp2kofe33k17.apps.googleusercontent.com\\\",\\r\\n          \\\"client_type\\\": 1,\\r\\n          \\\"android_info\\\": {\\r\\n            \\\"package_name\\\": \\\"com.beyondyou.BeyondYou\\\",\\r\\n            \\\"certificate_hash\\\": \\\"487e7ab843a22751314d0aa97d82d621490f9e26\\\"\\r\\n          }\\r\\n        },\\r\\n        {\\r\\n          \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n          \\\"client_type\\\": 3\\r\\n        }\\r\\n      ],\\r\\n      \\\"api_key\\\": [\\r\\n        {\\r\\n          \\\"current_key\\\": \\\"AIzaSyDyxZ3ImSaihYd05_ikmR_ht28w3HLyjKA\\\"\\r\\n        }\\r\\n      ],\\r\\n      \\\"services\\\": {\\r\\n        \\\"appinvite_service\\\": {\\r\\n          \\\"other_platform_oauth_client\\\": [\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 3\\r\\n            },\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-7ng55udo4sk04vu5su6s8kof6ejurh1r.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 2,\\r\\n              \\\"ios_info\\\": {\\r\\n                \\\"bundle_id\\\": \\\"com.beyondyounet.BeyondYounet.providerapp\\\"\\r\\n              }\\r\\n            }\\r\\n          ]\\r\\n        }\\r\\n      }\\r\\n    },\\r\\n    {\\r\\n      \\\"client_info\\\": {\\r\\n        \\\"mobilesdk_app_id\\\": \\\"1:378256963900:android:5a1939650afc2896948639\\\",\\r\\n        \\\"android_client_info\\\": {\\r\\n          \\\"package_name\\\": \\\"com.beyondyounet.BeyondYounet.provider\\\"\\r\\n        }\\r\\n      },\\r\\n      \\\"oauth_client\\\": [\\r\\n        {\\r\\n          \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n          \\\"client_type\\\": 3\\r\\n        }\\r\\n      ],\\r\\n      \\\"api_key\\\": [\\r\\n        {\\r\\n          \\\"current_key\\\": \\\"AIzaSyDyxZ3ImSaihYd05_ikmR_ht28w3HLyjKA\\\"\\r\\n        }\\r\\n      ],\\r\\n      \\\"services\\\": {\\r\\n        \\\"appinvite_service\\\": {\\r\\n          \\\"other_platform_oauth_client\\\": [\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 3\\r\\n            },\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-7ng55udo4sk04vu5su6s8kof6ejurh1r.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 2,\\r\\n              \\\"ios_info\\\": {\\r\\n                \\\"bundle_id\\\": \\\"com.beyondyounet.BeyondYounet.providerapp\\\"\\r\\n              }\\r\\n            }\\r\\n          ]\\r\\n        }\\r\\n      }\\r\\n    },\\r\\n    {\\r\\n      \\\"client_info\\\": {\\r\\n        \\\"mobilesdk_app_id\\\": \\\"1:378256963900:android:4e2cd7c1e03e60a5948639\\\",\\r\\n        \\\"android_client_info\\\": {\\r\\n          \\\"package_name\\\": \\\"com.beyondyounet.BeyondYounet.services\\\"\\r\\n        }\\r\\n      },\\r\\n      \\\"oauth_client\\\": [\\r\\n        {\\r\\n          \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n          \\\"client_type\\\": 3\\r\\n        }\\r\\n      ],\\r\\n      \\\"api_key\\\": [\\r\\n        {\\r\\n          \\\"current_key\\\": \\\"AIzaSyDyxZ3ImSaihYd05_ikmR_ht28w3HLyjKA\\\"\\r\\n        }\\r\\n      ],\\r\\n      \\\"services\\\": {\\r\\n        \\\"appinvite_service\\\": {\\r\\n          \\\"other_platform_oauth_client\\\": [\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-rp58ms513hvc5gcu6fiabr5b9075e3qu.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 3\\r\\n            },\\r\\n            {\\r\\n              \\\"client_id\\\": \\\"378256963900-7ng55udo4sk04vu5su6s8kof6ejurh1r.apps.googleusercontent.com\\\",\\r\\n              \\\"client_type\\\": 2,\\r\\n              \\\"ios_info\\\": {\\r\\n                \\\"bundle_id\\\": \\\"com.beyondyounet.BeyondYounet.providerapp\\\"\\r\\n              }\\r\\n            }\\r\\n          ]\\r\\n        }\\r\\n      }\\r\\n    }\\r\\n  ],\\r\\n  \\\"configuration_version\\\": \\\"1\\\"\\r\\n}\"}','third_party','live',0,'2022-07-16 04:56:01','2024-12-09 09:41:38'),
('b9525ca3-9c9e-432c-a2bb-a9f41c8a6b68','time_format','\"12\"','\"12\"','business_information','live',1,'2022-06-14 09:39:24','2024-11-18 02:26:55'),
('ba08f7c0-a233-43f5-a801-cd727e3e7de9','admin_order_notification','1','1','service_setup','live',1,'2022-07-20 06:04:23','2022-08-13 07:35:03'),
('bb1f5b40-88b8-45ac-a28e-53c32bd5c4de','deadline_warning_message','\"Your subscription ending soon. Please  renew to continue access\"','\"Your subscription ending soon. Please  renew to continue access\"','subscription_Setting','live',1,'2024-07-09 18:57:16','2024-07-09 18:57:16'),
('bbfd087c-eaa5-4868-8a69-3be87720ae86','top_description','\"LARGEST BOOKING SERVICE PLATEFORM\"','\"LARGEST BOOKING SERVICE PLATEFORM\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 15:36:11'),
('bc4ed6e1-2c7e-4c95-8c7f-fe547a317c1e','about_us_image','\"2024-11-27-6746b5b7de8ef.png\"','\"2024-11-27-6746b5b7de8ef.png\"','landing_images','live',0,'2022-10-03 17:37:45','2024-11-27 07:01:27'),
('bd122993-e4d6-427a-be42-713b3e9612a3','booking_cancel','{\"booking_cancel_status\":\"1\",\"booking_cancel_message\":\"Booking Cancel\"}','{\"booking_cancel_status\":\"1\",\"booking_cancel_message\":\"Booking Cancel\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('bde4ffab-e63d-435d-8854-46e4cfa49daf','booking_edit_service_add','{\"booking_edit_service_add_status\":\"1\",\"booking_edit_service_add_message\":\"Booking Edit Service Add\"}','{\"booking_edit_service_add_status\":\"1\",\"booking_edit_service_add_message\":\"Booking Edit Service Add\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('be65566f-dbbd-4f9c-b451-e93101d195c0','maintenance_duration_setup','{\"maintenance_duration\":\"until_change\",\"start_date\":null,\"end_date\":null}',NULL,'maintenance_mode','live',1,'2024-08-25 14:24:01','2024-08-25 14:24:01'),
('be927e91-0b1f-44b1-9ad8-73022910f717','new_service_request_arrived','{\"new_service_request_arrived_status\":\"1\",\"new_service_request_arrived_message\":\"New Service Request Arrived\"}','{\"new_service_request_arrived_status\":\"1\",\"new_service_request_arrived_message\":\"New Service Request Arrived\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('bef3c996-55b2-4371-8fe0-7204931d7478','usage_time','70','70','subscription_Setting','live',1,'2024-07-09 18:57:16','2024-07-09 18:57:16'),
('bf085f4a-1f5d-4ff2-b4de-2038ef70ad79','serviceman_assign','{\"serviceman_assign_status\":\"1\",\"serviceman_assign_message\":\"Serviceman Assign\"}','{\"serviceman_assign_status\":\"1\",\"serviceman_assign_message\":\"Serviceman Assign\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('bf12c77c-5274-408c-aa5f-f056db9ac3b8','provider_suspension_remove','{\"provider_suspension_remove_status\":\"1\",\"provider_suspension_remove_message\":\"Provider Suspension removed\"}','{\"provider_suspension_remove_status\":\"1\",\"provider_suspension_remove_message\":\"Provider Suspension removed\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('bf2b55c8-3ba0-4087-97b9-af101a5258d1','guest_checkout','0','0','service_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('c58ecce7-598f-4568-aa15-d875dfa12232','terms_and_conditions','\"<p>Demo terms and conditions<\\/p>\"',NULL,'pages_setup','live',1,'2022-08-06 04:02:24','2024-10-08 12:42:37'),
('c5d7ea4e-d51b-408f-8e57-58186d7d62f6','booking_edit_service_add','{\"booking_edit_service_add_status\":\"1\",\"booking_edit_service_add_message\":\"Booking Edit Service Add\"}','{\"booking_edit_service_add_status\":\"1\",\"booking_edit_service_add_message\":\"Booking Edit Service Add\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('c6331403-a1cd-4899-8d68-24a2ac323499','offline_payment_approved','{\"offline_payment_approved_status\":\"1\",\"offline_payment_approved_message\":\"Offline Payment Approved\"}','{\"offline_payment_approved_status\":\"1\",\"offline_payment_approved_message\":\"Offline Payment Approved\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('c68a9f47-7504-4fc9-b4f6-6a5aa274e4b8','business_name','\"Beyond-You.net\"','\"Beyond-You.net\"','business_information','live',1,'2022-06-14 09:39:24','2024-11-18 02:28:58'),
('c8dd2bcf-44e5-41e4-a121-fe4cc6f44e33','discount_cost_bearer','{\"bearer\":\"provider\",\"admin_percentage\":0,\"provider_percentage\":100,\"type\":\"discount\"}','{\"bearer\":\"provider\",\"admin_percentage\":0,\"provider_percentage\":100,\"type\":\"coupon\"}','promotional_setup','live',1,'2023-01-22 17:33:48','2023-01-22 17:33:48'),
('cc84f94d-743d-4551-8981-2fec5a750e93','booking_complete','{\"booking_complete_status\":\"1\",\"booking_complete_message\":\"Booking Complete\"}','{\"booking_complete_status\":\"1\",\"booking_complete_message\":\"Booking Complete\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('cccc6210-ceb8-431a-a676-e4ad322ef32d','loyalty_point','{\"loyalty_point_status\":\"1\",\"loyalty_point_message\":\"Loyalty Point\"}','{\"loyalty_point_status\":\"1\",\"loyalty_point_message\":\"Loyalty Point\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('cd0a7610-8c1a-49b1-a007-44560f69b7d8','storage_connection_type','\"local\"','\"local\"','storage_settings','live',1,'2024-07-07 16:15:01','2024-07-07 16:15:01'),
('cd206dd3-6d91-4608-8bc5-9be80cbf2e42','top_sub_title','\"Get all services from one App.\"','\"Get all services from one App.\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 15:36:11'),
('cfb57339-dc26-48f0-9815-896aebee243f','features','[{\"id\":\"54fc434a-b953-4b90-97e7-c6d7fae28f41\",\"title\":\"GET YOUR SERVICE 24\\/7\",\"sub_title\":\"Visit our app and select your location to see available services near you\",\"image_1\":\"2023-08-31-64ef2e92e47c3.png\",\"image_2\":\"2023-08-31-64ef2e92e8b41.png\"}]','[{\"id\":\"54fc434a-b953-4b90-97e7-c6d7fae28f41\",\"title\":\"GET YOUR SERVICE 24\\/7\",\"sub_title\":\"Visit our app and select your location to see available services near you\",\"image_1\":\"2023-08-31-64ef2e92e47c3.png\",\"image_2\":\"2023-08-31-64ef2e92e8b41.png\"}]','landing_features','live',1,'2022-10-03 17:26:57','2023-08-30 18:58:36'),
('d0c18642-cfa4-4178-8e25-a3a58a6cdff3','admin_payable','{\"admin_payable_status\":\"1\",\"admin_payable_message\":\"Admin Payable\"}','{\"admin_payable_status\":\"1\",\"admin_payable_message\":\"Admin Payable\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('d27c7746-520f-470d-a3e0-6ac0b427ae61','registration_title','\"REGISTER AS PROVIDER\"','\"REGISTER AS PROVIDER\"','landing_text_setup','live',0,'2022-10-03 15:36:11','2022-10-03 15:36:11'),
('d2b531d9-4cf1-4f7c-b96f-395856f5003d','google_map','{\"party_name\":\"google_map\",\"map_api_key_client\":\"AIzaSyA7buZN5cgWgLzlAEUHJkTi8e5d7tg5ksg\",\"map_api_key_server\":\"AIzaSyA7buZN5cgWgLzlAEUHJkTi8e5d7tg5ksg\"}','{\"party_name\":\"google_map\",\"map_api_key_client\":\"AIzaSyA7buZN5cgWgLzlAEUHJkTi8e5d7tg5ksg\",\"map_api_key_server\":\"AIzaSyA7buZN5cgWgLzlAEUHJkTi8e5d7tg5ksg\"}','third_party','live',0,'2022-09-14 19:49:51','2024-11-19 16:10:31'),
('d3ed9c30-4ce1-4c43-8016-e3a51cd74206','booking_schedule_time_change','{\"booking_schedule_time_change_status\":\"1\",\"booking_schedule_time_change_message\":\"Booking Schedule Time Change\"}','{\"booking_schedule_time_change_status\":\"1\",\"booking_schedule_time_change_message\":\"Booking Schedule Time Change\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('d42c3f11-c43f-48ab-849e-b950d90aea3d','widthdraw_request_approve','{\"widthdraw_request_approve_status\":\"1\",\"widthdraw_request_approve_message\":\"Withdraw Request Approve\"}','{\"widthdraw_request_approve_status\":\"1\",\"widthdraw_request_approve_message\":\"Withdraw Request Approve\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('d5ff36a8-634b-42a1-ab49-08375eeb21ac','footer_text','\"All rights reserved By @ Beyond-You.net\"','\"All rights reserved By @ Beyond-You.net\"','business_information','live',1,'2022-09-05 10:06:02','2024-11-18 02:28:58'),
('d683b185-6f67-4cd0-94f7-14d85f8da03a','booking_additional_charge','0','0','booking_setup','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('d8a4c244-0e6c-4511-a156-93db22a66b7e','phone_number_visibility_for_chatting','\"1\"','\"1\"','business_information','live',1,'2023-02-23 00:25:16','2024-11-18 02:28:58'),
('d9ecd0f6-aa05-42fe-b539-990618fca55f','booking_edit_service_quantity_decrease','{\"booking_edit_service_quantity_decrease_status\":\"1\",\"booking_edit_service_quantity_decrease_message\":\"Booking Edit Service Quantity Decrease\"}','{\"booking_edit_service_quantity_decrease_status\":\"1\",\"booking_edit_service_quantity_decrease_message\":\"Booking Edit Service Quantity Decrease\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('db386429-6982-4f46-82f9-08ec70f13f57','maximum_withdraw_amount','\"2\"','\"2\"','business_information','live',1,'2023-01-22 17:33:48','2024-11-18 02:26:55'),
('dbd7d22a-299e-49be-869e-efdcaf8ee7e4','web_url','\"https:\\/\\/beyond-you.net\\/\"','\"https:\\/\\/beyond-you.net\\/\"','landing_button_and_links','live',1,'2022-10-03 16:00:01','2024-12-09 11:17:52'),
('dbf71089-a769-4025-b971-307c08a6b455','service_man_can_cancel_booking','\"0\"','\"0\"','service_setup','live',0,'2022-07-20 06:04:21','2022-10-04 16:00:21'),
('dcb1d44b-f536-43ab-80f8-ea115f008abe','advertisement_paused','{\"advertisement_paused_status\":\"1\",\"advertisement_paused_message\":\"Advertisement Paused\"}','{\"advertisement_paused_status\":\"1\",\"advertisement_paused_message\":\"Advertisement Paused\"}','provider_notification','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('e28b7af4-2284-40bf-b28b-84baad4dc1a7','top_image_2','\"2024-11-17-673a2edc8df43.png\"','\"2024-11-17-673a2edc8df43.png\"','landing_images','live',0,'2022-10-03 16:06:00','2024-11-17 18:58:52'),
('e2bcae59-8095-4b14-8faf-ebe4a1a867cb','booking_ongoing','{\"booking_ongoing_status\":\"1\",\"booking_ongoing_message\":\"Booking Ongoing\"}','{\"booking_ongoing_status\":\"1\",\"booking_ongoing_message\":\"Booking Ongoing\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('e5362c47-db82-4437-86d8-626bfa78e264','booking_complete','{\"booking_complete_status\":\"1\",\"booking_complete_message\":\"Booking Complete\"}','{\"booking_complete_status\":\"1\",\"booking_complete_message\":\"Booking Complete\"}','serviceman_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('e79f70a2-7580-422c-9d07-8dc47e3961bc','free_trial_type','\"day\"','\"day\"','subscription_Setting','live',1,'2024-07-09 18:57:16','2024-07-09 18:57:16'),
('e80a7c3d-9371-4959-8463-c67973a42e56','business_email','\"leo.koesters@beyond-you.net\"','\"leo.koesters@beyond-you.net\"','business_information','live',1,'2022-06-14 09:39:24','2024-12-08 00:57:11'),
('e82e188c-d7de-478b-a83b-26c086b0576d','2factor','{\"gateway\":\"2factor\",\"mode\":\"live\",\"status\":\"0\",\"api_key\":\"data\"}','{\"gateway\":\"2factor\",\"mode\":\"live\",\"status\":\"0\",\"api_key\":\"data\"}','sms_config','live',0,'2022-06-08 08:56:14','2022-10-04 16:26:44'),
('e83290d3-d06b-47dd-b83c-5c8876ed0bd0','apple_login','{\"party_name\":\"apple_login\",\"status\":0,\"client_id\":null,\"team_id\":null,\"key_id\":null,\"service_file\":null}','{\"party_name\":\"apple_login\",\"status\":0,\"client_id\":null,\"team_id\":null,\"key_id\":null,\"service_file\":null}','third_party','live',1,'2023-08-30 13:09:23','2023-08-30 13:09:23'),
('ea0c3ccd-6db7-4b34-8f21-d0eb637cc47c','minimum_withdraw_amount','\"1\"','\"1\"','business_information','live',1,'2023-01-22 17:33:48','2023-08-30 19:38:42'),
('ea71998b-2399-44cc-8949-1786e753eb9c','country_code','\"DE\"','\"DE\"','business_information','live',1,'2022-06-14 09:39:24','2024-11-18 02:28:58'),
('eb2430a8-8d49-4bbe-b19d-1de8bd80be64','cash_after_service','1','1','service_setup','live',1,'2023-05-29 16:22:38','2023-05-29 16:22:38'),
('eb38f917-771c-48b8-8f65-dad3394a2b1b','schedule_booking','1','1','booking_setup','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('eb59a509-e7c2-499b-9c44-57554cbfe015','language_code','[\"Bengali\",\"English\",\"Arabic\",\"Abkhaz\",\"Afar\",\"Akan\",\"Albanian\",\"Amharic\"]','[\"Bengali\",\"English\",\"Arabic\",\"Abkhaz\",\"Afar\",\"Akan\",\"Albanian\",\"Amharic\"]','business_information','live',1,'2022-06-14 09:39:24','2022-07-23 07:26:01'),
('ee36e0ac-f41f-4e14-a77c-54e933939a72','referral_discount_type','\"flat\"','\"flat\"','customer_config','live',1,'2024-05-20 14:36:21','2024-05-20 14:36:21'),
('eeca1881-9a28-4be9-9c27-95f4e84e6aca','loyalty_point_value_per_currency_unit','0','0','customer_config','live',1,'2023-02-23 00:25:16','2023-02-23 00:25:16'),
('f290631d-bf48-45a8-90fc-98060f71d828','booking_accepted','{\"booking_accepted_status\":\"1\",\"booking_accepted_message\":\"Booking Accepted\"}','{\"booking_accepted_status\":\"1\",\"booking_accepted_message\":\"Booking Accepted\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('f4dd708c-4430-4bf1-8f10-797619fbdb7e','provider_subscription','0','0','provider_config','live',1,'2024-07-09 13:20:42','2024-07-09 13:20:42'),
('f4e0c496-d24f-4e3d-a533-74cb5c363e1a','firebase_message_config','{\"apiKey\":\"AIzaSyDbY3gXvxT5aGgrdF-o0c9TJuPWrU1fUIg\",\"authDomain\":\"beyondyou-c2149.firebaseapp.com\",\"projectId\":\"beyondyou-c2149\",\"storageBucket\":\"beyondyou-c2149.firebasestorage.app\",\"messagingSenderId\":\"378256963900\",\"appId\":\"1:378256963900:web:4ec0748689e58ace948639\",\"measurementId\":null}','{\"apiKey\":\"AIzaSyDbY3gXvxT5aGgrdF-o0c9TJuPWrU1fUIg\",\"authDomain\":\"beyondyou-c2149.firebaseapp.com\",\"projectId\":\"beyondyou-c2149\",\"storageBucket\":\"beyondyou-c2149.firebasestorage.app\",\"messagingSenderId\":\"378256963900\",\"appId\":\"1:378256963900:web:4ec0748689e58ace948639\",\"measurementId\":null}','third_party','live',0,'2024-11-19 18:52:18','2024-12-02 17:38:22'),
('f82d1978-8ab9-4ad3-a84f-050faa17436f','service_request_approve','{\"service_request_approve_status\":\"1\",\"service_request_approve_message\":\"Service Request Review\"}','{\"service_request_approve_status\":\"1\",\"service_request_approve_message\":\"Service Request Review\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('f99e20b3-dfb1-431f-891b-7d78c413e964','booking_refund','{\"booking_refund_status\":1,\"booking_refund_message\":\"Booking Refund Successfully\"}','{\"booking_refund_status\":1,\"booking_refund_message\":\"Booking Refund Successfully\"}','notification_messages','live',1,'2022-06-06 12:41:28','2022-09-05 15:17:05'),
('fb2792f7-d2f9-4560-83e0-61a8ed5d4aed','booking_cancel','{\"booking_cancel_status\":\"1\",\"booking_cancel_message\":\"Booking Cancel\"}','{\"booking_cancel_status\":\"1\",\"booking_cancel_message\":\"Booking Cancel\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('fc50433d-6dff-4a85-adaa-9bf1a27fc9ad','customized_booking_request','{\"customized_booking_request_status\":\"1\",\"customized_booking_request_message\":\"Customized Booking Request\"}','{\"customized_booking_request_status\":\"1\",\"customized_booking_request_message\":\"Customized Booking Request\"}','customer_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('fc7e71f7-c5d1-4c8a-aec4-ccbee608314d','deadline_warning','5','5','subscription_Setting','live',1,'2024-07-09 18:57:16','2024-07-09 18:57:16'),
('fc9ca7b4-4f21-4d45-a0cb-04693ebee4dc','provider_section_image','\"2024-11-27-6746c61ae2c38.png\"','\"2024-11-27-6746c61ae2c38.png\"','landing_images','live',0,'2022-10-03 17:17:01','2024-11-27 08:11:22'),
('fccca07e-50a5-4a6e-b509-5840a14fbc03','booking_schedule_time_change','{\"booking_schedule_time_change_status\":\"1\",\"booking_schedule_time_change_message\":\"Booking schedule time change\"}','{\"booking_schedule_time_change_status\":\"1\",\"booking_schedule_time_change_message\":\"Booking schedule time change\"}','provider_notification','live',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('fe386570-fee3-46bd-a9eb-1b34be33b7d6','loyalty_point_percentage_per_booking','0','0','customer_config','live',1,'2023-02-23 00:25:16','2023-02-23 00:25:16');
/*!40000 ALTER TABLE `business_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaigns` (
  `id` char(36) NOT NULL,
  `campaign_name` varchar(191) DEFAULT NULL,
  `cover_image` varchar(191) NOT NULL DEFAULT 'def.png',
  `thumbnail` varchar(191) NOT NULL DEFAULT 'def.png',
  `discount_id` char(36) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carts` (
  `id` char(36) NOT NULL,
  `customer_id` char(36) DEFAULT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `service_id` char(36) DEFAULT NULL,
  `category_id` char(36) DEFAULT NULL,
  `sub_category_id` char(36) DEFAULT NULL,
  `variant_key` varchar(191) DEFAULT NULL,
  `service_cost` decimal(24,2) NOT NULL DEFAULT 0.00,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `discount_amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `coupon_code` varchar(255) DEFAULT NULL,
  `coupon_discount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `campaign_discount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `total_cost` decimal(24,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` VALUES
('04b583d0-5102-4543-a24b-17bd28bbf445','696b1360-b8ae-11ef-9411-c10a15e80c62',NULL,'f4d44b69-9b28-4c3c-8956-1c223367dd3a','5e5c0fdb-9ad7-4075-bcc1-d7523efde8c6','b4fcd6d4-ba80-4e20-9ee2-f07a8b1466c6','Variant-1',100.00,1,0.00,NULL,0.00,0.00,10.00,110.00,'2024-12-12 18:31:03','2024-12-12 18:31:03',1),
('6a846c66-c2f3-4caa-bbf6-fe576d7b36e6','813240f0-88a5-4d07-93ca-ad6592204768',NULL,'f4d44b69-9b28-4c3c-8956-1c223367dd3a','5e5c0fdb-9ad7-4075-bcc1-d7523efde8c6','b4fcd6d4-ba80-4e20-9ee2-f07a8b1466c6','Variant-1',100.00,1,0.00,NULL,0.00,0.00,10.00,110.00,'2024-12-26 19:07:19','2024-12-26 19:07:19',0),
('a2fba10a-6858-4235-aeb6-b3d19f5e1304','43ee3110-bbd0-11ef-941b-fdb6f9dab86c',NULL,'f4d44b69-9b28-4c3c-8956-1c223367dd3a','5e5c0fdb-9ad7-4075-bcc1-d7523efde8c6','b4fcd6d4-ba80-4e20-9ee2-f07a8b1466c6','Variant-1',100.00,20,0.00,NULL,0.00,0.00,200.00,2200.00,'2024-12-17 14:16:12','2024-12-17 14:16:12',1);
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `position` int(10) unsigned NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
('3c699893-51e2-4a43-b5e3-6c1f26643f76','0','Yoga','2024-11-27-6746a5fcd4224.png',1,NULL,1,1,'2024-11-27 05:54:20','2024-11-27 05:56:48'),
('5e5c0fdb-9ad7-4075-bcc1-d7523efde8c6','0','Psychotherapy','2023-08-31-64ef394fcd699.png',1,NULL,1,1,'2023-08-30 19:42:55','2024-11-29 14:12:18'),
('7e37386e-5374-4b89-a92b-4181fbead9f1','0','Meditation','2024-11-27-6746a5d1473c8.png',1,NULL,1,1,'2024-11-27 05:53:37','2024-11-27 05:56:46'),
('b3be2897-7b5a-4197-8070-ac5faa88fef3','0','Coaching','2024-11-27-6746a61b8d1a6.png',1,NULL,1,1,'2024-11-27 05:54:51','2024-11-27 05:56:51'),
('b4fcd6d4-ba80-4e20-9ee2-f07a8b1466c6','5e5c0fdb-9ad7-4075-bcc1-d7523efde8c6','Test Sub category','2023-08-31-64ef3983e4faa.png',2,'This is a fake description',1,0,'2023-08-30 19:43:47','2023-08-30 19:43:47');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_zone`
--

DROP TABLE IF EXISTS `category_zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_zone` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` char(36) NOT NULL,
  `zone_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_zone`
--

LOCK TABLES `category_zone` WRITE;
/*!40000 ALTER TABLE `category_zone` DISABLE KEYS */;
INSERT INTO `category_zone` VALUES
(1,'5e5c0fdb-9ad7-4075-bcc1-d7523efde8c6','a1614dbe-4732-11ee-9702-dee6e8d77be4',NULL,NULL),
(2,'7e37386e-5374-4b89-a92b-4181fbead9f1','a1614dbe-4732-11ee-9702-dee6e8d77be4',NULL,NULL),
(3,'3c699893-51e2-4a43-b5e3-6c1f26643f76','a1614dbe-4732-11ee-9702-dee6e8d77be4',NULL,NULL),
(4,'b3be2897-7b5a-4197-8070-ac5faa88fef3','a1614dbe-4732-11ee-9702-dee6e8d77be4',NULL,NULL);
/*!40000 ALTER TABLE `category_zone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_conversations`
--

DROP TABLE IF EXISTS `channel_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_conversations` (
  `id` char(36) NOT NULL,
  `channel_id` char(36) NOT NULL,
  `message` text DEFAULT NULL,
  `user_id` char(36) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_conversations`
--

LOCK TABLES `channel_conversations` WRITE;
/*!40000 ALTER TABLE `channel_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_lists`
--

DROP TABLE IF EXISTS `channel_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_lists` (
  `id` char(36) NOT NULL,
  `reference_id` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  `reference_type` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_lists`
--

LOCK TABLES `channel_lists` WRITE;
/*!40000 ALTER TABLE `channel_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_users`
--

DROP TABLE IF EXISTS `channel_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_users` (
  `id` char(36) NOT NULL,
  `channel_id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_users`
--

LOCK TABLES `channel_users` WRITE;
/*!40000 ALTER TABLE `channel_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_files`
--

DROP TABLE IF EXISTS `conversation_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conversation_files` (
  `id` char(36) NOT NULL,
  `conversation_id` char(36) NOT NULL,
  `stored_file_name` varchar(255) NOT NULL,
  `original_file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_files`
--

LOCK TABLES `conversation_files` WRITE;
/*!40000 ALTER TABLE `conversation_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_customers`
--

DROP TABLE IF EXISTS `coupon_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon_customers` (
  `id` char(36) NOT NULL,
  `coupon_id` char(36) DEFAULT NULL,
  `customer_user_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_customers`
--

LOCK TABLES `coupon_customers` WRITE;
/*!40000 ALTER TABLE `coupon_customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` char(36) NOT NULL,
  `coupon_type` varchar(191) DEFAULT NULL,
  `coupon_code` varchar(191) DEFAULT NULL,
  `discount_id` char(36) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cron_jobs`
--

DROP TABLE IF EXISTS `cron_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cron_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `send_mail_type` varchar(255) DEFAULT NULL,
  `send_mail_day` int(11) NOT NULL DEFAULT 1,
  `activity` varchar(255) DEFAULT NULL,
  `php_file_path` varchar(255) DEFAULT NULL,
  `command` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_jobs`
--

LOCK TABLES `cron_jobs` WRITE;
/*!40000 ALTER TABLE `cron_jobs` DISABLE KEYS */;
INSERT INTO `cron_jobs` VALUES
(1,'Subscription renewal reminder mail',NULL,1,NULL,NULL,NULL,0,'2024-10-08 12:42:37','2024-10-08 12:42:37','subscription_renewal_reminder'),
(2,'Free Trial End Mail',NULL,1,NULL,NULL,NULL,0,'2024-10-08 12:42:37','2024-10-08 12:42:37','free_trial_end'),
(3,'Subscription Time End Mail',NULL,1,NULL,NULL,NULL,0,'2024-10-08 12:42:37','2024-10-08 12:42:37','subscription_time_end');
/*!40000 ALTER TABLE `cron_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_settings`
--

DROP TABLE IF EXISTS `data_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_settings` (
  `id` char(36) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_settings`
--

LOCK TABLES `data_settings` WRITE;
/*!40000 ALTER TABLE `data_settings` DISABLE KEYS */;
INSERT INTO `data_settings` VALUES
('0689bba0-0de2-4820-902a-5b4840af7fe9','bottom_title','GET ALL UPDATES & EXCITING NEWS','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:04'),
('11c9071f-70e2-412b-ba73-73da0ae9f7cb','refund_policy','<p>Test Refund Policy</p>','pages_setup',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('2787bb42-2e6a-43a4-81f1-7aee084f7083','bottom_description','Subcribe to out newsletters to receive all the latest activty we provide for you','landing_text_setup',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('42a986a9-831b-4789-9ae4-26b8284a2017','top_title','Client Statisfaciton is our main moto','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:42'),
('514e21aa-ae56-447e-9f9d-a34d4995bb9e','cancellation_policy','<p>Test Cancellation Policy</p>','pages_setup',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('7f249215-5ee0-4a39-872e-3b3bd2634278','about_us','<div><a href=\"http://beyond-you.net/\">Beyond-You.net</a> has the mission to make mental healthcare more accessible and affordable (whilst ensuring quality) and to strengthen psychological research. To create a mental healthcare ecosystem, we will combine online therapy, data analytics, AI, and digital therapy. Establishing a mental healthcare ecosystem is our vision.</div>\r\n<div><br>Our first product is an online therapy and mental health community app.&nbsp;</div>\r\n<div>Stay tuned for much more to come!</div>','pages_setup',1,'2023-11-28 15:33:21','2024-11-18 12:04:37'),
('875a27cc-5456-4573-a4af-cdf9d2e15c16','registration_title','REGISTER AS PROVIDER','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:04'),
('95b1d2d7-b656-4ea6-9347-79909a94e7dd','registration_description','Become a provider & Start your own business online with on demand service platform','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:04'),
('af772e44-2cea-4396-bb82-9dbc13eb8691','top_sub_title','Get all services from one App.','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:04'),
('c1f90ba8-3432-4478-8f35-7c992fa10aaf','privacy_policy','<p><strong>Privacy Policy for <a href=\"http://beyond-you.net/\">Beyond-You.net</a> Beta Test</strong></p>\r\n<p>Effective Date: 17th November 2024</p>\r\n<p>At <a href=\"http://beyond-you.net/\">Beyond-You.net</a>, we take your privacy seriously. This Privacy Policy outlines how we collect, use, and protect your personal information during the beta testing phase of the <a href=\"http://beyond-you.net/\">Beyond-You.net</a> mobile app (the \"App\"). By participating in our beta test, you agree to collect and use your information as described in this policy.</p>\r\n<h3>1. <strong>Information We Collect</strong></h3>\r\n<p>During the beta test of the App, we may collect the following types of data:</p>\r\n<ul>\r\n<li>\r\n<p><strong>Personal Information</strong>: When you sign up for the beta test, we may collect personal information such as your name, email address, and any other details you provide during registration.</p>\r\n</li>\r\n<li>\r\n<p><strong>Usage Data</strong>: We collect data on how you interact with the App, including crash logs, error reports, and other diagnostic data that help us improve the App.</p>\r\n</li>\r\n<li>\r\n<p><strong>Technical Data</strong>: This may include your IP address, device type, operating system, browser type, and other technical information related to your device or connection.</p>\r\n</li>\r\n<li>\r\n<p><strong>Location Data</strong>: If the App includes location-based features, we may collect information about your physical location with your consent.</p>\r\n</li>\r\n<li>\r\n<p><strong>Sensitive Data</strong>: Unless explicitly stated, we do not intend to collect sensitive data (e.g., health data) during the beta phase. We will obtain your explicit consent if we need to collect such data.</p>\r\n</li>\r\n</ul>\r\n<h3>2. <strong>How We Use Your Data</strong></h3>\r\n<p>The data we collect will be used for the following purposes:</p>\r\n<ul>\r\n<li>\r\n<p><strong>Improving the App</strong>: Monitor the performance of the app, identify and fix bugs, and make improvements based on your feedback.</p>\r\n</li>\r\n<li>\r\n<p><strong>Communication</strong>: To send you updates regarding the beta test, including changes, new features, and other relevant information about the App.</p>\r\n</li>\r\n<li>\r\n<p><strong>Support and Feedback</strong>: To respond to your inquiries and requests for technical support or assistance during the beta testing period.</p>\r\n</li>\r\n<li>\r\n<p><strong>Analytics and Research</strong>: To analyze how the App is used and improve the user experience based on aggregated data.</p>\r\n</li>\r\n</ul>\r\n<h3>3. <strong>Legal Basis for Data Processing</strong></h3>\r\n<p>The legal basis for processing your data is your <strong>consent</strong>, which you provide when you sign up for the beta test and agree to this Privacy Policy. In some cases, we may process your data based on our <strong>legitimate interests</strong> in improving the App and conducting user testing.</p>\r\n<h3>4. <strong>Data Sharing</strong></h3>\r\n<p>We may share your data with the following third parties:</p>\r\n<ul>\r\n<li>\r\n<p><strong>Service Providers</strong>: We may share your information with trusted third-party service providers who help us operate and improve the App (e.g., hosting services, and analytics platforms).</p>\r\n</li>\r\n<li>\r\n<p><strong>Business Transfers</strong>: If we are involved in a merger, acquisition, or sale of assets, your data may be transferred as part of the transaction.</p>\r\n</li>\r\n</ul>\r\n<p>We might sell your anonymized data to other organizations such as universities to support psychological and medical research. Anonymized data will be collected. We ensure that no identifiable personal information will be sold to third parties for research.&nbsp;</p>\r\n<h3>5. <strong>Data Retention</strong></h3>\r\n<p>We will retain your data only as long as necessary to fulfill the purposes outlined in this Privacy Policy, or as required by law.</p>\r\n<h3>6. <strong>Data Security</strong></h3>\r\n<p>We implement appropriate technical and organizational measures to protect your data against unauthorized access, disclosure, alteration, or destruction. However, no data transmission over the internet or data storage system can be guaranteed to be 100% secure.</p>\r\n<h3>7. <strong>Your Rights</strong></h3>\r\n<p>As a user, you have the following rights regarding your data:</p>\r\n<ul>\r\n<li>\r\n<p><strong>Access</strong>: You have the right to request access to the personal data we hold about you.</p>\r\n</li>\r\n<li>\r\n<p><strong>Correction</strong>: You can request that we correct any inaccurate or incomplete data.</p>\r\n</li>\r\n<li>\r\n<p><strong>Deletion</strong>: You may request that we delete your data, subject to certain legal exceptions.</p>\r\n</li>\r\n<li>\r\n<p><strong>Withdrawal of Consent</strong>: If we process your data based on consent, you may withdraw that consent at any time.</p>\r\n</li>\r\n<li>\r\n<p><strong>Objection and Restriction</strong>: You have the right to object to or restrict the processing of your data in certain circumstances.</p>\r\n</li>\r\n</ul>\r\n<p>If you wish to exercise any of these rights, please contact us at <a href=\"mailto:leo.koesters@beyond-you.net\">leo.koesters@beyond-you.net</a></p>\r\n<h3>8. <strong>Cookies and Tracking Technologies</strong></h3>\r\n<p>We use cookies and similar technologies to collect data on how you interact with the App. These technologies help us improve the App&rsquo;s functionality and user experience. You can manage your cookie preferences through your device settings.</p>\r\n<h3>9. <strong>Changes to This Privacy Policy</strong></h3>\r\n<p>We may update this Privacy Policy from time to time. Any changes will be posted on this page, and we will notify you of significant changes. We encourage you to review this policy periodically.</p>\r\n<h3>10. <strong>Contact Us</strong></h3>\r\n<p>If you have any questions or concerns about this Privacy Policy or the way we handle your personal data, please contact us at:</p>\r\n<ul>\r\n<li><strong>Email</strong>: <a href=\"mailto:leo.koesters@beyond-you.net\">leo.koesters@beyond-you.net</a></li>\r\n<li><strong>Address</strong>: Franz-Liszt-Stra&szlig;e 9, 50825 K&ouml;ln, Germany</li>\r\n</ul>\r\n<hr>\r\n<p>By participating in our beta test, you acknowledge that you have read and understood this Privacy Policy.</p>','pages_setup',1,'2023-11-28 15:33:21','2024-11-18 12:04:19'),
('c60d816a-3100-4d3e-8aba-013a0ef13639','about_us_description','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:04'),
('f4df4ad8-96be-4f99-a14e-6dc7c82035f8','top_description','LARGEST THERAPY SERVICE PLATFORM','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:04'),
('f4e72cf5-7e3f-40e0-a7b0-1185c62a65fa','about_us_title','WHO WE ARE','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:04'),
('f64ffa14-fb1c-47e6-8736-0da45af39785','terms_and_conditions','<p>Test Terms & Conditions</p>','pages_setup',1,'2023-11-28 15:33:21','2023-11-28 15:33:21'),
('f6516965-15da-4fd6-805d-7788c0121a5f','mid_title','SERVICE WE PROVIDE FOR YOU','landing_text_setup',0,'2023-11-28 15:33:21','2024-11-17 15:06:04');
/*!40000 ALTER TABLE `data_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_types`
--

DROP TABLE IF EXISTS `discount_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `discount_id` char(36) DEFAULT NULL,
  `discount_type` varchar(255) DEFAULT NULL,
  `type_wise_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_types`
--

LOCK TABLES `discount_types` WRITE;
/*!40000 ALTER TABLE `discount_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts`
--

DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `id` char(36) NOT NULL,
  `discount_title` varchar(191) DEFAULT NULL,
  `discount_type` varchar(191) DEFAULT NULL,
  `discount_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `discount_amount_type` varchar(191) NOT NULL DEFAULT 'percent',
  `min_purchase` decimal(24,3) NOT NULL DEFAULT 0.000,
  `max_discount_amount` decimal(24,3) NOT NULL DEFAULT 0.000,
  `limit_per_user` int(11) NOT NULL DEFAULT 0,
  `promotion_type` varchar(191) NOT NULL DEFAULT 'discount',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `start_date` date NOT NULL DEFAULT '2022-04-04',
  `end_date` date NOT NULL DEFAULT '2022-04-04',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts`
--

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_role_accesses`
--

DROP TABLE IF EXISTS `employee_role_accesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_role_accesses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` char(36) NOT NULL,
  `role_id` char(36) NOT NULL,
  `section_name` varchar(255) NOT NULL,
  `can_view` tinyint(4) NOT NULL DEFAULT 1,
  `can_add` tinyint(4) NOT NULL DEFAULT 0,
  `can_update` tinyint(4) NOT NULL DEFAULT 0,
  `can_delete` tinyint(4) NOT NULL DEFAULT 0,
  `can_export` tinyint(4) NOT NULL DEFAULT 0,
  `can_manage_status` tinyint(4) NOT NULL DEFAULT 0,
  `can_approve_or_deny` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `can_assign_serviceman` tinyint(4) NOT NULL DEFAULT 0,
  `can_give_feedback` tinyint(4) NOT NULL DEFAULT 0,
  `can_take_backup` tinyint(4) NOT NULL DEFAULT 0,
  `can_change_status` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_role_accesses`
--

LOCK TABLES `employee_role_accesses` WRITE;
/*!40000 ALTER TABLE `employee_role_accesses` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_role_accesses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_role_sections`
--

DROP TABLE IF EXISTS `employee_role_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_role_sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` char(36) NOT NULL,
  `role_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_role_sections`
--

LOCK TABLES `employee_role_sections` WRITE;
/*!40000 ALTER TABLE `employee_role_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_role_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `error_logs`
--

DROP TABLE IF EXISTS `error_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `error_logs` (
  `id` char(36) NOT NULL,
  `status_code` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `hit_counts` int(11) NOT NULL DEFAULT 0,
  `redirect_url` varchar(255) DEFAULT NULL,
  `redirect_status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `error_logs`
--

LOCK TABLES `error_logs` WRITE;
/*!40000 ALTER TABLE `error_logs` DISABLE KEYS */;
INSERT INTO `error_logs` VALUES
('08683814-1c8f-4943-9dd3-03e44e684d27',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=76e018ed78-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-76e018ed78-109951053&ct=t()&mc_cid=76e018ed78&mc_eid=c97993ad47',1,NULL,NULL,'2024-12-16 00:17:14','2024-12-16 00:17:14'),
('28e206c4-3f2a-4291-9276-cf78d722b0d9',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAaaNnLTw9MD6unLo9xh7N11ZKWws1BB09cjqfqOYuEFvQdbIoi_DGHyhIdQ_aem_MjkZKBX1seVqU9ngIliA9A',1,NULL,NULL,'2025-01-04 22:55:55','2025-01-04 22:55:55'),
('513e10fb-e10c-4fb2-af45-d89855b40892',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAaba3JcAr7i55aHlSIVUBZBEefnGuRPjt-Q2-oUBwOYwU4SVE7y3DRYkSUM_aem_Y974PoPGrBGUyewADgYcew',1,NULL,NULL,'2025-01-04 20:45:11','2025-01-04 20:45:11'),
('535e5b4f-ecc9-49ff-8152-7a2eef83a0c9',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=520e256c3b-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-520e256c3b-109570245&ct=t()&mc_cid=520e256c3b&mc_eid=8043f764e0',1,NULL,NULL,'2024-12-15 08:02:02','2024-12-15 08:02:02'),
('58508c1a-051d-4dc3-a418-a4f29503b957',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAaYY_Jz9M5lmhRsU4OHYtHVzyc9DOyaFi9SlWrf7GA9lAY_nfFEppdjquz8_aem_RIM5VGQWupHQBsvkGZWD8g',2,NULL,NULL,'2025-01-04 19:44:07','2025-01-04 19:44:07'),
('60388b6b-a1f0-4642-a7cf-374d05eac045',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=76e018ed78-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-76e018ed78-594976955&ct=t()&mc_cid=76e018ed78&mc_eid=5adec76d29',1,NULL,NULL,'2024-12-15 08:21:14','2024-12-15 08:21:14'),
('637434e8-2b20-4161-b82c-899487d36a88',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAaZltvIvOz4dMTp-ti64euSE40YWEIgjsmllf-w98TO5-YZ-BLsQgiVvSc4_aem_x0lJc_4ZtQqs8bpAMv9rvw',1,NULL,NULL,'2024-12-24 04:09:44','2024-12-24 04:09:44'),
('6eaac192-3dc6-40ac-bd61-9936e4c4575e',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAaYtoA0512nf3bK-H559OSzZOQvqYRGRVOJetLF_xSngXVWPOz899Lod96s_aem_2Gc55SkkSQkqm2DQ7btLmw',1,NULL,NULL,'2024-12-24 07:19:19','2024-12-24 07:19:19'),
('817eea1b-2ce9-4da0-8129-a6d2f3948b9f',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAaaNgImdhn2xlCDaF5ZLmfpMd_3yEmCzp9tpF2Ijgp4chASz47aOOiiW6Sg_aem__a0-B_8mgHq6bz-AYyx8lw',1,NULL,NULL,'2025-01-04 14:36:23','2025-01-04 14:36:23'),
('9b1c01c7-034b-4f20-b04e-05c420387443',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=76e018ed78-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-76e018ed78-594976722&ct=t()&mc_cid=76e018ed78&mc_eid=a507abb376',1,NULL,NULL,'2024-12-15 10:19:35','2024-12-15 10:19:35'),
('a530c561-1580-40d0-8420-3ccdb76d17ab',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=76e018ed78-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-76e018ed78-109949321&ct=t()&mc_cid=76e018ed78&mc_eid=217d6f2dd0',1,NULL,NULL,'2024-12-15 10:59:20','2024-12-15 10:59:20'),
('a7d48d51-de30-4eaa-a32f-b5d100fcae92',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=76e018ed78-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-76e018ed78-110064953&ct=t()&mc_cid=76e018ed78',1,NULL,NULL,'2024-12-15 08:11:04','2024-12-15 08:11:04'),
('ba30a11d-5290-4909-b4f3-09fd7e5f072c',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=520e256c3b-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-520e256c3b-110002921&ct=t()&mc_cid=520e256c3b&mc_eid=a7a23fce3d',1,NULL,NULL,'2024-12-16 10:17:22','2024-12-16 10:17:22'),
('be65c133-045f-4b0f-9253-3dae1190eb2f',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAabmaEjQFZ3_h62MMFbQomvs0b8ORwvxbwZHIXfAADs0YcL7LlNuQMSk0Po_aem__2T3dU1BnnhGz5jwmWTBkg',1,NULL,NULL,'2024-12-24 05:00:39','2024-12-24 05:00:39'),
('ef956fe7-199e-44d2-b9dd-d8e5cc1fb0be',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAabbJz7j3Vo43Os4RhGVO9l94RwkoX0fqbOWp-qx2RSfgx7FtBPJlwxrC4Y_aem_m4ShK62xyscBgpHIstSrZw',1,NULL,NULL,'2025-01-07 12:07:07','2025-01-07 12:07:07'),
('f0e2dd39-50b1-4367-87dc-83036e425f86',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=520e256c3b-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-520e256c3b-109627913&ct=t()&mc_cid=520e256c3b&mc_eid=66754939ef',1,NULL,NULL,'2024-12-15 08:01:58','2024-12-15 08:01:58'),
('f46b4e2c-1c41-48dc-ba36-f8d6d4c5059c',NULL,'https://beyond-you.net:/?fbclid=PAZXh0bgNhZW0CMTEAAaaTX0FIDGlnSFoRd8t7Zeax1XnQnvt5wJqGRP1_GRu2sp-rlzU4IK50QVE_aem_BlMawHWEAuito0qO0TPsng',2,NULL,NULL,'2025-01-04 19:40:06','2025-01-04 19:40:11'),
('f7213e95-a4ca-439a-be7b-518d4dd2be87',NULL,'https://beyond-you.net:/?utm_source=ALL+STARTPLATZ+USER&utm_campaign=520e256c3b-STARTPLATZ_CommunityUpdate_Dezember_2024_2&utm_medium=email&utm_term=0_be73f77d94-520e256c3b-110064773&ct=t()&mc_cid=520e256c3b&mc_eid=63d5e3f71e',1,NULL,NULL,'2024-12-15 10:37:40','2024-12-15 10:37:40');
/*!40000 ALTER TABLE `error_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` char(36) NOT NULL,
  `question` text DEFAULT NULL,
  `answer` text DEFAULT NULL,
  `service_id` char(36) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite_providers`
--

DROP TABLE IF EXISTS `favorite_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorite_providers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_user_id` char(36) NOT NULL,
  `provider_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite_providers`
--

LOCK TABLES `favorite_providers` WRITE;
/*!40000 ALTER TABLE `favorite_providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite_services`
--

DROP TABLE IF EXISTS `favorite_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorite_services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_user_id` char(36) NOT NULL,
  `service_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite_services`
--

LOCK TABLES `favorite_services` WRITE;
/*!40000 ALTER TABLE `favorite_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guests`
--

DROP TABLE IF EXISTS `guests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guests` (
  `id` char(36) NOT NULL,
  `guest_id` char(36) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `current_language_key` varchar(255) DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guests`
--

LOCK TABLES `guests` WRITE;
/*!40000 ALTER TABLE `guests` DISABLE KEYS */;
INSERT INTO `guests` VALUES
('009dbb12-ab6b-4de2-991b-e12877ff97e4',NULL,'176.6.52.85','2024-12-21 21:02:14','2024-12-21 21:02:14','en'),
('00d4a192-f13e-4f9a-9670-b1ab75b3b831',NULL,'88.128.92.33','2024-12-26 03:30:10','2024-12-26 03:30:10','en'),
('0189714c-1ca5-4e56-86cb-515c99d8ee01',NULL,'191.101.157.152','2024-12-09 11:58:55','2024-12-09 11:58:55','en'),
('01eba896-e76f-43d2-a4ea-0d57d5cddf7f',NULL,'52.164.202.181','2024-12-26 04:07:02','2024-12-26 04:07:02','en'),
('028fa4d3-bfcc-48d5-bf90-482ee404d03b',NULL,'181.215.176.25','2024-11-28 21:16:34','2024-11-28 21:16:34','en'),
('029414aa-d035-4bde-aad7-ceab42d4ec48',NULL,'37.201.153.99','2024-12-12 11:59:49','2024-12-12 11:59:49','en'),
('02ce40a6-de22-42ca-9646-b34c0f4c0806',NULL,'176.6.60.147','2025-01-06 14:08:53','2025-01-06 14:08:53','en'),
('02d9b41b-10ea-4764-af94-dc5ed1087ca4',NULL,'191.101.157.152','2024-12-09 11:01:57','2024-12-09 11:01:57','en'),
('03204667-812a-40c7-bb58-5eedaa740478',NULL,'84.119.18.216','2024-11-30 00:41:57','2024-11-30 00:41:57','en'),
('0390bcdd-79ad-450b-a894-728c51fdf349',NULL,'176.6.57.222','2024-12-09 11:03:02','2024-12-09 11:03:02','en'),
('0520bafb-7e1f-45b8-973b-db46268e6e29',NULL,'197.210.53.131','2024-12-28 18:00:58','2024-12-28 18:00:58','en'),
('05948e71-a933-4e0b-8817-60da24b42c63',NULL,'197.210.53.16','2024-12-19 20:04:36','2024-12-19 20:04:36','en'),
('059a4f5a-b501-4465-b631-b71308dc3308',NULL,'91.59.135.173','2024-12-12 08:58:23','2024-12-12 08:58:23','en'),
('077a9c31-75d2-437a-929e-a3f5b423b6b0',NULL,'37.201.194.175','2025-01-04 08:41:24','2025-01-04 08:41:24','en'),
('07b5d6de-ecb0-4df1-a1f4-b8e45ec40af3',NULL,'185.40.61.29','2025-01-04 21:21:21','2025-01-04 21:21:21','en'),
('07fd3d35-5e39-4f94-ac68-a75a3e3606d6',NULL,'37.201.153.99','2024-12-17 14:28:36','2024-12-17 14:28:36','en'),
('08825e9a-6231-4cbc-bb1b-8555dec76c23',NULL,'213.168.126.222','2024-12-22 07:15:19','2024-12-22 07:15:19','en'),
('08a113c8-83eb-46c4-ba82-4541883ac901',NULL,'37.201.153.99','2024-12-14 14:39:47','2024-12-14 14:39:47','en'),
('09228766-937d-49db-8a22-20f83601f120',NULL,'194.8.199.29','2024-12-23 18:31:42','2024-12-23 18:31:42','en'),
('09d40b66-2890-4eb1-8f83-78adb17a18c4',NULL,'93.230.28.250','2025-01-06 17:26:38','2025-01-06 17:26:38','en'),
('0a59407a-7dbe-442f-b8a3-083e9115a3e4',NULL,'212.185.237.22','2024-12-17 20:38:12','2024-12-17 20:38:12','en'),
('0aefebf5-ff4b-4d7f-aaf4-e2accb4cc51f',NULL,'46.114.108.138','2024-12-17 15:36:35','2024-12-17 15:36:35','en'),
('0b116cb4-328b-40b0-9932-03b9e2e389cf',NULL,'89.0.212.13','2024-12-12 18:28:12','2024-12-12 18:28:12','en'),
('0ba4fb28-7743-4103-9c3e-c808fe50df4d',NULL,'104.28.54.67','2024-12-09 12:51:20','2024-12-09 12:51:20','en'),
('0bb65399-048a-4e49-a9ef-e0e3e3173584',NULL,'103.157.239.114','2024-12-21 04:01:08','2024-12-21 04:01:08','en'),
('0bc072a0-12ad-4792-baa1-0ce44ad2661b',NULL,'194.8.199.29','2024-12-16 22:47:51','2024-12-16 22:47:51','en'),
('0c12f1be-e1fb-40a7-b124-e4f1d73b7d38',NULL,'194.8.199.28','2024-12-09 14:06:31','2024-12-09 14:06:31','en'),
('0c4fa0b6-b2f0-47ec-bb24-4ebe2e85d81c',NULL,'102.91.93.179','2025-01-03 14:20:17','2025-01-03 14:20:17','en'),
('0ca5c64e-ca74-4636-82f7-5ee02ea320a0',NULL,'102.89.23.30','2025-01-02 16:54:50','2025-01-02 16:54:50','en'),
('0d374d3f-c02f-4162-a927-43d426ffe0b8',NULL,'176.6.59.226','2024-12-13 17:31:45','2024-12-13 17:31:45','en'),
('0daed391-73d8-488c-8147-e666dc261f41',NULL,'46.114.109.167','2025-01-08 13:52:13','2025-01-08 13:52:13','en'),
('0e1623e7-b91e-442e-948b-21afbf5c0965',NULL,'80.145.245.155','2025-01-04 19:44:23','2025-01-04 19:44:23','en'),
('0e43f082-7ca2-46b4-8d61-5701b1b8de57',NULL,'176.6.60.147','2025-01-06 14:08:51','2025-01-06 14:08:51','en'),
('0ebea45b-2fa3-48c0-90c5-a2cb9ed669b8',NULL,'88.128.90.76','2024-12-22 04:03:48','2024-12-22 04:03:48','en'),
('0ec348e5-ef83-44fe-bf0f-d0d04494424c',NULL,'37.201.153.99','2024-12-17 14:12:42','2024-12-17 14:12:42','en'),
('0f077b51-7574-459b-85b1-4e59a7f8c4ab',NULL,'176.1.5.202','2024-12-23 23:40:36','2024-12-23 23:40:36','en'),
('0f0f5638-0965-43f8-ac6a-1e1ccca8aaf2',NULL,'102.91.102.252','2024-12-09 12:00:55','2024-12-09 12:00:55','en'),
('0f1fcc33-f7e1-4f17-b7be-c06e467d9cbe',NULL,'162.120.172.51','2024-12-23 10:14:37','2024-12-23 10:14:37','en'),
('0f285867-2f0f-408d-b7de-772f92df4687',NULL,'93.232.77.62','2024-12-22 10:25:13','2024-12-22 10:25:13','en'),
('0f4c519d-f3e0-4992-97f7-26225c9ebfeb',NULL,'74.125.212.224','2024-12-22 03:58:01','2024-12-22 03:58:01','en'),
('0fc85038-4996-4be6-9382-fcf73203ed93',NULL,'46.114.109.167','2025-01-08 13:47:16','2025-01-08 13:47:16','en'),
('0ffbda27-2b5d-483b-8856-046dd8a3d711',NULL,'81.185.163.11','2025-01-01 21:04:28','2025-01-01 21:04:28','en'),
('103e03eb-7406-4f47-9ef5-ffad89cdf86d',NULL,'197.210.53.131','2025-01-02 15:42:13','2025-01-02 15:42:13','en'),
('10565c79-2c09-4eaf-ac97-f83bed26e38a',NULL,'92.216.157.93','2024-12-12 13:26:35','2024-12-12 13:26:35','en'),
('10cd37fa-800f-4607-977b-9752f37f5419',NULL,'37.201.153.66','2024-12-14 12:01:29','2024-12-14 12:01:29','en'),
('115e24e0-4ebc-4cc0-90e5-ded546174fd3',NULL,'104.197.69.115','2024-12-12 16:37:44','2024-12-12 16:37:44','en'),
('12633062-93ce-4da3-b394-ffc0b5841c60',NULL,'60.91.48.37','2024-12-24 01:30:24','2024-12-24 01:30:24','en'),
('13ab3698-8b53-48a9-9604-b1c179feafd2',NULL,'18.201.130.187','2024-12-11 04:25:59','2024-12-11 04:25:59','en'),
('13c00574-2147-48a3-89eb-5a29a5bbcc91',NULL,'176.198.203.173','2024-12-15 10:59:27','2024-12-15 10:59:27','en'),
('14069ce7-cb70-4863-8fcf-d881b4debf52',NULL,'37.201.153.66','2024-11-28 22:44:41','2024-11-28 22:44:41','en'),
('1427c26a-cc18-421c-8952-a5686e62fc60',NULL,'78.48.38.107','2024-12-12 14:14:18','2024-12-12 14:14:18','en'),
('14821ba7-09f9-4456-b181-cc09abd11f10',NULL,'84.181.10.221','2024-12-24 07:19:19','2024-12-24 07:19:19','en'),
('14b3076b-ab92-476d-b596-7ead2eb9ce4b',NULL,'87.78.229.224','2025-01-04 19:40:12','2025-01-04 19:40:12','en'),
('14c65bd2-062f-42f3-9eef-049efb7f37dd',NULL,'46.114.109.167','2025-01-08 13:52:51','2025-01-08 13:52:51','en'),
('15218ab0-c1bb-4969-aa75-c5d7aa750f5c',NULL,'104.28.54.66','2024-12-09 12:18:00','2024-12-09 12:18:00','en'),
('15256b7d-4ef9-49bb-a4ff-3da450622f69',NULL,'94.31.92.254','2025-01-09 14:26:56','2025-01-09 14:26:56','en'),
('153ee8da-da1f-41d1-9d1d-55d53d37ab31',NULL,'89.0.49.58','2024-12-12 12:44:42','2024-12-12 12:44:42','en'),
('15576e1c-1dd4-4c89-b758-9f9438dfd2b2',NULL,'191.101.157.152','2024-12-09 12:13:17','2024-12-09 12:13:17','en'),
('15cd37f5-3b84-4bab-93ce-10b683e338f5',NULL,'181.215.176.25','2024-11-28 21:16:31','2024-11-28 21:16:31','en'),
('165a5b6e-a7ad-4a79-9e1d-3092ab89fed0',NULL,'37.201.194.175','2025-01-04 08:40:35','2025-01-04 08:40:35','en'),
('16624492-6b70-4fd9-883d-ac2310db5c05',NULL,'209.95.190.140','2024-12-28 15:14:25','2024-12-28 15:14:25','en'),
('1678e7ae-3d33-40a4-a978-d4db6127af4f',NULL,'191.101.157.152','2024-12-09 10:58:03','2024-12-09 10:58:03','en'),
('169bd77d-0e78-4139-8cfd-6f27480aed1b',NULL,'176.6.57.222','2024-12-09 13:13:48','2024-12-09 13:13:48','en'),
('16b1dc4b-f3ad-4ba6-a415-a2f86aad6020',NULL,'176.6.53.210','2024-12-08 17:40:09','2024-12-08 17:40:09','en'),
('172d01c6-5cfd-4811-88be-0a075a1b8094',NULL,'176.6.68.171','2024-12-09 13:40:31','2024-12-09 13:40:31','en'),
('17af6516-664f-4687-9e6a-2a5eae843cca',NULL,'88.128.92.33','2024-12-26 03:30:12','2024-12-26 03:30:12','en'),
('1844033e-4326-4376-95d6-5351c6927020',NULL,'191.101.157.152','2024-12-09 12:07:11','2024-12-09 12:07:11','en'),
('18e5abfd-890b-4429-a8b7-9a235b1d62ff',NULL,'78.35.74.152','2025-01-09 10:27:18','2025-01-09 10:27:18','en'),
('19445d9f-7795-4341-b449-00fca644d5d1',NULL,'94.31.117.166','2024-12-16 17:24:30','2024-12-16 17:24:30','en'),
('195be57e-290f-4cfc-94a2-19751be8e56c',NULL,'92.116.146.253','2024-12-12 12:47:53','2024-12-12 12:47:53','en'),
('19741ceb-8dc2-4010-a31e-ea10e0acb0c6',NULL,'61.247.177.142','2024-12-09 14:15:09','2024-12-09 14:15:09','en'),
('199b16f2-9e2b-4229-8a68-392679e64d36',NULL,'93.133.244.214','2024-12-21 03:37:38','2024-12-21 03:37:38','en'),
('19ce2b15-c23e-4b96-bf4c-33ac2657a953',NULL,'45.82.172.20','2025-01-02 08:28:51','2025-01-02 08:28:51','en'),
('19d01b44-0326-4776-b299-0653a5e1d8f1',NULL,'154.161.159.20','2024-12-22 00:38:39','2024-12-22 00:38:39','en'),
('1a8fb879-af32-4a47-9184-af6491099a46',NULL,'185.40.61.29','2025-01-04 20:56:03','2025-01-04 20:56:03','en'),
('1b0792ab-3bb1-4af9-8ee7-86f4b5292f8d',NULL,'37.201.153.66','2024-11-28 22:45:01','2024-11-28 22:45:01','en'),
('1b333a77-7b32-4791-a417-ccd2eb8c7c34',NULL,'109.192.106.166','2025-01-06 14:09:00','2025-01-06 14:09:00','en'),
('1b49f972-7a73-481b-924f-6b06707a57fd',NULL,'102.91.92.52','2024-11-24 17:48:57','2024-11-24 17:48:57','en'),
('1b5927dc-96cb-460c-b2f8-4cc65b7d6c20',NULL,'89.0.212.1','2024-12-12 16:15:18','2024-12-12 16:15:18','en'),
('1b69158a-94dd-404b-8ba5-d192d9969d4e',NULL,'37.201.153.99','2024-12-17 14:13:25','2024-12-17 14:13:25','en'),
('1b882566-4c47-45eb-8757-4b7a36371dc1',NULL,'191.101.157.152','2024-12-09 12:05:40','2024-12-09 12:05:40','en'),
('1b8da134-14d5-41bc-917f-84a67374e7f5',NULL,'154.159.237.94','2024-12-22 02:33:27','2024-12-22 02:33:27','en'),
('1bf55141-2dbf-4a45-9346-e015cb423e60',NULL,'78.35.74.152','2025-01-09 10:27:50','2025-01-09 10:27:50','en'),
('1c109e4a-949b-4c24-8d35-9dce1c70417e','43ee3110-bbd0-11ef-941b-fdb6f9dab86c','37.201.153.99','2024-12-16 18:10:34','2024-12-16 18:10:34','en'),
('1c58e60c-19ec-41cf-906d-444c2a153841',NULL,'66.249.66.160','2024-12-18 23:43:34','2024-12-18 23:43:34','en'),
('1c7493e5-b035-4ed9-8da6-7d1a582f74f0',NULL,'194.8.199.28','2024-12-09 13:28:28','2024-12-09 13:28:28','en'),
('1d437d70-fc75-438e-acf7-346c5a4a020d',NULL,'61.247.177.142','2024-12-15 09:48:40','2024-12-15 09:48:40','en'),
('1d63e523-8e45-44c9-90c5-040ef8008a0f','43ee3110-bbd0-11ef-941b-fdb6f9dab86c','37.201.153.99','2024-12-17 14:09:10','2024-12-17 14:09:10','en'),
('1db553b7-c388-434c-b07f-a3b003ecad0a',NULL,'104.197.69.115','2024-12-11 12:25:03','2024-12-11 12:25:03','en'),
('1e084f46-97b0-47eb-a5e6-5c809f694e33',NULL,'66.102.9.1','2025-01-06 20:08:48','2025-01-06 20:08:48','en'),
('1e1059b0-f69f-4e32-94e9-014777a35ff3',NULL,'197.210.85.243','2024-12-17 13:33:17','2024-12-17 13:33:17','en'),
('1e63d74a-c9c5-49ed-a740-f0eb69672e83',NULL,'102.91.93.92','2024-12-11 04:35:08','2024-12-11 04:35:08','en'),
('1ef4cab7-a4a5-4a43-a227-25b0b299dabd',NULL,'93.133.244.214','2024-12-21 03:37:36','2024-12-21 03:37:36','en'),
('1fd0ae8e-f74f-4b9c-bd42-1a59e27e8330',NULL,'109.42.176.173','2025-01-04 14:36:29','2025-01-04 14:36:29','en'),
('2024d3b1-98ef-4d7d-baf3-7e4b02c297cf',NULL,'88.128.90.17','2024-12-08 01:06:41','2024-12-08 01:06:41','en'),
('204f4834-882c-41e9-a0fb-f41c1e81f1bc',NULL,'176.6.64.43','2024-12-11 23:40:20','2024-12-11 23:40:20','en'),
('20545e50-05c3-4af2-b8ea-96e7156f9ab3',NULL,'37.201.153.99','2024-12-17 14:08:01','2024-12-17 14:08:01','en'),
('2055df6c-ca7a-49ae-8ee9-0aba1ebaba5d',NULL,'103.157.239.114','2024-12-30 08:18:58','2024-12-30 08:18:58','en'),
('205f96a5-45f5-4cb9-8b0d-766c24c8d6e4',NULL,'41.66.209.48','2024-12-20 23:10:10','2024-12-20 23:10:10','en'),
('20931c78-04b4-4e70-b777-188b012353e4',NULL,'176.6.67.11','2024-12-11 15:10:49','2024-12-11 15:10:49','en'),
('20932f08-4ca3-4ff9-8afb-41fbba392cff',NULL,'79.248.180.170','2025-01-02 11:13:15','2025-01-02 11:13:15','en'),
('21219090-55b3-4d36-8847-b893dbd30c38',NULL,'37.201.153.66','2024-11-28 22:45:09','2024-11-28 22:45:09','en'),
('216d88e6-5252-40a5-94dd-f677c4a250a7',NULL,'176.6.58.86','2024-12-15 14:14:41','2024-12-15 14:14:41','en'),
('21b868ca-7340-4432-9905-f72e70f7dae4',NULL,'37.201.153.99','2024-12-16 18:09:00','2024-12-16 18:09:00','en'),
('21eec716-622f-4a21-843b-c6e1cd12084e',NULL,'46.114.109.167','2025-01-08 13:53:49','2025-01-08 13:53:49','en'),
('224d3f01-ec0d-43f5-9ed4-a9919a7fbd6e',NULL,'176.1.5.202','2024-12-23 23:41:46','2024-12-23 23:41:46','en'),
('22515d20-0e38-4c6b-9a3e-ac826b89493d',NULL,'87.79.236.180','2024-12-07 23:34:36','2024-12-07 23:34:36','en'),
('233cc2a2-670f-4496-b92b-58ee5b0270f5',NULL,'109.43.113.3','2024-12-26 20:05:17','2024-12-26 20:05:17','en'),
('234d4d73-69b4-446e-826b-44a3bd6072a0',NULL,'185.209.196.218','2024-12-19 20:48:35','2024-12-19 20:48:35','en'),
('236f9887-100d-4fcf-b18c-95d9a931d581',NULL,'93.133.9.231','2024-11-24 19:24:56','2024-11-24 19:24:56','en'),
('238ae5d3-3c7d-4fc7-88b4-56236e4ea19d',NULL,'80.155.183.58','2025-01-08 14:29:44','2025-01-08 14:29:44','en'),
('239b71e7-f0d2-423e-8809-7cfe6230ae06',NULL,'31.17.29.134','2025-01-10 09:17:37','2025-01-10 09:17:37','en'),
('2410409b-34f4-4f70-b869-764ea6b7d1ab',NULL,'94.31.92.254','2025-01-09 14:25:23','2025-01-09 14:25:23','en'),
('2431277d-b9ce-4f23-aa96-9b93368d2f94',NULL,'176.6.49.48','2024-12-11 23:36:39','2024-12-11 23:36:39','en'),
('253e1119-30b4-4ca4-aac4-298fe77aa228',NULL,'197.211.61.35','2024-12-12 19:26:47','2024-12-12 19:26:47','en'),
('258172e5-ecb8-4830-8ee1-df85b462a999',NULL,'62.156.174.114','2025-01-03 09:25:22','2025-01-03 09:25:22','en'),
('25eefdae-d3d4-4d8b-8467-c99aecfa372c',NULL,'194.8.199.29','2024-12-16 21:47:43','2024-12-16 21:47:43','en'),
('2619027a-ea16-476a-b88c-e4445a725119',NULL,'89.0.209.63','2024-12-24 04:45:48','2024-12-24 04:45:48','en'),
('26c08b1b-1812-44c2-a6b0-374e0f649b62',NULL,'176.6.59.226','2024-12-13 17:31:32','2024-12-13 17:31:32','en'),
('26fdcb83-6996-44e9-9991-e0fc81f1c97d',NULL,'37.201.153.99','2024-12-17 14:13:29','2024-12-17 14:13:29','en'),
('27054b1b-6acc-45a0-bd76-fabe007b2b91',NULL,'194.8.199.29','2024-12-16 22:06:21','2024-12-16 22:06:21','en'),
('271f5d2d-4d1e-45b0-9b55-96e837f6b2e6',NULL,'102.88.43.132','2025-01-03 18:33:23','2025-01-03 18:33:23','en'),
('277c8a3e-8e78-460d-82c8-b8cb62fe57ba',NULL,'34.245.222.198','2024-12-15 08:01:32','2024-12-15 08:01:32','en'),
('277df0b1-0585-402c-90c0-1f138307f743',NULL,'46.114.109.224','2024-12-18 15:13:33','2024-12-18 15:13:33','en'),
('2816c308-02fa-4e74-8286-e4d05f1a2cec',NULL,'176.5.133.122','2024-12-25 03:05:45','2024-12-25 03:05:45','en'),
('28db8501-4802-4714-8a37-ab48b79e5dea',NULL,'93.133.244.214','2024-12-21 04:54:08','2024-12-21 04:54:08','en'),
('28ddf35e-c6b9-4158-ae26-567dfe073360',NULL,'66.249.81.102','2025-01-04 20:56:10','2025-01-04 20:56:10','en'),
('29449466-64f5-4d83-b638-2ca3e7010952',NULL,'62.156.174.114','2025-01-03 09:25:20','2025-01-03 09:25:20','en'),
('2982b6a7-5176-44a8-b870-0f236b9c668c',NULL,'78.35.74.71','2024-12-18 14:04:38','2024-12-18 14:04:38','en'),
('2a9ef0c1-2587-4a1d-85e7-6c4e9c3446ff',NULL,'191.101.157.152','2024-12-09 12:08:33','2024-12-09 12:08:33','en'),
('2b01ccb1-91d2-4c13-a171-af761c3923ca',NULL,'191.101.157.152','2024-12-09 11:16:28','2024-12-09 11:16:28','en'),
('2bc5cff1-9abb-4a54-b00b-ae76c134d1a6',NULL,'191.101.157.152','2024-12-09 11:08:58','2024-12-09 11:08:58','en'),
('2c4ec629-ce6b-4310-b51f-afbae9e889ec',NULL,'102.91.93.92','2024-12-11 04:38:23','2024-12-11 04:38:23','en'),
('2c67d47d-54a1-4e94-a818-f03e100b054b',NULL,'102.91.92.52','2024-11-24 17:53:15','2024-11-24 17:53:15','en'),
('2c8b598a-ec6f-458b-8896-574d80646bac',NULL,'37.201.153.99','2024-12-16 18:00:03','2024-12-16 18:00:03','en'),
('2c8c811b-fae1-4f24-ad01-d13acf903806',NULL,'89.0.212.1','2024-12-12 16:15:30','2024-12-12 16:15:30','en'),
('2ca9e12e-4545-4d91-b859-5e6e9d293d5c',NULL,'37.201.153.99','2024-12-16 18:15:27','2024-12-16 18:15:27','en'),
('2ce5f86d-2cc5-47f3-99f5-ee247af9fb2e',NULL,'194.8.199.28','2024-12-09 13:14:18','2024-12-09 13:14:18','en'),
('2d1d7329-cc8d-419f-aaca-f15a837b76f3',NULL,'88.128.90.22','2024-11-24 18:38:22','2024-11-24 18:38:22','en'),
('2d2c1254-aa41-4416-9f10-fbdb3f5dc93d',NULL,'94.31.92.254','2025-01-09 14:25:24','2025-01-09 14:25:24','en'),
('2db85653-5749-4e6d-9286-a38ee216ac35',NULL,'102.91.4.18','2024-12-02 15:05:41','2024-12-02 15:05:41','en'),
('2e093e30-86d7-4f56-b0fa-d99778b018b0',NULL,'46.114.108.115','2024-11-28 18:38:27','2024-11-28 18:38:27','en'),
('2e33e407-b099-4ea0-9815-7a78cb83b82d',NULL,'37.201.153.66','2024-12-14 12:01:48','2024-12-14 12:01:48','en'),
('2ebc34d4-f9b2-4721-a2c1-ae7cd5a45aa0',NULL,'176.5.133.122','2024-12-25 03:05:42','2024-12-25 03:05:42','en'),
('2ef5dd75-8314-4717-bffa-0f058d983a0b',NULL,'102.91.72.229','2024-12-17 15:49:26','2024-12-17 15:49:26','en'),
('2f661e14-1956-4921-b17b-c62ec145b1e8',NULL,'154.161.158.121','2024-12-22 15:27:45','2024-12-22 15:27:45','en'),
('2f82e983-227c-4dc4-a7f0-85d0905f049d',NULL,'92.40.176.71','2024-12-22 03:56:50','2024-12-22 03:56:50','en'),
('2f988724-9e04-4d5c-b0fc-7b6979bd137a',NULL,'102.91.93.92','2024-12-11 04:39:07','2024-12-11 04:39:07','en'),
('2f997865-fa89-4f66-bdd6-64ccf396f7fc',NULL,'37.201.153.99','2024-12-17 14:19:22','2024-12-17 14:19:22','en'),
('2fb683ae-f0e6-443c-ac18-03c74521bf41',NULL,'34.244.223.25','2024-12-16 23:52:10','2024-12-16 23:52:10','en'),
('30285142-fe33-402d-945e-d1a9105f0e59',NULL,'80.145.245.155','2025-01-04 19:44:45','2025-01-04 19:44:45','en'),
('30bbc8c4-4bd0-4111-a506-20e1b2dac4e9',NULL,'61.247.177.142','2024-12-09 07:41:29','2024-12-09 07:41:29','en'),
('30d2dffa-29b5-4de2-88e5-c79efc660bc4',NULL,'102.91.4.18','2024-12-02 15:18:04','2024-12-02 15:18:04','en'),
('3110efa5-c683-43a5-9fd4-bede0e969d58',NULL,'93.133.149.1','2024-12-28 15:20:34','2024-12-28 15:20:34','en'),
('31386933-c547-4ef0-8892-b6db31d17432',NULL,'185.40.61.29','2025-01-04 20:57:59','2025-01-04 20:57:59','en'),
('31490673-1144-4f8b-a211-712fcf724cc9',NULL,'34.244.223.25','2024-12-16 23:52:12','2024-12-16 23:52:12','en'),
('31ad9106-e46e-488b-add4-7760981e0083',NULL,'66.249.66.160','2024-12-18 23:43:43','2024-12-18 23:43:43','en'),
('321de264-45fc-4d8c-a3d9-b89842596a9e',NULL,'31.17.29.134','2025-01-10 09:22:11','2025-01-10 09:22:11','en'),
('33112f1a-e9b0-4939-b380-b380c4d8e840',NULL,'2.202.6.35','2024-12-15 08:11:04','2024-12-15 08:11:04','en'),
('33560153-c98b-44ef-966e-cb5926f1e47b',NULL,'102.89.23.30','2025-01-02 16:55:52','2025-01-02 16:55:52','en'),
('33ccc0d8-2485-4bfc-baf9-93f5667638ef',NULL,'88.128.94.29','2024-12-27 16:48:18','2024-12-27 16:48:18','en'),
('34056485-6a33-4be1-b2c4-b53b2f33e80c',NULL,'87.123.243.180','2024-12-25 07:27:02','2024-12-25 07:27:02','en'),
('3412c692-495d-4930-8293-ffb9f5cb451a',NULL,'88.128.90.76','2024-12-22 04:03:49','2024-12-22 04:03:49','en'),
('3433b4ae-22c9-43d1-8da4-89f6793b88e5',NULL,'41.90.5.54','2025-01-02 11:53:11','2025-01-02 11:53:11','en'),
('3440b1de-179a-44a2-87d1-0bf9e506d4f5',NULL,'102.91.92.119','2024-12-08 12:17:00','2024-12-08 12:17:00','en'),
('3578bed4-56e9-402d-bf36-c56d69ddf654',NULL,'37.201.154.94','2025-01-06 20:08:47','2025-01-06 20:08:47','en'),
('35d064c6-d080-4c4f-a9f7-63b9c1bffca0',NULL,'102.91.93.92','2024-12-11 06:30:05','2024-12-11 06:30:05','en'),
('36a7faff-a8a5-4485-b9b7-76febba9cee1',NULL,'102.91.92.52','2024-11-24 18:34:23','2024-11-24 18:34:23','en'),
('36c0ddb4-df4d-4383-8dc3-4a956c9566f9',NULL,'102.91.92.52','2024-11-24 17:50:58','2024-11-24 17:50:58','en'),
('36c674b9-74c2-4f5e-9e5b-35d662e7834b',NULL,'74.125.212.225','2024-12-23 05:55:29','2024-12-23 05:55:29','en'),
('37ffcaa7-4a7b-44e2-a13a-2ef993a1fcf9',NULL,'176.3.69.119','2024-12-26 20:35:36','2024-12-26 20:35:36','en'),
('38bd4bd7-1666-491f-9347-6c982014d785',NULL,'197.210.53.131','2025-01-02 16:10:45','2025-01-02 16:10:45','en'),
('396fd020-74c4-434d-8e7a-162d60a8cfe0',NULL,'92.216.157.93','2024-12-12 13:26:37','2024-12-12 13:26:37','en'),
('399bfb40-5bef-48bc-822f-94ef28cd188b',NULL,'46.114.108.138','2024-12-17 15:11:57','2024-12-17 15:11:57','en'),
('3a4aac9a-0b04-46cd-a1f1-8b91ff402a14',NULL,'102.89.45.211','2025-01-02 15:57:57','2025-01-02 15:57:57','en'),
('3a81ff36-16bf-492c-bbd5-80d35d43a9c3',NULL,'102.88.43.132','2025-01-03 18:35:46','2025-01-03 18:35:46','en'),
('3a950390-417b-4216-be24-f59f303fd81f',NULL,'106.221.178.206','2024-12-21 22:32:41','2024-12-21 22:32:41','en'),
('3c4322c2-3754-4a20-b300-87824ded5272',NULL,'5.180.61.237','2024-12-28 16:59:14','2024-12-28 16:59:14','en'),
('3c6c8f3d-73ac-471e-9e1c-b968898b67ba',NULL,'41.190.14.102','2024-12-19 10:18:52','2024-12-19 10:18:52','en'),
('3c9fabb2-10a9-4522-9921-d79d2d84d1e9',NULL,'34.245.222.198','2024-12-15 08:01:34','2024-12-15 08:01:34','en'),
('3ced1e3a-6547-4c7a-9f77-9dec9f903ce5',NULL,'191.101.157.152','2024-12-09 11:01:02','2024-12-09 11:01:02','en'),
('3d142f73-846a-4ad1-a509-69953b6d5960',NULL,'88.128.90.22','2024-11-24 18:37:07','2024-11-24 18:37:07','en'),
('3d427702-79b8-407d-9e93-4cb79b17ca67',NULL,'46.114.108.97','2025-01-03 14:44:09','2025-01-03 14:44:09','en'),
('3d6ec772-0f2d-45ff-990a-11344824d09c',NULL,'176.6.61.20','2024-12-28 01:15:55','2024-12-28 01:15:55','en'),
('3d99a476-88a9-4abe-a7b6-1e83f35ccca6',NULL,'194.8.199.28','2024-11-25 19:00:44','2024-11-25 19:00:44','en'),
('3ddfdecf-d238-42e6-bbd8-c9df93ba3143',NULL,'176.6.58.164','2024-12-12 15:21:42','2024-12-12 15:21:42','en'),
('3eaf5e06-539c-4dac-baf5-5dc0533e549d',NULL,'46.114.109.167','2025-01-08 13:48:16','2025-01-08 13:48:16','en'),
('3f1e669a-1b31-4b72-9118-9bbf51634e8f',NULL,'102.88.43.132','2025-01-03 18:35:07','2025-01-03 18:35:07','en'),
('3f4e801f-315f-459d-a584-2d1d6c65dd6a',NULL,'102.91.92.52','2024-11-24 18:33:32','2024-11-24 18:33:32','en'),
('4005abe1-67c0-442e-a079-4566957e07e2',NULL,'40.94.89.22','2024-12-29 19:20:18','2024-12-29 19:20:18','en'),
('400cab4f-3887-42f1-9825-0ce277bd4495',NULL,'102.91.92.52','2024-11-24 18:33:30','2024-11-24 18:33:30','en'),
('40497668-51bf-40cd-b861-00f169550b6c',NULL,'176.6.64.43','2024-12-11 19:02:56','2024-12-11 19:02:56','en'),
('40543e56-47da-45b1-9ad2-9b7022f370a6',NULL,'44.244.155.213','2024-12-24 05:00:27','2024-12-24 05:00:27','en'),
('40623e73-e7f1-4353-bade-b3aa80c68af3',NULL,'194.8.199.29','2024-12-16 21:56:42','2024-12-16 21:56:42','en'),
('4093e6bf-6e63-438f-b888-1dd2a83c7556',NULL,'88.128.88.14','2024-12-02 20:47:56','2024-12-02 20:47:56','en'),
('40a2c9e9-0a82-44d2-a643-df2fdef1797c',NULL,'37.201.153.99','2024-12-16 18:15:35','2024-12-16 18:15:35','en'),
('4106ea24-fb68-46f2-a860-1c50a3cd633d',NULL,'5.180.61.32','2024-12-19 21:18:53','2024-12-19 21:18:53','en'),
('4141f196-e7d8-4297-bc30-46a445c9661b',NULL,'194.8.199.29','2024-12-16 22:06:22','2024-12-16 22:06:22','en'),
('4199a9ca-2444-47fc-a2c9-24e529f2444c',NULL,'194.8.199.29','2024-12-16 21:55:52','2024-12-16 21:55:52','en'),
('42b18319-9f7f-4a16-96ab-77f8dfc3ad43',NULL,'46.114.109.167','2025-01-08 13:47:49','2025-01-08 13:47:49','en'),
('42f04e26-7d59-4c76-8379-16ce37a39b5f',NULL,'104.28.86.51','2025-01-10 02:05:40','2025-01-10 02:05:40','en'),
('43512282-d237-409d-b47a-41e312b1c00a',NULL,'37.201.153.99','2024-12-17 14:07:34','2024-12-17 14:07:34','en'),
('43674b98-6e99-4a84-b399-e53b918ebb22',NULL,'102.91.102.252','2024-12-09 12:03:40','2024-12-09 12:03:40','en'),
('445175e5-c0c0-48a5-ba43-3873e3f47fd1',NULL,'91.14.184.108','2024-12-26 19:02:29','2024-12-26 19:02:29','en'),
('449643ba-f89e-4cbe-9bce-8b3dd6aa3531',NULL,'88.128.90.17','2024-12-08 01:06:34','2024-12-08 01:06:34','en'),
('44c821c3-9846-4236-b11e-5f0091506254',NULL,'80.187.120.195','2024-12-12 19:08:49','2024-12-12 19:08:49','en'),
('45153176-f8b9-4eef-a4bf-a515215c14bb',NULL,'87.79.236.180','2024-12-07 23:34:51','2024-12-07 23:34:51','en'),
('471fabd7-7ced-46e9-9065-8752ebc03bb9',NULL,'37.201.153.99','2024-12-17 14:11:43','2024-12-17 14:11:43','en'),
('47373238-b854-48d3-982f-c77a5c25bad1',NULL,'80.145.245.155','2025-01-04 19:44:46','2025-01-04 19:44:46','en'),
('473f563c-f056-4634-a56c-cf655302e293',NULL,'93.133.21.151','2024-12-22 19:29:10','2024-12-22 19:29:10','en'),
('479c5c23-910b-4d1b-8b1a-c303c186d6ad',NULL,'191.101.157.152','2024-12-09 12:07:38','2024-12-09 12:07:38','en'),
('47f2fe5b-0fb3-4174-8a09-7e31c258d395',NULL,'88.128.90.58','2024-12-15 23:09:44','2024-12-15 23:09:44','en'),
('47f60a04-b11d-4fbe-a828-fa1282d68efe',NULL,'191.101.157.152','2024-12-09 11:01:05','2024-12-09 11:01:05','en'),
('4862a87c-493a-4aa9-8b09-9ce2f6a03855',NULL,'41.190.14.126','2024-12-17 18:27:13','2024-12-17 18:27:13','en'),
('48e9b11f-3589-4c7b-b70e-5b56d30b9117',NULL,'197.210.71.140','2024-11-24 07:47:59','2024-11-24 07:47:59','en'),
('49158906-8406-42ce-bad9-7e6006e96cdb',NULL,'37.24.218.14','2024-12-13 08:25:58','2024-12-13 08:25:58','en'),
('497c4284-d1ae-4bed-84fa-2fe178621225',NULL,'102.89.23.82','2025-01-06 11:45:51','2025-01-06 11:45:51','en'),
('498cd154-cc3f-49c8-b99e-5d2ebbe15ddf',NULL,'91.65.53.200','2025-01-02 14:54:58','2025-01-02 14:54:58','en'),
('49cdf020-b9de-40c4-93ea-2f833cd60e61',NULL,'46.114.108.97','2025-01-03 14:44:07','2025-01-03 14:44:07','en'),
('49ddb47a-465a-465e-a924-e0ccffc31bd5',NULL,'194.8.199.29','2024-12-19 22:14:54','2024-12-19 22:14:54','en'),
('4b206d99-ea64-408f-8995-9e41d84f6ba1',NULL,'91.14.184.108','2024-12-26 19:02:49','2024-12-26 19:02:49','en'),
('4b584a9b-e8bf-4bb5-ac29-eead54a7572e',NULL,'154.161.159.20','2024-12-22 00:38:41','2024-12-22 00:38:41','en'),
('4b6b1725-230a-4910-991e-047fd90e09a2',NULL,'102.91.92.52','2024-11-24 17:48:54','2024-11-24 17:48:54','en'),
('4b8f5470-2f9c-4c7b-a9b8-8c43251bba3d','696b1360-b8ae-11ef-9411-c10a15e80c62','89.0.212.13','2024-12-12 18:31:03','2024-12-12 18:31:03','en'),
('4b912d6c-fd45-4a6d-97d3-a8aefbab9ffb',NULL,'46.114.109.167','2025-01-08 13:47:48','2025-01-08 13:47:48','en'),
('4bb645e3-40ba-4949-b26c-89a8b07b060e',NULL,'87.78.173.70','2024-12-15 10:37:34','2024-12-15 10:37:34','en'),
('4befadc4-c65b-40e4-9fde-9c92b01e466b',NULL,'93.133.9.231','2024-11-24 19:24:15','2024-11-24 19:24:15','en'),
('4c1c7e26-e7a7-4cc9-a82e-dc81717fae49',NULL,'93.133.199.38','2024-12-21 00:30:34','2024-12-21 00:30:34','en'),
('4ca03c67-7ac7-42e1-882c-4f5fbe438f95',NULL,'13.79.156.49','2024-12-15 08:01:56','2024-12-15 08:01:56','en'),
('4cfc6302-1157-442a-a635-2c13448b4c1c',NULL,'194.8.199.28','2024-12-09 13:15:18','2024-12-09 13:15:18','en'),
('4cff2a93-1a13-45d1-9d45-1289e70d83a2',NULL,'89.0.49.58','2024-12-12 12:44:43','2024-12-12 12:44:43','en'),
('4d666624-fc2e-457d-9d2d-7f87e05564a8',NULL,'93.133.9.231','2024-11-24 19:24:15','2024-11-24 19:24:15','en'),
('4d73068a-35fc-4003-9f29-489b9b05397f',NULL,'102.88.43.132','2025-01-03 18:34:57','2025-01-03 18:34:57','en'),
('4dad841b-1417-4d43-b4ce-78a0944b1303',NULL,'88.128.88.14','2024-12-02 20:45:05','2024-12-02 20:45:05','en'),
('4e7d1727-28aa-4522-b70d-6de5b07f4af9',NULL,'102.90.100.70','2024-12-15 17:03:27','2024-12-15 17:03:27','en'),
('4e927094-ce83-43c2-a5fe-4377e6222ed1',NULL,'79.248.180.170','2025-01-02 11:13:17','2025-01-02 11:13:17','en'),
('4ee20aac-9fc8-483d-a3f3-c57a9d876c4a',NULL,'176.6.57.222','2024-12-09 11:03:11','2024-12-09 11:03:11','en'),
('4f034d00-6644-4222-b1d6-d2dbcf595e44',NULL,'191.101.157.152','2024-12-09 11:07:49','2024-12-09 11:07:49','en'),
('4f249429-36a1-4fef-a5e5-a66cb5802c78',NULL,'191.101.157.152','2024-12-09 11:02:56','2024-12-09 11:02:56','en'),
('4f39cdfe-a26d-41bf-aa25-39ef1f449483',NULL,'46.114.109.167','2025-01-08 13:52:12','2025-01-08 13:52:12','en'),
('4f40938a-483b-4f19-81f6-d69b62191744',NULL,'80.171.22.11','2024-12-13 10:26:05','2024-12-13 10:26:05','en'),
('4f601b6a-0733-4197-b7d2-c5e65530d24f',NULL,'102.91.93.92','2024-12-11 04:38:25','2024-12-11 04:38:25','en'),
('4fedd41a-77a0-4f01-ab34-8a1b17656dc9',NULL,'102.91.102.252','2024-12-09 12:10:06','2024-12-09 12:10:06','en'),
('501e7c1b-8cae-462d-a0ec-22ce1ba967b4',NULL,'37.201.153.99','2024-12-12 12:00:36','2024-12-12 12:00:36','en'),
('502a9be3-a143-4d67-b2c4-17ef5b06e946',NULL,'194.8.199.29','2024-12-16 22:06:38','2024-12-16 22:06:38','en'),
('507a5ef4-6ebe-42eb-9022-94082d2ad62c',NULL,'102.91.92.52','2024-11-24 18:32:51','2024-11-24 18:32:51','en'),
('50a690f0-cec1-4022-9497-a28225bc08a2',NULL,'102.91.93.92','2024-12-11 04:39:12','2024-12-11 04:39:12','en'),
('5198743e-3dcf-44f6-9d26-7886b36650a8',NULL,'37.201.153.99','2024-12-27 12:00:54','2024-12-27 12:00:54','en'),
('519fab09-dbcd-41cd-97d1-f568a3d38e81',NULL,'61.247.177.142','2024-12-09 14:15:04','2024-12-09 14:15:04','en'),
('51b87042-4a9e-46c0-87b7-d5ed07b74387',NULL,'176.6.50.186','2024-12-20 01:46:12','2024-12-20 01:46:12','en'),
('51c5883a-7788-4227-98bc-a789b8d01365',NULL,'197.211.61.35','2024-12-12 19:26:57','2024-12-12 19:26:57','en'),
('51d14858-6cd3-49de-b852-35fa29adef6b',NULL,'197.210.53.131','2025-01-02 16:10:43','2025-01-02 16:10:43','en'),
('51f015c3-ba1d-4f3d-af7d-1601574731f9',NULL,'176.6.64.43','2024-12-11 22:30:36','2024-12-11 22:30:36','en'),
('52529723-725d-408f-aad4-bfc11ba3f497',NULL,'176.6.50.186','2024-12-20 01:51:02','2024-12-20 01:51:02','en'),
('525569e0-786f-4f39-8db7-74eea490aeb1',NULL,'93.133.199.38','2024-12-21 00:29:05','2024-12-21 00:29:05','en'),
('52f11bd9-b140-490e-924d-1ccc83e22f5f',NULL,'104.28.86.51','2025-01-10 02:06:00','2025-01-10 02:06:00','en'),
('530477a9-32f4-451f-8dbd-5b48b37bd727',NULL,'88.128.90.22','2024-11-24 18:39:10','2024-11-24 18:39:10','en'),
('5346239a-40e5-4f4c-a374-fe37b5b76890',NULL,'104.28.54.47','2024-12-15 08:27:05','2024-12-15 08:27:05','en'),
('5373ab22-0596-485f-a4a1-fd940112412e',NULL,'92.116.146.253','2024-12-12 12:50:04','2024-12-12 12:50:04','en'),
('54198ae6-9814-4f22-9473-a3407dec1817',NULL,'84.119.18.216','2024-11-29 22:08:58','2024-11-29 22:08:58','en'),
('54263f07-2cb6-46b7-a653-811474d9296e',NULL,'197.211.61.116','2024-12-02 18:08:52','2024-12-02 18:08:52','en'),
('545e6f07-4e14-4d85-99e8-12b041b0f82b',NULL,'61.247.177.142','2024-12-09 14:15:11','2024-12-09 14:15:11','en'),
('5460e74c-1aaf-4eb2-9c5f-8244cd9e0a48',NULL,'176.6.64.43','2024-12-11 22:40:33','2024-12-11 22:40:33','en'),
('54a87813-ad7a-4c40-b136-6380fef27951',NULL,'194.8.199.29','2024-12-16 22:47:49','2024-12-16 22:47:49','en'),
('553d305a-52ab-4a62-b4ea-f23fd9dfce75',NULL,'104.28.54.46','2024-12-15 08:26:58','2024-12-15 08:26:58','en'),
('5660e5dc-8872-4ca5-b8e4-6202fe5f59f0',NULL,'176.5.133.122','2024-12-24 18:22:45','2024-12-24 18:22:45','en'),
('56b95d70-9965-4ebb-8374-d28aedf583c4',NULL,'102.89.45.211','2025-01-02 16:11:29','2025-01-02 16:11:29','en'),
('56da4e12-c6ce-43f5-9bb8-394760b309f2',NULL,'88.128.90.22','2024-11-24 18:36:19','2024-11-24 18:36:19','en'),
('57083ec4-40c4-47ff-892c-dacf5124fb1f',NULL,'194.8.199.28','2024-11-25 19:00:29','2024-11-25 19:00:29','en'),
('572a1b71-3a71-41f4-904c-4423b3150229',NULL,'88.128.90.22','2024-11-24 18:40:12','2024-11-24 18:40:12','en'),
('573f3ff5-5baf-4b27-b841-0896a09ebe04',NULL,'212.185.237.22','2024-12-20 11:01:08','2024-12-20 11:01:08','en'),
('5764b38e-729e-4688-be17-501068b7cd2c',NULL,'93.230.28.250','2025-01-06 17:26:36','2025-01-06 17:26:36','en'),
('577ee985-e2c4-40af-8141-dfac58070f46',NULL,'176.6.49.48','2024-12-11 23:37:01','2024-12-11 23:37:01','en'),
('57a9baa7-3793-4155-88e5-6549a2d2df8c',NULL,'84.119.18.216','2024-11-30 00:41:50','2024-11-30 00:41:50','en'),
('57fbcc7d-a052-4801-ba56-1030c7382c0d',NULL,'104.28.54.47','2024-12-15 08:21:23','2024-12-15 08:21:23','en'),
('5808856a-be85-40f4-8a3f-caba77b6ebdc',NULL,'102.89.45.211','2025-01-02 16:09:48','2025-01-02 16:09:48','en'),
('59a62ead-7e36-4524-8c59-da6a8ec67832',NULL,'89.0.209.63','2024-12-24 04:42:58','2024-12-24 04:42:58','en'),
('59c76359-d23e-4609-91f0-578e3f2d26a2',NULL,'80.155.183.58','2025-01-08 10:53:07','2025-01-08 10:53:07','en'),
('5aad9f42-504a-4214-8bf1-d60d791567be',NULL,'37.201.153.66','2024-11-24 22:15:12','2024-11-24 22:15:12','en'),
('5ac0d520-3336-4590-b2df-5ca30e78c785',NULL,'102.90.100.70','2024-12-15 17:03:16','2024-12-15 17:03:16','en'),
('5ae50059-0d5f-48ed-945f-0412be0c5907',NULL,'61.247.177.142','2024-12-10 05:41:26','2024-12-10 05:41:26','en'),
('5b006ad2-e74f-4e29-b197-4d18ab72e291',NULL,'109.43.240.79','2025-01-02 07:36:23','2025-01-02 07:36:23','en'),
('5b1a5fe2-8226-4ec6-9ddb-12833059e230',NULL,'176.6.59.226','2024-12-13 17:31:34','2024-12-13 17:31:34','en'),
('5b64686e-13fe-45a2-ba1a-0c1c2dafc411',NULL,'176.6.64.43','2024-12-11 23:18:33','2024-12-11 23:18:33','en'),
('5b861c0d-1d90-49c0-8f0d-cd19de557e84',NULL,'102.91.93.92','2024-12-11 04:35:05','2024-12-11 04:35:05','en'),
('5b93493d-a6cc-4500-804f-0af24b6c9545',NULL,'92.116.25.177','2025-01-09 10:41:31','2025-01-09 10:41:31','en'),
('5b94d13a-27c2-4cbf-a746-0a4a03836131',NULL,'46.114.109.167','2025-01-08 13:52:51','2025-01-08 13:52:51','en'),
('5b96a8ff-bd7b-4d37-b2cb-3eebaf3041a8',NULL,'176.6.53.44','2025-01-09 22:17:10','2025-01-09 22:17:10','en'),
('5ba1aa67-dea6-4628-b127-51aa996d41af',NULL,'5.145.130.18','2024-12-16 17:45:26','2024-12-16 17:45:26','en'),
('5baddbea-555b-452f-ac2c-d0f6f3ed6d71',NULL,'191.101.157.152','2024-12-09 12:17:11','2024-12-09 12:17:11','en'),
('5bd406ec-b418-4fbf-aeaf-49c2ee3acce8',NULL,'37.201.153.99','2024-12-16 18:09:34','2024-12-16 18:09:34','en'),
('5c2e5fe0-b05f-4a43-a8cd-6f34fecc2095',NULL,'88.128.90.58','2024-12-15 23:09:46','2024-12-15 23:09:46','en'),
('5c620d1a-85c9-4ac3-8c89-6199288d58b4',NULL,'191.101.157.152','2024-12-09 10:57:40','2024-12-09 10:57:40','en'),
('5c69d2dd-b57e-4212-a3a8-04f5d2f4b936',NULL,'191.101.157.152','2024-12-09 11:07:21','2024-12-09 11:07:21','en'),
('5ccce11b-ac22-4e12-b4e1-1496c1a254c6',NULL,'37.24.218.14','2024-12-13 08:26:00','2024-12-13 08:26:00','en'),
('5db424a3-1722-4bca-a9e8-d63a58756ae8',NULL,'88.128.90.22','2024-11-24 18:42:57','2024-11-24 18:42:57','en'),
('5e46ad32-4e5a-4e81-aadc-d144763bd9bf',NULL,'34.123.170.104','2024-12-29 18:59:40','2024-12-29 18:59:40','en'),
('5ed02af2-bac5-4d12-98a8-a1831eff51a5',NULL,'212.185.237.22','2024-12-20 11:01:09','2024-12-20 11:01:09','en'),
('5efb9527-08e9-47ca-a53d-f9c3c28d3142',NULL,'2.243.10.124','2025-01-10 02:09:31','2025-01-10 02:09:31','en'),
('5f20308f-e65e-4cff-8e7b-72c74d9c7a05',NULL,'178.202.191.63','2024-12-12 21:08:58','2024-12-12 21:08:58','en'),
('5fd1b031-8bc8-47c4-becb-eb1688e17c73',NULL,'88.128.90.22','2024-11-24 18:36:45','2024-11-24 18:36:45','en'),
('6053cc5f-cbb0-4402-bb9d-986044afc26a',NULL,'102.89.45.211','2025-01-02 16:32:45','2025-01-02 16:32:45','en'),
('6075edb6-f887-4c12-b448-6215fd8bef52',NULL,'176.5.137.134','2024-12-24 04:09:44','2024-12-24 04:09:44','en'),
('60d54fa4-2316-4008-a4cb-f70e62da1306',NULL,'79.232.232.174','2025-01-06 09:01:42','2025-01-06 09:01:42','en'),
('6146ee71-eedd-4ee0-9e8f-24173f48b2d3',NULL,'18.201.130.187','2024-12-11 04:25:57','2024-12-11 04:25:57','en'),
('6158375b-eb50-465e-bf56-477dae28eb47',NULL,'93.133.244.214','2024-12-21 04:54:49','2024-12-21 04:54:49','en'),
('615ed94f-9219-446f-ba65-953b7c1d2313',NULL,'176.5.133.122','2024-12-24 18:21:21','2024-12-24 18:21:21','en'),
('619607f7-36a3-47b3-b562-944efcdd9bed',NULL,'154.159.237.94','2024-12-22 02:34:11','2024-12-22 02:34:11','en'),
('61ade27b-1000-4cac-888d-eea6bab14eaf',NULL,'176.6.49.48','2024-12-11 23:36:41','2024-12-11 23:36:41','en'),
('6200322d-8632-485d-b05b-8eb1085be278',NULL,'88.128.88.14','2024-12-02 20:46:28','2024-12-02 20:46:28','en'),
('624970b4-af52-4701-a573-4654d736d15c',NULL,'87.123.243.180','2024-12-25 07:25:37','2024-12-25 07:25:37','en'),
('62d98467-008a-4fee-b387-55b796012174',NULL,'37.201.153.99','2024-12-16 18:15:31','2024-12-16 18:15:31','en'),
('638e0a76-fa3c-40d4-b8e8-9d623e24c572',NULL,'87.79.236.180','2024-12-07 23:34:45','2024-12-07 23:34:45','en'),
('63c0e3c9-560d-4c53-9399-e6e537f7409b',NULL,'89.0.209.63','2024-12-24 04:45:08','2024-12-24 04:45:08','en'),
('643ee6f8-4724-4ae0-b438-3562eaa9f1ee',NULL,'191.101.157.152','2024-12-09 11:01:12','2024-12-09 11:01:12','en'),
('648cb972-470d-4b32-aca7-ddaca4ae99ea',NULL,'176.6.53.210','2024-12-08 17:40:51','2024-12-08 17:40:51','en'),
('64b5aca6-743e-4504-822e-924d8953c8d9',NULL,'91.59.135.173','2024-12-12 08:58:14','2024-12-12 08:58:14','en'),
('64e4cda6-2c16-470f-8853-470d74e17904',NULL,'185.209.196.218','2024-12-19 20:47:48','2024-12-19 20:47:48','en'),
('65061a87-264d-4101-a1a9-6aeab3954de1',NULL,'80.187.124.116','2025-01-07 12:07:57','2025-01-07 12:07:57','en'),
('65487d6b-2396-422d-b05a-c13f1df64430',NULL,'102.91.93.92','2024-12-11 06:01:21','2024-12-11 06:01:21','en'),
('65c3d67c-523b-4ce3-8340-e9300849c767',NULL,'80.145.245.155','2025-01-04 19:44:07','2025-01-04 19:44:07','en'),
('664d0b9d-aa71-4892-a254-cfb7d9076838',NULL,'87.169.17.222','2024-12-10 17:16:30','2024-12-10 17:16:30','en'),
('665c70c5-bec2-4e24-a636-0cd4c0826bf3',NULL,'88.128.88.14','2024-12-02 20:47:37','2024-12-02 20:47:37','en'),
('666dcaf4-925d-4e4f-ac25-d028e691ff33',NULL,'49.47.216.96','2025-01-02 03:54:55','2025-01-02 03:54:55','en'),
('66d27e2b-54c8-43f7-a537-fe5122c9e835',NULL,'176.1.5.202','2024-12-23 23:43:42','2024-12-23 23:43:42','en'),
('675715cf-22a2-4197-9b05-3b216c02bb75',NULL,'102.88.43.132','2025-01-03 18:34:11','2025-01-03 18:34:11','en'),
('6845e71c-1469-4749-a7f1-809e9d6e1988',NULL,'176.6.64.43','2024-12-11 19:02:55','2024-12-11 19:02:55','en'),
('68c288f1-9d71-49fa-a3d4-2d7eac0712c2',NULL,'89.0.212.13','2024-12-12 18:27:52','2024-12-12 18:27:52','en'),
('68ca6b77-ba06-4c91-bb40-dfefe5b21b36',NULL,'152.58.212.141','2024-12-22 03:57:58','2024-12-22 03:57:58','en'),
('68ea3c8c-5aac-483a-b26e-515cdb87a73c',NULL,'102.91.92.52','2024-11-24 18:34:21','2024-11-24 18:34:21','en'),
('6903293d-9d67-4eef-bdd4-af2d6c5952c7',NULL,'40.94.97.78','2025-01-09 00:31:59','2025-01-09 00:31:59','en'),
('69365aaa-3cfe-4ae5-bcf5-5596b314eeca',NULL,'176.6.67.11','2024-12-11 15:11:12','2024-12-11 15:11:12','en'),
('697ec8d7-a17d-46a3-bf01-c42f53e7a8ba',NULL,'66.102.9.1','2025-01-06 20:08:47','2025-01-06 20:08:47','en'),
('6a34afc6-bb07-42c5-aa00-ef72eed7e381',NULL,'87.169.17.222','2024-12-10 17:16:29','2024-12-10 17:16:29','en'),
('6a35d144-188f-4558-82ff-2dc37ea66ed2',NULL,'31.17.29.134','2025-01-10 09:22:13','2025-01-10 09:22:13','en'),
('6ae18cf0-1ce0-4e9b-9d80-57c3ba52f2d3',NULL,'34.123.170.104','2025-01-05 16:28:04','2025-01-05 16:28:04','en'),
('6b00bc58-a9e8-4d2d-bff9-607cfa8ca3b0',NULL,'37.201.154.94','2025-01-06 20:09:05','2025-01-06 20:09:05','en'),
('6bd6fbe4-b10e-46e0-a13b-269720d4e058',NULL,'37.201.153.99','2024-12-17 14:28:35','2024-12-17 14:28:35','en'),
('6bf99104-d72f-4de6-bf39-2f96b9cb1f53',NULL,'87.78.229.224','2025-01-04 19:40:23','2025-01-04 19:40:23','en'),
('6c67607e-0979-4690-8ad6-c1afebe4ab24',NULL,'176.198.203.173','2024-12-15 10:59:23','2024-12-15 10:59:23','en'),
('6c6e6ba7-1785-491e-a160-fabc053ec13f',NULL,'46.114.109.167','2025-01-08 13:50:13','2025-01-08 13:50:13','en'),
('6c7d34c6-9d64-43a3-ba1f-d8bee65778f9',NULL,'106.221.178.206','2024-12-21 22:32:43','2024-12-21 22:32:43','en'),
('6c839d1f-d634-48af-9fdc-3cc9e394eda2',NULL,'194.8.199.29','2024-12-17 00:12:57','2024-12-17 00:12:57','en'),
('6ca51bc5-699d-4532-8be2-3ea6c564279a',NULL,'88.128.90.17','2024-12-08 00:53:17','2024-12-08 00:53:17','en'),
('6caa3ca8-66a6-47d3-915e-6158bbbcb61e',NULL,'102.91.102.252','2024-12-09 12:04:06','2024-12-09 12:04:06','en'),
('6cca0669-b896-47dd-9999-b9836abeb352',NULL,'37.201.153.66','2024-11-28 22:47:03','2024-11-28 22:47:03','en'),
('6d54fd2a-0034-4060-8900-d82371c32879',NULL,'92.116.25.177','2025-01-09 10:41:29','2025-01-09 10:41:29','en'),
('6d910925-223b-40bd-949d-d9118cea285a',NULL,'61.247.177.142','2024-12-10 05:41:34','2024-12-10 05:41:34','en'),
('6dd6df52-7e68-4ee9-82e5-bb1a5aa98dc0',NULL,'194.8.199.28','2024-11-25 19:00:31','2024-11-25 19:00:31','en'),
('6e5ae5d6-f4e9-437b-80bb-0d4c96705d74',NULL,'194.8.199.28','2024-12-09 13:31:25','2024-12-09 13:31:25','en'),
('6f0868c9-8a32-421d-8a17-cd51fcc3aec9',NULL,'80.155.183.58','2025-01-08 14:29:43','2025-01-08 14:29:43','en'),
('7028ff79-e255-49c4-954a-4b78e06b0f38',NULL,'37.156.73.127','2024-12-22 13:11:30','2024-12-22 13:11:30','en'),
('7095d479-a9e5-4113-bf7c-7a1faa5d02f1',NULL,'191.101.157.152','2024-12-09 12:13:15','2024-12-09 12:13:15','en'),
('7121ad82-ce16-4206-b2dc-0af10f2421a5',NULL,'102.91.93.92','2024-12-11 06:30:07','2024-12-11 06:30:07','en'),
('71991e8b-f65e-4dc2-89ef-910e3b90b32e',NULL,'89.0.212.13','2024-12-12 18:28:33','2024-12-12 18:28:33','en'),
('71bdf7cf-8018-4eb4-befa-95a8c089749d',NULL,'205.169.39.4','2024-12-08 10:23:58','2024-12-08 10:23:58','en'),
('71fedd88-cf10-47a4-9ace-c249e2d2922c',NULL,'194.8.199.29','2024-12-29 22:07:16','2024-12-29 22:07:16','en'),
('72057c9a-07e1-4b01-a384-1a0a22d3c6ca',NULL,'37.201.153.99','2024-12-16 18:07:46','2024-12-16 18:07:46','en'),
('7237e29e-232b-4811-9350-ba080f4f7a4f',NULL,'176.6.57.222','2024-12-09 13:13:51','2024-12-09 13:13:51','en'),
('7287018e-6292-42e5-aef6-a62e2b37a77a',NULL,'52.210.103.140','2025-01-09 21:08:36','2025-01-09 21:08:36','en'),
('728eb1be-b606-4b78-9da6-3844366aea91',NULL,'52.165.149.97','2025-01-09 22:17:36','2025-01-09 22:17:36','en'),
('73135b5b-2a27-4bf2-879a-d3357179816d',NULL,'91.65.53.200','2025-01-02 14:54:51','2025-01-02 14:54:51','en'),
('731b972c-0c7f-4aea-aee1-9cbcdb593bc6',NULL,'104.28.62.53','2024-12-12 19:07:58','2024-12-12 19:07:58','en'),
('7331c481-e9dc-4b54-8f20-209f29cdb09e',NULL,'194.8.199.29','2024-12-16 22:00:38','2024-12-16 22:00:38','en'),
('73503c4e-5ec3-415d-8c54-8cb5ceb4c1b8',NULL,'80.155.183.58','2025-01-08 10:52:31','2025-01-08 10:52:31','en'),
('736bddde-5818-43e5-8261-60fbf479904e',NULL,'102.91.4.9','2024-12-15 17:39:51','2024-12-15 17:39:51','en'),
('73a3cffc-bae5-4c0b-a4a6-8483addb19f9',NULL,'109.43.113.3','2024-12-26 20:04:37','2024-12-26 20:04:37','en'),
('73d35ee9-fffa-476c-b6fc-d906891de589',NULL,'89.0.212.1','2024-12-12 16:15:18','2024-12-12 16:15:18','en'),
('73d42986-870e-4202-9551-8d4cf8cae50b',NULL,'205.169.39.4','2024-12-08 10:23:59','2024-12-08 10:23:59','en'),
('7402a4e5-34f1-4f1b-adb4-82e852000951',NULL,'37.201.153.99','2024-12-17 14:13:08','2024-12-17 14:13:08','en'),
('7421db01-8869-4148-9a42-2a66d1dd97d6',NULL,'104.28.86.51','2025-01-10 02:05:41','2025-01-10 02:05:41','en'),
('74ce521b-de88-4f2a-b467-da3717e1781e',NULL,'194.8.199.29','2024-12-29 22:07:17','2024-12-29 22:07:17','en'),
('7537df44-a938-41fb-ae61-65aea622ee4a',NULL,'185.40.61.29','2025-01-04 20:56:06','2025-01-04 20:56:06','en'),
('768291a5-9f72-4c13-bf6b-ab09e9d6b313',NULL,'217.5.148.29','2024-12-16 10:17:21','2024-12-16 10:17:21','en'),
('7770ba2b-b9b8-42e7-a8aa-c55dd90e0b5e',NULL,'91.14.184.108','2024-12-26 19:02:28','2024-12-26 19:02:28','en'),
('77b0b1cf-955f-47fc-b9f8-479cd3f797af',NULL,'66.249.66.160','2024-12-18 23:43:23','2024-12-18 23:43:23','en'),
('77dc7d07-ea44-474e-aca4-0768b338d56b',NULL,'81.185.163.11','2025-01-01 21:04:31','2025-01-01 21:04:31','en'),
('77e55ce8-fad7-464d-b2de-68c47a2f94b0',NULL,'92.116.146.253','2024-12-12 12:49:28','2024-12-12 12:49:28','en'),
('78166887-2a4e-4f1c-bd00-aea7f396ab29',NULL,'79.232.232.174','2025-01-06 09:00:50','2025-01-06 09:00:50','en'),
('784e40d7-8e49-49cb-8f81-c168b5b1ee88',NULL,'88.128.90.22','2024-11-24 18:39:09','2024-11-24 18:39:09','en'),
('78b86ccd-23ca-42b0-a628-d3ee5de66723',NULL,'197.211.61.38','2024-12-11 15:12:32','2024-12-11 15:12:32','en'),
('78bc2d9d-1d2c-4321-8cf2-ec894c8cb420',NULL,'176.6.64.43','2024-12-11 23:40:18','2024-12-11 23:40:18','en'),
('791533bd-a639-4ea1-95a0-86c409ad3eaf',NULL,'176.6.57.222','2024-12-09 11:03:23','2024-12-09 11:03:23','en'),
('7a92dded-e9f0-4aa9-8b61-b98130a06381',NULL,'93.133.30.180','2024-12-23 17:05:54','2024-12-23 17:05:54','en'),
('7b03e9b6-5fa5-47e7-8eea-9f1624b624f9',NULL,'5.180.61.32','2024-12-19 21:18:55','2024-12-19 21:18:55','en'),
('7b9e884d-5a36-4f1e-8a09-6aa914a2126c',NULL,'5.180.61.237','2024-12-28 16:59:47','2024-12-28 16:59:47','en'),
('7c11b423-46d8-47c7-8d3b-fda5b1faf0bc',NULL,'176.6.64.43','2024-12-11 22:25:47','2024-12-11 22:25:47','en'),
('7c2a5a73-81b7-4b81-a211-3d3dcbd5cee4',NULL,'79.232.232.174','2025-01-06 09:00:31','2025-01-06 09:00:31','en'),
('7c743f4d-4108-4e1e-a55d-be08befe2074',NULL,'103.157.239.114','2024-12-30 08:18:56','2024-12-30 08:18:56','en'),
('7db5ab62-e3f3-41af-ae9d-0272a2244998',NULL,'102.89.23.30','2025-01-02 16:54:47','2025-01-02 16:54:47','en'),
('7e41c733-00e9-4fe5-8e02-f2338e8aa649',NULL,'185.40.61.29','2025-01-04 21:21:19','2025-01-04 21:21:19','en'),
('7ee4a20c-8726-4f1a-a245-0498258c0f67',NULL,'176.6.68.171','2024-12-09 13:40:33','2024-12-09 13:40:33','en'),
('7f0792f5-f6e7-49e0-836b-1b9ce62939ac',NULL,'41.190.14.102','2024-12-19 10:18:42','2024-12-19 10:18:42','en'),
('7f1eb175-5968-4ed3-9ca4-7df8e62fa655',NULL,'102.91.4.9','2024-12-15 17:39:03','2024-12-15 17:39:03','en'),
('7f73b088-5396-4620-9caf-bfb05a4ac5b1',NULL,'205.169.39.0','2025-01-06 06:41:22','2025-01-06 06:41:22','en'),
('7f999474-6531-4518-98e0-7d8ef8e33dca',NULL,'162.120.172.51','2024-12-23 10:16:07','2024-12-23 10:16:07','en'),
('7fcd42d9-6e49-4416-a0e0-e78cb6b5d485',NULL,'78.48.38.107','2024-12-12 14:14:16','2024-12-12 14:14:16','en'),
('7fe00fd9-a644-4748-b2dd-a5ffcbb9e5d6',NULL,'194.8.199.29','2024-12-17 00:12:56','2024-12-17 00:12:56','en'),
('7fefcd70-709f-426f-a5fe-2c0d38f7a670',NULL,'95.91.208.169','2025-01-09 10:42:00','2025-01-09 10:42:00','en'),
('800d77de-7492-46ea-b391-251d2891372d',NULL,'176.6.59.84','2024-12-14 14:05:34','2024-12-14 14:05:34','en'),
('80d74e75-c97c-436c-bd16-f1f138828b77',NULL,'194.8.199.29','2024-12-19 22:14:08','2024-12-19 22:14:08','en'),
('8140d772-4054-4f6e-a48f-ba00bc0bed7f',NULL,'194.8.199.29','2024-12-16 22:39:17','2024-12-16 22:39:17','en'),
('814d84a5-fc9b-4c6c-bf5c-f3b6f398fc04',NULL,'66.102.8.98','2025-01-04 19:40:31','2025-01-04 19:40:31','en'),
('8195f443-4651-4d33-8d9d-562b88193782',NULL,'79.248.5.179','2025-01-10 15:26:16','2025-01-10 15:26:16','en'),
('81a484c9-d725-41d0-a7a5-573fa1d0d8f6',NULL,'93.133.244.214','2024-12-21 04:54:10','2024-12-21 04:54:10','en'),
('81bfe185-ec5a-4d6c-a020-7823622c119a',NULL,'89.0.209.63','2024-12-24 04:46:45','2024-12-24 04:46:45','en'),
('81e9dbb2-c1f7-47d2-9ad7-8c051b4b460e',NULL,'66.249.81.103','2025-01-04 20:56:09','2025-01-04 20:56:09','en'),
('822201f1-b5d5-4e69-97db-c39fb2e7b8bd',NULL,'102.91.92.52','2024-11-24 17:53:15','2024-11-24 17:53:15','en'),
('8286819e-4794-4c1b-ad44-e8d05271698a',NULL,'89.0.212.1','2024-12-12 16:16:05','2024-12-12 16:16:05','en'),
('82a3460c-e9d0-456a-bf06-0df5d80c3416',NULL,'102.91.92.52','2024-11-24 18:32:48','2024-11-24 18:32:48','en'),
('8318d66e-3d00-44fa-94ce-f124fb2e2937',NULL,'46.114.108.138','2024-12-17 15:11:55','2024-12-17 15:11:55','en'),
('837158ac-b0e5-48f6-ba69-3c22ddcb37dd',NULL,'109.43.113.3','2024-12-26 20:05:39','2024-12-26 20:05:39','en'),
('83cf467f-4d20-4a5f-b163-039cb8774bd3',NULL,'61.247.177.142','2024-12-09 07:41:06','2024-12-09 07:41:06','en'),
('83dfa885-c809-42d3-8793-0dcadd02e61e',NULL,'194.8.199.28','2024-12-09 13:28:26','2024-12-09 13:28:26','en'),
('83ea93fe-8695-4a7a-905a-e57e00ac1097',NULL,'84.181.10.221','2024-12-24 07:19:25','2024-12-24 07:19:25','en'),
('842235b7-7135-4f52-8faf-6b8d540ed670',NULL,'209.95.190.140','2024-12-28 15:14:23','2024-12-28 15:14:23','en'),
('851ce582-84e8-49ad-baaa-885da4893bc5',NULL,'102.91.93.92','2024-12-11 06:09:37','2024-12-11 06:09:37','en'),
('85e74040-b224-4c52-9345-d807af8b095a',NULL,'147.161.165.106','2025-01-08 13:52:08','2025-01-08 13:52:08','en'),
('85ea5207-350b-48af-9560-20482137aebc',NULL,'78.48.38.107','2024-12-12 13:36:51','2024-12-12 13:36:51','en'),
('85f6c299-c30e-4360-8a6d-174678db8e2b',NULL,'80.187.120.195','2024-12-12 19:07:56','2024-12-12 19:07:56','en'),
('86216b78-c443-44e7-a2de-c85a163a8285',NULL,'176.6.64.43','2024-12-11 21:07:42','2024-12-11 21:07:42','en'),
('8686761a-e309-4dc8-857f-0776ff34a053',NULL,'20.169.168.224','2024-12-15 19:51:49','2024-12-15 19:51:49','en'),
('86b8b8db-5452-4dc2-bcc1-4f02ef561bc9',NULL,'84.119.18.216','2024-11-30 00:42:15','2024-11-30 00:42:15','en'),
('87845ef1-c362-4401-b014-fa0623ce26e2',NULL,'74.125.212.225','2024-12-22 03:57:59','2024-12-22 03:57:59','en'),
('87b07d2f-b67b-4905-9a74-da9a055fdf28',NULL,'152.58.212.141','2024-12-22 03:57:56','2024-12-22 03:57:56','en'),
('87c1e173-f59d-4a8c-aa71-503cfeb0e352',NULL,'87.79.22.196','2024-12-27 14:10:17','2024-12-27 14:10:17','en'),
('87ca785d-04ed-4ce4-b4d3-19e13a1230c5',NULL,'87.78.229.224','2025-01-04 19:40:05','2025-01-04 19:40:05','en'),
('87dc208c-1a6a-49ff-a397-01084e1c071e',NULL,'37.201.153.66','2024-11-28 22:44:35','2024-11-28 22:44:35','en'),
('88174d9b-4828-487c-9e16-19054ede2f66',NULL,'40.94.96.46','2024-12-04 17:30:37','2024-12-04 17:30:37','en'),
('88f1f789-1d5a-4fa2-b589-fea6de3a7c6e',NULL,'88.128.90.77','2024-12-15 23:51:50','2024-12-15 23:51:50','en'),
('89f972e4-2f7a-4ef1-a9c8-1918c2f1d2f8',NULL,'209.99.160.69','2024-12-21 04:05:16','2024-12-21 04:05:16','en'),
('8a1b85e2-0dcc-49d4-8d13-50f06df90f47',NULL,'197.210.53.131','2024-12-28 18:00:59','2024-12-28 18:00:59','en'),
('8aa9b18c-9aa0-48dd-8432-6960cbb57725',NULL,'176.7.142.210','2025-01-08 16:31:55','2025-01-08 16:31:55','en'),
('8abbe74f-bde2-4662-a933-21880fd792bb',NULL,'31.17.29.134','2025-01-10 09:17:50','2025-01-10 09:17:50','en'),
('8ad1a831-9ad3-4696-aae9-8ab567e5d5c1',NULL,'102.91.93.92','2024-12-11 06:23:10','2024-12-11 06:23:10','en'),
('8b908f5c-8fbf-4b4e-a48f-f15d219ce37e',NULL,'176.6.53.210','2024-12-08 17:40:24','2024-12-08 17:40:24','en'),
('8bbd390e-d61a-40dd-9eeb-cf7478be2be7',NULL,'87.169.17.222','2024-12-10 17:16:46','2024-12-10 17:16:46','en'),
('8bcfae4f-52ea-4863-8d39-e7ad1dc15859',NULL,'74.125.212.225','2024-12-23 05:55:28','2024-12-23 05:55:28','en'),
('8da12a6a-e189-417a-b618-eec4ddf7c38e',NULL,'109.42.176.173','2025-01-04 14:36:22','2025-01-04 14:36:22','en'),
('8db8f705-940f-48db-965d-08508086615a',NULL,'104.28.62.53','2024-12-12 19:08:23','2024-12-12 19:08:23','en'),
('8e713abf-32b4-4222-98d6-2b0ad49154df',NULL,'44.244.155.213','2024-12-24 05:00:29','2024-12-24 05:00:29','en'),
('8e9329cb-d2e2-48b4-9245-8b8b2b0d2c65',NULL,'102.91.72.229','2024-12-17 15:45:02','2024-12-17 15:45:02','en'),
('8f2f9092-316c-4ae4-a2aa-ae718acf12b1',NULL,'147.161.165.106','2025-01-08 13:52:12','2025-01-08 13:52:12','en'),
('8f8f4cd5-fe9d-4d82-8b95-b6da1e275a52',NULL,'176.6.61.20','2024-12-28 01:15:39','2024-12-28 01:15:39','en'),
('8fc7d15d-e0e5-4cba-823e-0e3d535d5b44',NULL,'88.128.90.74','2024-12-21 20:11:17','2024-12-21 20:11:17','en'),
('900bc64c-1099-4e60-8c2e-420b1fe2a4cc',NULL,'194.8.199.28','2024-12-09 13:14:20','2024-12-09 13:14:20','en'),
('902691b9-4777-47a0-a226-1e5ad770dfb4',NULL,'61.247.177.142','2024-12-09 14:21:01','2024-12-09 14:21:01','en'),
('90552159-ea35-4b0f-a1f5-66c893b8e7a3',NULL,'194.8.199.28','2024-12-09 14:06:30','2024-12-09 14:06:30','en'),
('909ad052-863e-4d1b-b825-089c765e9c51',NULL,'88.128.90.17','2024-12-08 00:53:05','2024-12-08 00:53:05','en'),
('90bc8850-0c07-4358-a9e0-b404a81b78d6',NULL,'176.6.60.147','2025-01-06 14:09:47','2025-01-06 14:09:47','en'),
('91d9f2b8-562e-4a96-b92e-fdd8f702e4ef',NULL,'5.145.130.18','2024-12-16 17:45:24','2024-12-16 17:45:24','en'),
('9216d5c8-587b-45c9-b3ce-e5ac0e30cb91',NULL,'89.0.209.63','2024-12-24 04:42:56','2024-12-24 04:42:56','en'),
('92525821-11ff-4d1c-bece-d50e54f2bcd6',NULL,'37.201.153.99','2024-12-17 14:13:02','2024-12-17 14:13:02','en'),
('927e0b50-808b-4c2a-957c-a93cc668b124',NULL,'176.6.67.11','2024-12-11 15:10:40','2024-12-11 15:10:40','en'),
('929d65a5-f820-49bd-80e0-5e63b81deb6a',NULL,'46.114.108.115','2024-11-28 18:38:38','2024-11-28 18:38:38','en'),
('937bb639-caf6-416f-9daa-2e9578bfa0c0',NULL,'52.164.202.181','2024-12-26 04:07:01','2024-12-26 04:07:01','en'),
('9475a2f5-a893-41c0-85cc-a4287f5c5201',NULL,'89.0.209.63','2024-12-24 04:46:52','2024-12-24 04:46:52','en'),
('94826290-7714-41c2-b518-f240237fb724',NULL,'194.8.199.29','2024-12-19 22:14:07','2024-12-19 22:14:07','en'),
('949e3817-ad14-44b3-8ed7-fb53cfae7ab3',NULL,'197.211.61.116','2024-12-02 18:08:58','2024-12-02 18:08:58','en'),
('94c80144-7485-47f8-aed1-8767c5dd9968',NULL,'217.253.67.113','2025-01-07 09:58:32','2025-01-07 09:58:32','en'),
('955f208a-c156-4fa0-bfe4-58ae488331c1',NULL,'37.201.154.94','2025-01-06 20:08:40','2025-01-06 20:08:40','en'),
('957a4a37-0d86-4952-b0b8-4c2a79fa0074',NULL,'93.133.244.214','2024-12-21 04:32:41','2024-12-21 04:32:41','en'),
('95ff117a-6946-4ed1-89c2-2eee24435689',NULL,'89.1.58.130','2024-12-13 10:03:51','2024-12-13 10:03:51','en'),
('974db2bb-46e2-493d-895b-40bac2e24986',NULL,'194.8.199.28','2024-12-09 13:31:27','2024-12-09 13:31:27','en'),
('97b8b35a-774b-4667-89cc-f96fd70126c2',NULL,'31.17.29.134','2025-01-10 09:17:36','2025-01-10 09:17:36','en'),
('97fe8f4f-157c-4e37-8347-c37093d6b568',NULL,'102.91.4.18','2024-12-02 15:05:04','2024-12-02 15:05:04','en'),
('982aac95-3f08-4a61-8772-d1833eb19571',NULL,'162.120.172.51','2024-12-23 10:16:11','2024-12-23 10:16:11','en'),
('986a6b2e-d88f-4767-8b48-5257dcb25e76',NULL,'154.161.158.121','2024-12-22 18:07:10','2024-12-22 18:07:10','en'),
('9896f310-cc4b-43a2-bc8f-67cc0e7855e9',NULL,'191.101.157.152','2024-12-09 12:05:46','2024-12-09 12:05:46','en'),
('9914797c-a3d9-4458-ab86-72eb698698d3',NULL,'93.133.9.231','2024-11-24 19:24:04','2024-11-24 19:24:04','en'),
('9917707c-a7bc-405b-9e8f-6ad8aca0a072',NULL,'197.210.53.131','2025-01-02 16:10:46','2025-01-02 16:10:46','en'),
('998a546d-e6fd-45aa-aad2-bb2896e0c346',NULL,'89.0.212.13','2024-12-12 18:29:03','2024-12-12 18:29:03','en'),
('9a421c46-a65d-4e83-82e9-728b7ed2bd5e',NULL,'92.40.176.71','2024-12-22 03:56:49','2024-12-22 03:56:49','en'),
('9a86fde3-7c7b-4a37-875d-da5277739462',NULL,'89.0.212.13','2024-12-12 18:27:51','2024-12-12 18:27:51','en'),
('9acabd9e-316f-4f08-8c32-6348ab28f86f',NULL,'197.210.85.243','2024-12-17 13:33:14','2024-12-17 13:33:14','en'),
('9b3de578-c18c-4161-9d0a-86e871134ccd',NULL,'194.8.199.29','2024-12-19 22:14:19','2024-12-19 22:14:19','en'),
('9b54cfc1-c73a-4d94-bd0b-607a60b04fd9',NULL,'191.101.157.152','2024-12-09 11:15:42','2024-12-09 11:15:42','en'),
('9c6f2b87-44e9-4313-af1e-bef6a0d74e71',NULL,'94.31.92.254','2025-01-09 14:26:55','2025-01-09 14:26:55','en'),
('9c710210-d8fa-40b0-bd34-f56b94abefd8',NULL,'88.128.90.58','2025-01-03 03:40:43','2025-01-03 03:40:43','en'),
('9ccaaadf-9ae4-4976-af06-544055b2a29b',NULL,'176.5.133.122','2024-12-24 18:22:06','2024-12-24 18:22:06','en'),
('9ddff2f8-cff5-4190-aec0-ce1ae2711835',NULL,'176.6.67.11','2024-12-11 15:09:34','2024-12-11 15:09:34','en'),
('9e31e822-f9e2-4675-9362-d60fb94a3068',NULL,'20.169.168.224','2024-12-15 19:51:48','2024-12-15 19:51:48','en'),
('9e660283-303b-4bb2-b661-ed41b411882f',NULL,'102.88.43.132','2025-01-03 18:36:29','2025-01-03 18:36:29','en'),
('9edc3ae5-8228-4a54-8a88-573be42e8ad3',NULL,'197.210.53.131','2024-12-28 18:03:31','2024-12-28 18:03:31','en'),
('9f72c9c6-d47e-4a6e-a07c-5d9df97542e1',NULL,'78.35.74.71','2024-12-18 14:05:21','2024-12-18 14:05:21','en'),
('9fc8dc01-3630-48ed-ba8d-05abb46ccb66',NULL,'176.7.142.210','2025-01-08 16:31:58','2025-01-08 16:31:58','en'),
('a01a8b08-c938-4cad-8710-14e898fd3f81',NULL,'205.169.39.25','2024-12-29 18:59:36','2024-12-29 18:59:36','en'),
('a02b2fb1-7424-4170-a8f8-3710787d49ab',NULL,'102.91.92.52','2024-11-24 18:33:33','2024-11-24 18:33:33','en'),
('a05f6df8-6af1-47ff-8dc2-fb67bef1731d',NULL,'102.91.92.52','2024-11-24 17:48:56','2024-11-24 17:48:56','en'),
('a0712c4e-7350-4619-9a4d-979b2629c242',NULL,'102.91.102.252','2024-12-09 12:09:56','2024-12-09 12:09:56','en'),
('a0810320-361d-4b33-9cb1-e5d5586ad614',NULL,'92.40.176.68','2024-12-22 03:57:11','2024-12-22 03:57:11','en'),
('a0bc32ac-67ba-4196-bbdf-188d88029a1c',NULL,'52.165.149.97','2024-12-07 21:48:04','2024-12-07 21:48:04','en'),
('a0c5f3ff-053a-4ac4-9efb-8b85ed5b5082',NULL,'80.155.183.58','2025-01-08 10:53:54','2025-01-08 10:53:54','en'),
('a14b03ce-68cb-4659-819c-e69ac6272f85',NULL,'102.91.72.229','2024-12-17 15:44:53','2024-12-17 15:44:53','en'),
('a1a61c6b-9de9-4493-9335-1a53b1562fac',NULL,'217.253.67.113','2025-01-07 09:58:30','2025-01-07 09:58:30','en'),
('a1a89c1d-d94f-4427-a524-c89ac5b7c667',NULL,'217.5.148.29','2024-12-16 10:17:37','2024-12-16 10:17:37','en'),
('a1b05eab-c40d-42ed-b0bc-054db1299e43',NULL,'37.201.153.99','2024-12-17 14:07:31','2024-12-17 14:07:31','en'),
('a1bf6729-684a-408e-8109-04df54e3eb6d',NULL,'102.91.93.179','2025-01-03 14:20:24','2025-01-03 14:20:24','en'),
('a1c13ba6-cc84-44de-970e-4e65033c7aaf',NULL,'102.91.72.229','2024-12-17 15:44:42','2024-12-17 15:44:42','en'),
('a1e11d8b-6b0a-44a0-959e-57a324be9145',NULL,'147.235.207.116','2024-12-22 06:43:37','2024-12-22 06:43:37','en'),
('a2313430-865e-4cba-a788-1c91245b8140',NULL,'102.91.93.92','2024-12-11 04:24:56','2024-12-11 04:24:56','en'),
('a261cb69-3997-4e0a-b0fd-ab2d4f39c06d',NULL,'66.249.66.160','2024-12-18 06:00:51','2024-12-18 06:00:51','en'),
('a2a16f99-3738-49d2-9979-fefde3d6ff2c',NULL,'191.101.157.152','2024-12-09 11:58:57','2024-12-09 11:58:57','en'),
('a2b75217-54f3-4918-bd12-8693cdf49547',NULL,'102.89.45.211','2025-01-02 16:09:46','2025-01-02 16:09:46','en'),
('a2c0c001-4796-4567-8eeb-94a3c4679375',NULL,'205.169.39.25','2024-12-29 18:59:37','2024-12-29 18:59:37','en'),
('a31b271a-4968-4594-8c19-1c44892adc28',NULL,'102.91.93.92','2024-12-11 06:01:19','2024-12-11 06:01:19','en'),
('a33c76d3-c98a-40ef-bb09-ea90cd44fc77',NULL,'37.201.153.66','2024-11-28 22:45:14','2024-11-28 22:45:14','en'),
('a38e9999-31fb-4cfc-8e34-5c4b35933616',NULL,'37.201.154.94','2025-01-06 20:08:49','2025-01-06 20:08:49','en'),
('a43ad6eb-aa80-4279-9d42-4c061e993527',NULL,'31.17.29.134','2025-01-10 09:17:48','2025-01-10 09:17:48','en'),
('a449f0f3-e46c-4642-b4b7-fd398f730564',NULL,'154.161.159.20','2024-12-22 00:39:35','2024-12-22 00:39:35','en'),
('a49b45c1-5085-4cf5-af6c-bf5e33acf06c',NULL,'102.91.4.18','2024-12-02 15:18:08','2024-12-02 15:18:08','en'),
('a4bfd94f-4101-4fea-b9c2-78952ca70b57',NULL,'84.119.18.216','2024-11-29 22:11:37','2024-11-29 22:11:37','en'),
('a4d0f108-e013-4b24-979e-1b82a971b13c',NULL,'88.128.90.22','2024-11-24 18:40:19','2024-11-24 18:40:19','en'),
('a5137b6f-e30c-4648-85eb-4ca0a53b63bc',NULL,'66.249.66.162','2024-12-25 00:17:09','2024-12-25 00:17:09','en'),
('a621109f-46ab-488d-bf0e-a574185d3242',NULL,'80.171.22.11','2024-12-13 10:26:04','2024-12-13 10:26:04','en'),
('a6ca8d0f-924a-488a-b004-c99baa2f1eb7',NULL,'37.201.153.66','2024-12-14 12:01:27','2024-12-14 12:01:27','en'),
('a6e0c8f1-a1e8-48a1-bd2a-9fdda788a96e',NULL,'92.226.2.135','2024-12-15 10:37:42','2024-12-15 10:37:42','en'),
('a792433d-05bb-46d0-ba2a-ebc085a8b796',NULL,'89.0.209.63','2024-12-24 04:45:44','2024-12-24 04:45:44','en'),
('a8119122-c929-47b5-9c3b-65921fd45ff8',NULL,'176.6.64.43','2024-12-11 19:54:02','2024-12-11 19:54:02','en'),
('a83036b5-7a86-483e-8103-da4044a209cc',NULL,'103.157.239.114','2024-12-17 06:06:22','2024-12-17 06:06:22','en'),
('a89ecbbd-3f23-48f2-9c24-a1074b9521ef',NULL,'102.91.102.252','2024-12-09 12:03:50','2024-12-09 12:03:50','en'),
('a93a31aa-d221-45bb-9267-61ca4254b7a3','43ee3110-bbd0-11ef-941b-fdb6f9dab86c','37.201.153.99','2024-12-17 14:16:12','2024-12-17 14:16:12','en'),
('a9b9d993-31bf-4d99-a75e-8b3b2a55f0a2',NULL,'102.91.92.52','2024-11-24 18:32:50','2024-11-24 18:32:50','en'),
('a9e72c2e-fcaf-4dc2-b439-759d22f69851',NULL,'66.102.8.97','2025-01-04 19:40:14','2025-01-04 19:40:14','en'),
('aa6c62d4-4f1f-4b46-b26d-f44372f8c65f',NULL,'52.169.230.217','2024-12-15 08:02:00','2024-12-15 08:02:00','en'),
('aafad424-42df-42b8-91db-1b6fe9a9d979',NULL,'197.211.61.38','2024-12-11 15:12:35','2024-12-11 15:12:35','en'),
('ab282370-43dc-4307-a06d-834c336d3e91',NULL,'38.150.99.4','2024-12-31 06:10:12','2024-12-31 06:10:12','en'),
('ab5739a7-97cf-42bc-b237-8b5e90a39984',NULL,'104.28.62.53','2024-12-12 19:07:59','2024-12-12 19:07:59','en'),
('abb6792e-b4e4-401e-ae00-47a8e7f788bf',NULL,'93.133.9.231','2024-11-24 19:24:01','2024-11-24 19:24:01','en'),
('acc6338b-1c8e-4936-aaf4-754bae8471b7',NULL,'88.128.94.29','2024-12-27 16:48:17','2024-12-27 16:48:17','en'),
('ad43c69a-d5c6-4e18-8b95-b0f3a7cdb97a',NULL,'102.91.92.119','2024-12-08 12:17:23','2024-12-08 12:17:23','en'),
('ad74ddc6-7242-4e70-b576-512a39d20bfe',NULL,'194.8.199.28','2024-12-09 13:14:42','2024-12-09 13:14:42','en'),
('ada554b7-5801-4ece-b575-b99223173ea1',NULL,'176.6.60.147','2025-01-06 14:09:25','2025-01-06 14:09:25','en'),
('adcf779b-405e-44dd-b140-2d61211fb6dc',NULL,'104.197.69.115','2024-12-11 12:25:01','2024-12-11 12:25:01','en'),
('ade7b698-ca51-4465-be90-e1d4509dcbf2',NULL,'176.6.58.164','2024-12-12 15:21:44','2024-12-12 15:21:44','en'),
('ae9e1dfa-43fe-4dc7-908a-c9df0b2478a1',NULL,'34.122.147.229','2024-12-14 15:14:10','2024-12-14 15:14:10','en'),
('aeaf104e-7fdc-4663-8222-72dfa4bc227e',NULL,'102.91.93.92','2024-12-11 06:19:19','2024-12-11 06:19:19','en'),
('af32d7e7-7023-4743-8857-1f156fd8450b',NULL,'197.211.61.38','2024-12-11 15:26:46','2024-12-11 15:26:46','en'),
('af68b4b4-a609-4bd7-9c28-0c61851735c6',NULL,'104.28.54.66','2024-12-09 12:18:32','2024-12-09 12:18:32','en'),
('af6bc183-d730-4d1f-9f28-a901a9b409b2',NULL,'197.211.61.38','2024-12-11 15:26:48','2024-12-11 15:26:48','en'),
('af9e6a07-aa52-409c-825c-f3c52d0171fa',NULL,'61.247.177.142','2024-12-10 05:41:32','2024-12-10 05:41:32','en'),
('b026fcef-1321-4a8b-a874-e2a95dd59e8d',NULL,'191.101.157.152','2024-12-09 12:17:15','2024-12-09 12:17:15','en'),
('b0622c02-5bd5-488d-b6c7-6cbdbe77971f',NULL,'37.201.153.99','2024-12-16 18:07:45','2024-12-16 18:07:45','en'),
('b0679f8c-785d-4a0a-b645-f9c2b1e8876d',NULL,'209.99.160.69','2024-12-21 04:05:14','2024-12-21 04:05:14','en'),
('b0911d09-cd6a-4824-ad91-b5794ef35e89',NULL,'102.91.93.92','2024-12-11 04:39:04','2024-12-11 04:39:04','en'),
('b1008318-b416-4463-a6dd-9e520beb3675',NULL,'88.128.90.22','2024-11-24 18:38:55','2024-11-24 18:38:55','en'),
('b131415c-767b-4a19-a745-acddee90f7b1',NULL,'154.161.159.20','2024-12-22 00:39:36','2024-12-22 00:39:36','en'),
('b1897084-028c-47e3-a7f0-2a6092f8be7d',NULL,'103.157.239.114','2024-12-21 04:00:58','2024-12-21 04:00:58','en'),
('b18eda17-13f6-4ff8-b6e1-2309a7696213',NULL,'89.0.209.63','2024-12-24 04:46:18','2024-12-24 04:46:18','en'),
('b1ae5e76-21bf-4b6b-b732-89c730351d6a',NULL,'176.6.67.11','2024-12-11 15:09:36','2024-12-11 15:09:36','en'),
('b1d0bed1-0731-4784-a51b-440a2e049436',NULL,'176.6.67.11','2024-12-11 15:11:11','2024-12-11 15:11:11','en'),
('b2b91511-3174-4942-b283-5b428e53ca34',NULL,'37.201.154.94','2025-01-06 20:10:42','2025-01-06 20:10:42','en'),
('b3819c17-80d0-4c00-88cf-0fbc70458673',NULL,'5.180.61.237','2024-12-28 16:59:13','2024-12-28 16:59:13','en'),
('b456c29c-bcd4-40f1-8c24-1258c814a57d',NULL,'178.197.202.234','2024-12-26 10:46:31','2024-12-26 10:46:31','en'),
('b479c050-6397-42fa-98e0-b541575e559c',NULL,'191.101.157.152','2024-12-09 11:15:40','2024-12-09 11:15:40','en'),
('b49e40fb-236d-4f78-8f42-5ddc12de3a83',NULL,'37.201.153.66','2024-11-24 22:14:53','2024-11-24 22:14:53','en'),
('b4b793f7-bbd9-4bc7-a5d7-befa8947b3bc',NULL,'102.91.72.229','2024-12-17 15:53:11','2024-12-17 15:53:11','en'),
('b4d7aee7-4a05-4c11-bb0c-f2903ccec7d1',NULL,'34.122.147.229','2024-12-14 15:14:08','2024-12-14 15:14:08','en'),
('b4e2d8a3-0116-44b7-8634-3441027a5548',NULL,'103.157.239.114','2024-12-17 06:06:20','2024-12-17 06:06:20','en'),
('b531b219-c92e-4294-80e1-a34c9694105f',NULL,'162.120.172.51','2024-12-23 10:14:35','2024-12-23 10:14:35','en'),
('b56848bd-a13a-4c71-bc3f-54d1eef0159f',NULL,'66.249.66.160','2024-12-11 17:58:35','2024-12-11 17:58:35','en'),
('b59a409e-0d6e-43a2-85be-5c7a8e3c5373',NULL,'66.249.66.160','2024-12-18 23:38:48','2024-12-18 23:38:48','en'),
('b6e69e41-1338-44e0-8673-07c2c5d6b2c3',NULL,'79.248.180.170','2025-01-02 11:14:18','2025-01-02 11:14:18','en'),
('b70a89f5-a100-4709-b2ce-87f6736224ac',NULL,'194.33.76.71','2024-12-22 13:43:34','2024-12-22 13:43:34','en'),
('b7d79953-2ee3-4d56-8e98-643a7f1211f1',NULL,'102.89.45.211','2025-01-02 16:01:36','2025-01-02 16:01:36','en'),
('b7e8dd75-b3e2-40f0-b289-b6fd4ca7f2c1',NULL,'84.119.18.216','2024-11-29 22:09:53','2024-11-29 22:09:53','en'),
('b83863f1-0e11-4c38-8825-f403fe83eacd',NULL,'80.187.120.195','2024-12-12 19:07:58','2024-12-12 19:07:58','en'),
('b8519b06-b1b5-4b2c-8931-5394b765f73e',NULL,'41.90.176.21','2024-12-12 08:56:42','2024-12-12 08:56:42','en'),
('b852ebf9-0b57-48d1-a30a-a31463c0b891',NULL,'176.6.64.43','2024-12-11 21:07:34','2024-12-11 21:07:34','en'),
('b8c0d1d2-21c6-431c-8e08-a65097e1407d',NULL,'109.42.178.187','2025-01-09 18:15:47','2025-01-09 18:15:47','en'),
('b8d58712-241d-41b6-a52d-bf7e56693f75',NULL,'102.88.43.132','2025-01-03 18:33:20','2025-01-03 18:33:20','en'),
('b8e5bfaf-20bd-4552-b361-f3fd864211e6','43ee3110-bbd0-11ef-941b-fdb6f9dab86c','37.201.153.99','2024-12-17 14:09:31','2024-12-17 14:09:31','en'),
('b992347a-6a65-4f4c-b5aa-a3c5db505499',NULL,'49.47.216.96','2025-01-02 03:55:17','2025-01-02 03:55:17','en'),
('b9e8f23b-8cdd-4c60-b294-188f512da1bc',NULL,'46.114.108.115','2024-11-28 18:38:18','2024-11-28 18:38:18','en'),
('ba6dea72-e012-4284-99f7-14695ab78a91',NULL,'102.89.45.211','2025-01-02 16:32:49','2025-01-02 16:32:49','en'),
('baa9021d-f6f0-4c87-940c-52f900811e0a',NULL,'37.156.73.127','2024-12-22 13:13:47','2024-12-22 13:13:47','en'),
('bbe75772-8673-4b9e-962f-f606daa955ae',NULL,'176.6.58.86','2024-12-15 14:14:40','2024-12-15 14:14:40','en'),
('bc4b0d2f-ea65-4122-9acb-64eb5789a7bf',NULL,'37.201.153.66','2024-11-24 22:14:45','2024-11-24 22:14:45','en'),
('bc9f45db-b5e2-4c66-86b5-96dc37845094',NULL,'109.42.176.247','2024-12-15 10:19:34','2024-12-15 10:19:34','en'),
('bca44a5b-163c-4990-a368-421088278121',NULL,'93.133.244.214','2024-12-21 04:54:47','2024-12-21 04:54:47','en'),
('bd25d8b1-ed53-4ade-a30d-d090a9b52b07',NULL,'176.6.58.164','2024-12-12 15:22:29','2024-12-12 15:22:29','en'),
('bd4d3921-7983-40b2-9aa5-99cb41e4aa51',NULL,'176.1.5.202','2024-12-23 23:42:54','2024-12-23 23:42:54','en'),
('bd6d384c-6de4-43a1-9586-7fc0a4853a18',NULL,'31.17.29.134','2025-01-10 09:18:52','2025-01-10 09:18:52','en'),
('bd9637f7-c0f1-4de2-b8f1-5bd065b03d9c',NULL,'176.6.53.44','2025-01-09 22:17:11','2025-01-09 22:17:11','en'),
('bdab8394-09ae-455d-9795-9f1c004be7d3',NULL,'212.185.237.22','2024-12-17 20:38:11','2024-12-17 20:38:11','en'),
('be2fb82f-2b41-49ca-b7c7-92a5aeb7fd8d',NULL,'84.119.18.216','2024-11-29 22:09:44','2024-11-29 22:09:44','en'),
('be31d582-3412-4466-aa3a-a40d72f4df54',NULL,'176.6.64.43','2024-12-11 22:40:35','2024-12-11 22:40:35','en'),
('beab94c6-3917-4cc4-9995-3385125cdded',NULL,'176.6.64.43','2024-12-11 21:07:32','2024-12-11 21:07:32','en'),
('bed3b610-a238-4e1d-8220-fe25f921fb44',NULL,'93.133.199.38','2024-12-21 00:29:07','2024-12-21 00:29:07','en'),
('bed610c8-e033-4601-a9bb-403b7ad1aa9f',NULL,'37.201.153.99','2024-12-17 14:13:22','2024-12-17 14:13:22','en'),
('bee302d3-256f-4ade-8b83-2fdbad2cbdd1',NULL,'176.6.66.112','2024-12-19 21:57:07','2024-12-19 21:57:07','en'),
('bf55a5da-b22b-4f44-b3d6-b6b7090eddb4',NULL,'37.201.194.175','2025-01-04 08:40:33','2025-01-04 08:40:33','en'),
('bf7f8763-b2f0-41b5-8812-756bdd201da9',NULL,'104.28.242.121','2025-01-02 07:14:07','2025-01-02 07:14:07','en'),
('bf8a2316-efd8-4b39-b463-850576ddabeb',NULL,'147.235.207.116','2024-12-22 06:43:35','2024-12-22 06:43:35','en'),
('c017a314-b753-4e72-900c-82783ec37bae',NULL,'185.209.196.218','2024-12-19 20:47:46','2024-12-19 20:47:46','en'),
('c096c936-bdc5-4822-a826-e5d01c408667',NULL,'176.1.5.202','2024-12-23 23:40:34','2024-12-23 23:40:34','en'),
('c0b0312f-e162-4d31-b2fa-4551e80bc5d9',NULL,'89.0.5.86','2024-12-29 09:00:52','2024-12-29 09:00:52','en'),
('c0ecae59-2ad2-4f76-811d-aa20b49da543',NULL,'191.101.157.152','2024-12-09 12:05:48','2024-12-09 12:05:48','en'),
('c1b64828-2a8f-45f9-b1a5-588a8c1b52b9',NULL,'217.232.29.81','2024-12-16 00:17:13','2024-12-16 00:17:13','en'),
('c1b70a37-f776-4b0d-ac71-dfc6d3d7e48b',NULL,'92.116.146.253','2024-12-12 12:47:54','2024-12-12 12:47:54','en'),
('c1d12899-a646-48c7-a859-a9f3b81e7aac',NULL,'46.114.109.167','2025-01-08 13:50:12','2025-01-08 13:50:12','en'),
('c2f8afdf-0aa6-440a-8e18-e5651b5d50a7',NULL,'102.89.23.30','2025-01-02 16:54:42','2025-01-02 16:54:42','en'),
('c327c11a-0350-4bef-a9ce-3f2d97691608',NULL,'37.201.153.99','2024-12-17 14:10:35','2024-12-17 14:10:35','en'),
('c424eb9b-843c-4315-b79b-282bb4f1c7a9',NULL,'34.123.170.104','2025-01-05 16:28:01','2025-01-05 16:28:01','en'),
('c45f3eda-a266-4ab6-a20b-34661dff15a3',NULL,'2.243.114.133','2025-01-04 05:29:10','2025-01-04 05:29:10','en'),
('c52f605d-0376-4d51-8c50-e1522a1b4629',NULL,'154.159.237.94','2024-12-22 02:33:24','2024-12-22 02:33:24','en'),
('c56f42c6-5f16-4dd5-904b-da7a6fec980f',NULL,'79.232.232.174','2025-01-06 09:02:28','2025-01-06 09:02:28','en'),
('c644ede1-20b7-424d-a478-1ea9c7eb7df2',NULL,'88.128.90.22','2024-11-24 18:36:20','2024-11-24 18:36:20','en'),
('c64eab09-874b-4910-963d-496ce442f36b',NULL,'41.90.5.54','2025-01-02 11:53:13','2025-01-02 11:53:13','en'),
('c67656bd-dc0d-41d6-89bf-756068172c0b',NULL,'109.43.113.3','2024-12-26 20:04:35','2024-12-26 20:04:35','en'),
('c6a5c337-fb1e-4f5f-86df-9312e74b2ef8',NULL,'95.91.208.169','2025-01-09 10:41:58','2025-01-09 10:41:58','en'),
('c6bbd742-c4e7-478b-8f81-8cfd18453d83',NULL,'102.88.43.132','2025-01-03 18:33:14','2025-01-03 18:33:14','en'),
('c7786e32-db6c-4574-afb1-c267bbf57b5f',NULL,'176.5.133.122','2024-12-24 18:21:17','2024-12-24 18:21:17','en'),
('c78157bf-2fe4-4f61-955a-90c749d51636',NULL,'88.128.90.77','2024-12-15 23:51:51','2024-12-15 23:51:51','en'),
('c7c6f2e2-2ba4-4fab-aa1b-d75633b36fb9',NULL,'102.91.93.92','2024-12-11 06:19:21','2024-12-11 06:19:21','en'),
('c80e35b3-f3f0-481a-80cb-71c8c75adfc4',NULL,'104.28.210.121','2025-01-02 07:13:15','2025-01-02 07:13:15','en'),
('c89d56bc-8032-48af-b8de-36f7a9fe4a81',NULL,'80.187.124.116','2025-01-07 12:07:06','2025-01-07 12:07:06','en'),
('c8a44056-bf84-4458-9f43-3a900dc0d446',NULL,'191.101.157.152','2024-12-09 12:04:33','2024-12-09 12:04:33','en'),
('c8c53da6-2ae8-44fb-bf8e-3e951ba097e3',NULL,'89.0.208.89','2024-12-30 15:08:17','2024-12-30 15:08:17','en'),
('c8f77ccf-3f59-4f3c-80d0-bf3fdf0f3c01',NULL,'102.91.4.18','2024-12-02 15:18:00','2024-12-02 15:18:00','en'),
('c9288749-74f4-47fb-a856-ac94138c2b80',NULL,'194.8.199.29','2024-12-23 18:31:41','2024-12-23 18:31:41','en'),
('c95bf9e2-a475-4a8e-b681-bd1fe2b17d13',NULL,'191.101.157.152','2024-12-09 12:08:31','2024-12-09 12:08:31','en'),
('c9b2abd8-09cb-47f6-b018-6bd2e1b7e382',NULL,'102.91.102.252','2024-12-09 12:05:19','2024-12-09 12:05:19','en'),
('c9f71c17-33e1-468b-9098-426cd0d2e5e8',NULL,'102.91.93.179','2025-01-03 14:20:27','2025-01-03 14:20:27','en'),
('ca5ada21-f50a-43b4-bd68-75497940d0f4',NULL,'102.89.23.82','2025-01-06 10:38:35','2025-01-06 10:38:35','en'),
('caee3cf7-315b-41d3-9723-9bcf62ab033d',NULL,'102.91.92.119','2024-12-08 12:17:02','2024-12-08 12:17:02','en'),
('caf22ab6-06b4-4b13-857a-12243a62bbe9',NULL,'102.91.92.52','2024-11-24 17:50:56','2024-11-24 17:50:56','en'),
('caff3309-5c0f-47b3-949e-530689c8e878',NULL,'40.74.114.126','2024-12-15 08:01:51','2024-12-15 08:01:51','en'),
('cb49cd7f-199f-4f98-9c21-7d3eaf2bfd82',NULL,'191.101.157.152','2024-12-09 11:08:01','2024-12-09 11:08:01','en'),
('cb98efa8-012f-425d-8342-d89935e3e8f6',NULL,'87.79.236.180','2024-12-07 23:34:52','2024-12-07 23:34:52','en'),
('cd41a680-55de-4272-b257-50aa8fe7afcc',NULL,'176.6.64.43','2024-12-12 01:00:57','2024-12-12 01:00:57','en'),
('cd9f6c02-5a99-4d68-beb0-10100ecd55d4',NULL,'37.201.153.99','2024-12-12 11:59:47','2024-12-12 11:59:47','en'),
('ce43c1e4-8a78-43d4-99af-d4e7af9ed4fb',NULL,'205.169.39.0','2025-01-06 06:41:20','2025-01-06 06:41:20','en'),
('ce5cae38-808a-4457-9586-886f83a76e88',NULL,'66.249.83.130','2024-12-26 20:04:41','2024-12-26 20:04:41','en'),
('ce5f2920-5cb1-4d58-93ba-5593ae9f2244',NULL,'102.91.102.252','2024-12-09 11:59:56','2024-12-09 11:59:56','en'),
('cee9c0fe-e3e8-4fb6-a066-3575c8da8fc8',NULL,'66.102.8.97','2025-01-04 19:44:08','2025-01-04 19:44:08','en'),
('cf1a9d92-9cb9-4d8b-ae51-618e4164ac14',NULL,'89.0.5.86','2024-12-29 09:00:59','2024-12-29 09:00:59','en'),
('cf5a5d90-0449-4707-9508-3fe353eb8297',NULL,'61.247.177.142','2024-12-08 13:57:39','2024-12-08 13:57:39','en'),
('d07fe694-23ef-4c3c-8f10-5fc015782fac',NULL,'102.91.102.252','2024-12-09 12:04:16','2024-12-09 12:04:16','en'),
('d0bf22b8-a9a9-4036-a8ba-b6ab2893b3f2',NULL,'109.192.106.166','2025-01-06 14:08:59','2025-01-06 14:08:59','en'),
('d15e4cf3-d16a-40f6-81bb-b5a7d0762f59',NULL,'194.8.199.29','2024-12-17 00:14:22','2024-12-17 00:14:22','en'),
('d16cdccf-4585-4699-b396-cf00b17165c0',NULL,'88.128.90.58','2025-01-03 03:40:45','2025-01-03 03:40:45','en'),
('d1cb14c7-7cf2-45fc-b03e-fc4ce429e66f',NULL,'93.133.9.231','2024-11-24 19:24:53','2024-11-24 19:24:53','en'),
('d23c1c08-ade1-412d-b1e4-db13bedf3f24',NULL,'52.210.103.140','2025-01-09 21:08:34','2025-01-09 21:08:34','en'),
('d245325c-fe86-44e0-b58f-5c0b5d2e2d08',NULL,'176.6.66.112','2024-12-19 21:57:05','2024-12-19 21:57:05','en'),
('d2b88ff8-9e85-4603-858a-e198e6ec95b3',NULL,'89.0.209.63','2024-12-24 04:46:23','2024-12-24 04:46:23','en'),
('d2bc7a86-658d-4614-b2a4-875963e48563',NULL,'87.79.22.196','2024-12-27 14:10:19','2024-12-27 14:10:19','en'),
('d36548bc-8b39-46c0-8ca7-0b5dc4f2164f',NULL,'194.8.199.28','2024-12-09 13:14:44','2024-12-09 13:14:44','en'),
('d3f7a48c-5dde-4edb-84d9-5bfa4abd5f4c',NULL,'102.91.93.92','2024-12-11 04:24:54','2024-12-11 04:24:54','en'),
('d41843da-ab75-4c78-b7ea-6f14d3b4f283',NULL,'61.247.177.142','2024-12-10 05:41:23','2024-12-10 05:41:23','en'),
('d444a90c-bd92-4b77-93f0-9f2b9a571c60',NULL,'52.236.180.47','2024-12-29 04:18:34','2024-12-29 04:18:34','en'),
('d4915d82-551e-471d-bc5d-11d816e1b828',NULL,'49.47.216.96','2025-01-02 03:54:58','2025-01-02 03:54:58','en'),
('d5b756c0-7357-4ae6-9fcc-25aa3340b479',NULL,'176.1.5.202','2024-12-23 23:41:48','2024-12-23 23:41:48','en'),
('d627e0f2-063e-474b-91ca-5f8dc811cfdb',NULL,'88.128.90.22','2024-11-24 18:36:57','2024-11-24 18:36:57','en'),
('d6d5db46-b4e2-40d6-9023-a11a3ec94cec',NULL,'176.6.59.84','2024-12-14 14:05:36','2024-12-14 14:05:36','en'),
('d7778e65-71a0-46f2-b3f2-26718f0ec9de',NULL,'2.243.114.133','2025-01-04 05:29:06','2025-01-04 05:29:06','en'),
('d77b4a6c-61f9-4ab6-846b-f25f22dc4dec',NULL,'176.6.64.43','2024-12-11 23:18:34','2024-12-11 23:18:34','en'),
('d7969f03-f7b4-4ad3-a43b-253e02a27d78',NULL,'102.91.93.92','2024-12-11 06:09:34','2024-12-11 06:09:34','en'),
('d7be7fbe-6d67-43d5-b67f-a5de7567146f',NULL,'102.89.45.211','2025-01-02 16:13:06','2025-01-02 16:13:06','en'),
('d8b84952-f99d-48d7-b436-7b0120918878',NULL,'191.101.157.152','2024-12-09 11:01:59','2024-12-09 11:01:59','en'),
('d919e13c-e032-43a4-bd18-1c950ee9beef',NULL,'61.247.177.142','2024-12-09 14:20:58','2024-12-09 14:20:58','en'),
('d9501bbf-7405-4ccc-9343-1e88785b0d38',NULL,'46.114.109.167','2025-01-08 13:47:17','2025-01-08 13:47:17','en'),
('d98a3a7c-6685-43e1-aa48-c59bbf5f30df',NULL,'102.91.4.18','2024-12-02 15:05:06','2024-12-02 15:05:06','en'),
('d98abebe-85f9-4a06-8214-390be7c76719',NULL,'191.101.157.152','2024-12-09 11:34:30','2024-12-09 11:34:30','en'),
('d98c4c17-59c4-40ed-887e-e820a3ce7a59',NULL,'94.31.117.166','2024-12-16 17:24:28','2024-12-16 17:24:28','en'),
('d9ba708a-0de5-42d9-a44e-d621ac6e8dda',NULL,'79.232.232.174','2025-01-06 09:02:42','2025-01-06 09:02:42','en'),
('d9f187bd-d7fa-472a-81ef-482f37b3a781',NULL,'176.6.57.222','2024-12-09 11:03:04','2024-12-09 11:03:04','en'),
('da3e8869-c6f6-4965-afe2-fbaa2cd1efa7',NULL,'89.0.212.1','2024-12-12 16:15:16','2024-12-12 16:15:16','en'),
('da8f2943-6910-4927-8785-5810d691a380',NULL,'88.128.88.14','2024-12-02 20:47:02','2024-12-02 20:47:02','en'),
('da95d664-286b-40bc-a13f-91bbf1429482',NULL,'191.101.157.152','2024-12-09 11:08:56','2024-12-09 11:08:56','en'),
('db2020c1-d0fd-4f8f-8497-f96610634d1f',NULL,'102.91.92.52','2024-11-24 17:53:09','2024-11-24 17:53:09','en'),
('db2c720c-239f-4a9f-8819-211dd5697191',NULL,'176.6.58.86','2024-12-15 14:15:00','2024-12-15 14:15:00','en'),
('dbace3c0-dc47-4494-b324-bf637a693acf',NULL,'176.6.59.84','2024-12-14 16:19:39','2024-12-14 16:19:39','en'),
('dbbbaa6b-a06f-4afa-97e1-2dd71b53efe9',NULL,'66.249.83.129','2024-12-26 20:04:42','2024-12-26 20:04:42','en'),
('dbc1d28e-39ce-4b4c-a110-2f14d4d24fca',NULL,'191.101.157.152','2024-12-09 11:34:45','2024-12-09 11:34:45','en'),
('dc1f9f02-7ab8-4c06-814c-7c3b030a0ffc',NULL,'87.123.243.180','2024-12-25 07:26:50','2024-12-25 07:26:50','en'),
('dc7ebc71-0d4b-4586-a24b-900712350b0b',NULL,'191.101.157.152','2024-12-09 10:58:54','2024-12-09 10:58:54','en'),
('dc81a36f-2646-4e35-a25c-47c8f64804a1',NULL,'41.66.209.48','2024-12-20 23:10:07','2024-12-20 23:10:07','en'),
('dd1a9930-91a3-4204-886c-cac3977b7b91',NULL,'87.123.243.180','2024-12-25 07:25:38','2024-12-25 07:25:38','en'),
('dd3e06f1-4a7d-4e50-b48c-95699931bc9b',NULL,'93.133.244.214','2024-12-21 04:32:39','2024-12-21 04:32:39','en'),
('ddf5ef30-308f-4104-912e-6a8383dab83a',NULL,'217.5.148.29','2024-12-16 10:17:36','2024-12-16 10:17:36','en'),
('de8075da-3d43-4037-bb5b-23a928a61a17',NULL,'61.247.177.142','2024-12-09 14:15:02','2024-12-09 14:15:02','en'),
('df20f2d9-69d9-4514-8a0c-6d18d2b70124',NULL,'191.101.157.152','2024-12-09 11:34:32','2024-12-09 11:34:32','en'),
('df6e6117-4944-447a-82ed-d9844b40ccae',NULL,'191.101.157.152','2024-12-09 11:16:26','2024-12-09 11:16:26','en'),
('df944c5b-586a-469a-afe9-aa4dc0fe53aa',NULL,'197.211.61.38','2024-12-11 15:27:23','2024-12-11 15:27:23','en'),
('df992689-a836-4ed5-af7a-2e91cd4e4f9d',NULL,'37.201.153.66','2024-11-24 22:13:54','2024-11-24 22:13:54','en'),
('dfd3da4a-13b9-4129-bb18-8e6cd68a4e62',NULL,'88.128.90.22','2024-11-24 18:39:02','2024-11-24 18:39:02','en'),
('dffc7a3b-244a-4776-96ba-d08d2790fab1',NULL,'197.210.53.131','2024-12-28 18:00:54','2024-12-28 18:00:54','en'),
('e008de82-ce9e-4bba-b75b-1ca6d595a909',NULL,'191.101.157.152','2024-12-09 10:58:05','2024-12-09 10:58:05','en'),
('e0df83f8-4648-4f81-99de-2eeeedad1576',NULL,'194.8.199.29','2024-12-16 22:39:19','2024-12-16 22:39:19','en'),
('e1e02b32-cc77-4bb5-9359-3bf4f628b89c',NULL,'176.6.58.86','2024-12-15 17:53:46','2024-12-15 17:53:46','en'),
('e1ef7d6a-5a50-4ea1-b059-c79ee8ce50ad',NULL,'176.5.141.23','2024-12-27 04:14:54','2024-12-27 04:14:54','en'),
('e2a46517-9635-4a82-95e0-a74802e36014',NULL,'194.8.199.29','2024-12-16 21:56:41','2024-12-16 21:56:41','en'),
('e2ab58ba-fb35-4926-9641-5153a8aaf093',NULL,'102.91.4.9','2024-12-15 17:35:38','2024-12-15 17:35:38','en'),
('e3bb5e4f-b5e4-4a19-b3ef-8d3b91df8532',NULL,'79.232.232.174','2025-01-06 09:00:29','2025-01-06 09:00:29','en'),
('e426c276-b8b2-444f-ad76-75ddd692ed5b',NULL,'61.247.177.142','2024-12-15 09:48:52','2024-12-15 09:48:52','en'),
('e45a7f6d-e811-4a77-8752-b6956f1d8bcc',NULL,'37.201.153.99','2024-12-17 14:08:36','2024-12-17 14:08:36','en'),
('e4879b29-1a92-420f-9d7f-4a0e01eca97d',NULL,'104.28.54.66','2024-12-09 12:18:02','2024-12-09 12:18:02','en'),
('e4d96f4e-aa35-4591-a536-f2d530431091',NULL,'40.94.96.46','2024-12-04 17:30:38','2024-12-04 17:30:38','en'),
('e536efa6-c594-491a-88cb-a4b07c6a7de8',NULL,'176.6.53.210','2024-12-08 17:40:08','2024-12-08 17:40:08','en'),
('e53a45e6-62dd-48aa-80fc-732659066d7c',NULL,'104.28.210.121','2025-01-02 07:13:17','2025-01-02 07:13:17','en'),
('e5aa6846-961b-4861-81e4-eec73edb3050',NULL,'197.210.71.140','2024-11-24 07:48:01','2024-11-24 07:48:01','en'),
('e5e5593f-809c-4913-88de-599859bcf9e6',NULL,'102.91.102.252','2024-12-09 11:59:30','2024-12-09 11:59:30','en'),
('e6045df2-78cd-44dd-ab3e-1afeff33a7b9',NULL,'103.153.130.126','2024-12-21 05:25:11','2024-12-21 05:25:11','en'),
('e6fdc713-bd41-43d0-82de-c45d5c922ea0',NULL,'46.114.109.224','2024-12-18 15:13:35','2024-12-18 15:13:35','en'),
('e724b169-2e76-46c3-8442-3721b796ff86',NULL,'197.211.61.35','2024-12-12 19:27:15','2024-12-12 19:27:15','en'),
('e745c284-ecee-4bde-94c4-29287f2dd326',NULL,'78.48.38.107','2024-12-12 13:36:53','2024-12-12 13:36:53','en'),
('e76b5ed4-5ffc-4c28-8e0d-0115810ab35e',NULL,'191.101.157.152','2024-12-09 11:02:53','2024-12-09 11:02:53','en'),
('e7a11c4b-abeb-4955-959e-e399cde28fa2',NULL,'176.3.69.119','2024-12-26 20:35:38','2024-12-26 20:35:38','en'),
('e8526e9a-36b8-434d-a235-a8226fbd1f40',NULL,'66.102.8.96','2025-01-04 19:40:29','2025-01-04 19:40:29','en'),
('e85bc447-8225-4296-9beb-64d30a3e6713',NULL,'102.89.45.211','2025-01-02 16:32:40','2025-01-02 16:32:40','en'),
('e8e35ceb-013f-4856-b935-3d0a30e33df6',NULL,'45.82.172.20','2025-01-02 08:28:13','2025-01-02 08:28:13','en'),
('e9769085-3191-4ac0-b7d1-b5a74359f4bd',NULL,'89.0.209.63','2024-12-24 04:46:46','2024-12-24 04:46:46','en'),
('e983bdec-8648-45a3-9cf6-f8c8069d02e0',NULL,'176.6.64.43','2024-12-11 22:25:49','2024-12-11 22:25:49','en'),
('e9a1e22c-430c-4fc1-a9fc-7349d256111c',NULL,'107.207.0.186','2024-12-24 05:00:38','2024-12-24 05:00:38','en'),
('e9bd34bc-7846-47f1-a240-f86064ee1fac',NULL,'178.202.191.63','2024-12-12 21:09:23','2024-12-12 21:09:23','en'),
('e9c01541-a1c7-4d49-afa6-6a249fb00aaa',NULL,'102.91.102.252','2024-12-09 12:00:46','2024-12-09 12:00:46','en'),
('e9e2f1db-36ec-4e31-b801-1d64f9f5a80e',NULL,'93.133.244.214','2024-12-21 04:56:51','2024-12-21 04:56:51','en'),
('ea01b945-bb6a-4cb0-8e62-0f5f9709e715',NULL,'176.6.61.20','2024-12-28 01:15:38','2024-12-28 01:15:38','en'),
('ea7c041d-afbb-498e-9155-cfd42f2340ca',NULL,'181.215.176.25','2024-11-28 21:16:35','2024-11-28 21:16:35','en'),
('eaa6ac3e-5187-4006-aef0-ba4299fe9c2a',NULL,'52.165.149.97','2025-01-09 22:17:34','2025-01-09 22:17:34','en'),
('eb1c65b8-1f88-41c4-b634-1a7b3560c297',NULL,'194.33.76.71','2024-12-22 13:43:33','2024-12-22 13:43:33','en'),
('eb46f73e-10d1-43b5-a7df-359cdd5a2e0e',NULL,'37.201.153.99','2024-12-14 14:39:44','2024-12-14 14:39:44','en'),
('eb6ce100-07c8-406d-976f-19d6387ce2e9',NULL,'46.114.108.115','2024-11-28 18:39:26','2024-11-28 18:39:26','en'),
('eb728c40-e5e3-455a-8812-7d793c8f1808',NULL,'52.236.180.47','2024-12-29 04:18:33','2024-12-29 04:18:33','en'),
('eb88c15e-df98-4ce5-a380-9e6bce28b065',NULL,'194.8.199.29','2024-12-16 21:47:45','2024-12-16 21:47:45','en'),
('ec1cc44e-e7fa-44d7-82bf-add3dab8a95a',NULL,'176.6.53.210','2024-12-08 17:40:41','2024-12-08 17:40:41','en'),
('ec4e92a1-ff70-46b2-a15f-f8bc5748ea33',NULL,'191.101.157.152','2024-12-09 11:07:24','2024-12-09 11:07:24','en'),
('ec7137a3-87b0-4fb9-825d-f3040bcf4cb6',NULL,'176.6.59.84','2024-12-14 16:19:37','2024-12-14 16:19:37','en'),
('eca28dba-4284-4a4d-98b3-33c992830971',NULL,'84.44.249.165','2024-12-13 22:20:47','2024-12-13 22:20:47','en'),
('ecbfc0d6-1f83-4633-a344-a652b74ca86d',NULL,'102.91.4.9','2024-12-15 17:39:00','2024-12-15 17:39:00','en'),
('ece2eed4-703f-43e9-89af-6ad1d9b60ba0',NULL,'102.91.92.52','2024-11-24 17:50:59','2024-11-24 17:50:59','en'),
('ed736203-72d4-4239-b261-35bab03b892d',NULL,'176.198.203.173','2024-12-15 10:59:20','2024-12-15 10:59:20','en'),
('ede16798-2d33-4d8c-b6b5-b73930dffece',NULL,'176.6.64.43','2024-12-11 19:54:04','2024-12-11 19:54:04','en'),
('eebf9782-d9aa-4312-91ec-f829d35737de',NULL,'197.210.53.16','2024-12-19 20:04:34','2024-12-19 20:04:34','en'),
('eec56ca7-137f-4bbd-a250-3572b6a6b960',NULL,'80.155.183.58','2025-01-08 10:52:33','2025-01-08 10:52:33','en'),
('ef904a9c-6857-4ec2-a01a-bcbd98f3285b',NULL,'102.89.45.211','2025-01-02 16:01:37','2025-01-02 16:01:37','en'),
('f006ee6d-f089-41ba-b8b3-1f3be2afbb0b',NULL,'40.94.89.43','2024-12-15 08:02:22','2024-12-15 08:02:22','en'),
('f0796b08-943b-4522-b501-3912291e6385',NULL,'176.6.60.147','2025-01-06 14:09:45','2025-01-06 14:09:45','en'),
('f1c43960-1076-49db-8699-6fd5a848bee0',NULL,'213.168.126.222','2024-12-22 07:15:20','2024-12-22 07:15:20','en'),
('f26d8dd4-24e2-4ee9-8779-362404866a28',NULL,'191.101.157.152','2024-12-09 10:57:42','2024-12-09 10:57:42','en'),
('f2891e0e-b334-44a2-998d-f8f283e0fd75',NULL,'162.120.172.51','2024-12-23 10:16:10','2024-12-23 10:16:10','en'),
('f2947149-31c6-4655-8409-87668d241cff',NULL,'40.94.89.22','2024-12-29 19:20:17','2024-12-29 19:20:17','en'),
('f3206ea8-c856-47cc-927f-a2654a72591b',NULL,'149.172.163.114','2025-01-04 20:45:10','2025-01-04 20:45:10','en'),
('f381766b-33a1-426b-844d-d7a6baff8044',NULL,'178.197.202.234','2024-12-26 10:46:33','2024-12-26 10:46:33','en'),
('f3fd766d-feb1-442c-a784-36274c9aa3f4',NULL,'197.210.53.131','2025-01-02 15:42:12','2025-01-02 15:42:12','en'),
('f421af15-74cf-4aa2-a5c8-d00434b5c14a',NULL,'78.35.74.71','2024-12-18 14:04:39','2024-12-18 14:04:39','en'),
('f43daa76-193b-44a0-95e3-f77b58448fac',NULL,'102.91.102.252','2024-12-09 12:04:56','2024-12-09 12:04:56','en'),
('f4a16a73-ad10-4bd7-83e4-f5afbd803cce',NULL,'102.91.93.92','2024-12-11 06:09:36','2024-12-11 06:09:36','en'),
('f5505463-6faa-4049-a3d9-bb926535025d',NULL,'178.202.191.63','2024-12-12 21:08:56','2024-12-12 21:08:56','en'),
('f5b94131-8e9f-4c8f-8db6-80c4953b7e64',NULL,'79.248.5.179','2025-01-10 15:26:14','2025-01-10 15:26:14','en'),
('f60e72ce-a080-442d-b2fe-cf2086160073',NULL,'66.249.66.160','2024-12-18 23:43:44','2024-12-18 23:43:44','en'),
('f61467f8-b0d5-47f6-907e-8f632d94cd06',NULL,'194.8.199.28','2024-12-09 13:15:13','2024-12-09 13:15:13','en'),
('f6310b26-ab3f-442c-9d1d-8653e0c383ee',NULL,'89.0.212.103','2025-01-04 22:55:54','2025-01-04 22:55:54','en'),
('f64bd8eb-35f3-4882-9689-3b35553e0a8d',NULL,'104.197.69.115','2024-12-29 18:59:43','2024-12-29 18:59:43','en'),
('f67a6446-9c27-49ad-83dc-7f9acefd81a2',NULL,'104.197.69.115','2024-12-12 16:37:45','2024-12-12 16:37:45','en'),
('f6b0d9ad-c622-4471-b787-f870678184bc',NULL,'176.6.57.222','2024-12-09 11:03:12','2024-12-09 11:03:12','en'),
('f6d6a9cf-2dea-4f04-89d0-d8b630f9805d',NULL,'88.128.90.74','2024-12-21 20:11:16','2024-12-21 20:11:16','en'),
('f6d76e3f-19ed-404f-bbc1-aae82ebdc4bd',NULL,'89.0.212.1','2024-12-12 16:15:16','2024-12-12 16:15:16','en'),
('f6f016df-6fcb-4faa-9ca0-0f0bd0be0985',NULL,'41.90.176.21','2024-12-12 08:56:44','2024-12-12 08:56:44','en'),
('f73ffc6f-be2f-4f48-8624-d9057bc17ea1',NULL,'37.201.153.99','2024-12-27 12:00:56','2024-12-27 12:00:56','en'),
('f79de87c-ae0e-4e15-8399-5e137ccae355',NULL,'78.35.74.152','2025-01-09 10:27:17','2025-01-09 10:27:17','en'),
('f83ebf6c-45b4-45c7-a3ab-dec99ea09773',NULL,'197.210.53.131','2024-12-28 18:03:31','2024-12-28 18:03:31','en'),
('f8b8df31-00fc-4e00-a4aa-d7844df68018',NULL,'194.8.199.29','2024-12-16 22:39:20','2024-12-16 22:39:20','en'),
('f8e72a00-0168-4ffd-99b3-c8606cb02ac8',NULL,'46.114.108.138','2024-12-17 15:36:36','2024-12-17 15:36:36','en'),
('f8f4f056-d78f-484d-ba9d-0aced963f176',NULL,'185.209.196.218','2024-12-19 20:48:32','2024-12-19 20:48:32','en'),
('f9206694-3ec8-452b-9b4d-1c8d38a4dd38',NULL,'89.0.212.103','2025-01-04 22:56:05','2025-01-04 22:56:05','en'),
('f9bb0f1b-ff52-4935-b69e-5f57a5a7a7dd',NULL,'61.247.177.142','2024-12-09 07:41:04','2024-12-09 07:41:04','en'),
('f9f43d12-082e-4bc6-9bb0-872becc16c04',NULL,'104.28.54.47','2024-12-15 08:21:14','2024-12-15 08:21:14','en'),
('fa29fca9-9a6c-400a-9a53-3ca6b82308e4',NULL,'185.40.61.29','2025-01-04 20:56:27','2025-01-04 20:56:27','en'),
('fa4c038c-311c-4149-bf89-4d078777fe2a',NULL,'37.201.153.99','2024-12-16 18:00:05','2024-12-16 18:00:05','en'),
('fa551b78-ed12-4686-b311-be693292b94b',NULL,'197.211.61.116','2024-12-02 18:09:02','2024-12-02 18:09:02','en'),
('fabdb115-851a-4cd4-8095-c2b183c4cda5',NULL,'61.247.177.142','2024-12-09 07:41:25','2024-12-09 07:41:25','en'),
('fb3f65a4-213d-4853-b57c-7271c18fa1b2',NULL,'79.232.232.174','2025-01-06 09:02:17','2025-01-06 09:02:17','en'),
('fb613b4a-358c-45bd-8260-afe315867d96',NULL,'176.5.137.134','2024-12-24 04:09:50','2024-12-24 04:09:50','en'),
('fb841144-3f34-40e4-b295-6ad92c2b0cc4',NULL,'102.91.72.229','2024-12-17 15:49:35','2024-12-17 15:49:35','en'),
('fb87d09d-e64a-46e3-aec6-12d37ee9fecb',NULL,'40.94.97.78','2025-01-09 00:31:58','2025-01-09 00:31:58','en'),
('fbd255d5-9a94-4b3e-8fbd-6cfc8621581c',NULL,'93.133.30.180','2024-12-23 17:05:55','2024-12-23 17:05:55','en'),
('fbe71915-51fc-468e-b872-5fd00642276e',NULL,'102.91.93.92','2024-12-11 06:23:00','2024-12-11 06:23:00','en'),
('fca458e8-70b9-445e-bf67-044677f6760e',NULL,'89.1.58.130','2024-12-13 10:03:52','2024-12-13 10:03:52','en'),
('fcb85972-cf31-4e5e-be9b-3129666215fa',NULL,'45.82.172.20','2025-01-02 08:28:10','2025-01-02 08:28:10','en'),
('fce4751d-20e4-495e-a02f-9d8c7d2a585d',NULL,'2.243.10.124','2025-01-10 02:09:29','2025-01-10 02:09:29','en'),
('fd3016b6-d649-448c-9358-c75701eb9d54',NULL,'37.201.153.99','2024-12-17 14:07:27','2024-12-17 14:07:27','en'),
('fd978890-1b99-42df-8609-4eef4b549fe7',NULL,'176.6.67.11','2024-12-11 15:10:27','2024-12-11 15:10:27','en'),
('fdb77f9f-66ab-4be1-a604-fce8f1aa96cd',NULL,'191.101.157.152','2024-12-09 11:34:47','2024-12-09 11:34:47','en'),
('fe264697-e015-4ca2-a709-5cbe7e999ee9',NULL,'176.6.64.43','2024-12-12 01:48:07','2024-12-12 01:48:07','en'),
('ff367377-f703-4fea-8710-d554ed10b92a',NULL,'93.133.149.1','2024-12-28 15:20:21','2024-12-28 15:20:21','en'),
('ff520d5d-7f2c-4d81-b7c7-293c821cdeb9',NULL,'102.91.92.52','2024-11-24 18:34:22','2024-11-24 18:34:22','en'),
('ff68831c-172e-4fbb-90ff-c3555b7bf97f',NULL,'79.232.232.174','2025-01-06 09:02:28','2025-01-06 09:02:28','en'),
('ffab1d9c-5b65-4b35-a290-1ebdcedeeddc',NULL,'102.91.102.252','2024-12-09 11:59:32','2024-12-09 11:59:32','en'),
('fff66132-3f86-47c7-a314-c80e708f5c35',NULL,'78.35.74.152','2025-01-09 10:28:08','2025-01-09 10:28:08','en');
/*!40000 ALTER TABLE `guests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ignored_posts`
--

DROP TABLE IF EXISTS `ignored_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ignored_posts` (
  `id` char(36) NOT NULL,
  `post_id` char(36) NOT NULL,
  `provider_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ignored_posts`
--

LOCK TABLES `ignored_posts` WRITE;
/*!40000 ALTER TABLE `ignored_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `ignored_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landing_page_features`
--

DROP TABLE IF EXISTS `landing_page_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `landing_page_features` (
  `id` char(36) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `image_1` varchar(255) DEFAULT NULL,
  `image_2` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_page_features`
--

LOCK TABLES `landing_page_features` WRITE;
/*!40000 ALTER TABLE `landing_page_features` DISABLE KEYS */;
INSERT INTO `landing_page_features` VALUES
('12696663-098f-432a-8b1a-f192ea05c7a6','GET YOUR SERVICE 24/7','Visit our app and select your location to see available services near you','2023-08-31-64ef2e92e47c3.png','2023-08-31-64ef2e92e8b41.png','2023-12-28 14:00:58','2023-12-28 14:00:58');
/*!40000 ALTER TABLE `landing_page_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landing_page_specialities`
--

DROP TABLE IF EXISTS `landing_page_specialities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `landing_page_specialities` (
  `id` char(36) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_page_specialities`
--

LOCK TABLES `landing_page_specialities` WRITE;
/*!40000 ALTER TABLE `landing_page_specialities` DISABLE KEYS */;
INSERT INTO `landing_page_specialities` VALUES
('dcfe3c2b-9a84-4621-ba8a-34ea95dcb21f','Speciality','Speciality description','2023-08-31-64ef3bcbbeb55.png','2023-12-28 14:00:58','2023-12-28 14:00:58');
/*!40000 ALTER TABLE `landing_page_specialities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landing_page_testimonials`
--

DROP TABLE IF EXISTS `landing_page_testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `landing_page_testimonials` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `review` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_page_testimonials`
--

LOCK TABLES `landing_page_testimonials` WRITE;
/*!40000 ALTER TABLE `landing_page_testimonials` DISABLE KEYS */;
/*!40000 ALTER TABLE `landing_page_testimonials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_setups`
--

DROP TABLE IF EXISTS `login_setups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_setups` (
  `id` char(36) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_setups`
--

LOCK TABLES `login_setups` WRITE;
/*!40000 ALTER TABLE `login_setups` DISABLE KEYS */;
INSERT INTO `login_setups` VALUES
('1e92c1a5-b53d-43b9-830e-55c3045b739c','social_media_for_login','{\"google\":0,\"facebook\":0,\"apple\":0}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('6e11c053-8e75-427d-be3e-53995f6cfddf','phone_verification','1','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('f34648c0-3975-4728-9fc7-3f3e29c76afc','email_verification','1','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('fa2ec237-e8d7-4497-8ec3-2d1dfbfed25a','login_options','{\"manual_login\":1,\"otp_login\":1,\"social_media_login\":0}','2024-08-25 14:24:01','2024-08-25 14:24:01');
/*!40000 ALTER TABLE `login_setups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_point_transactions`
--

DROP TABLE IF EXISTS `loyalty_point_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_point_transactions` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `credit` decimal(24,2) NOT NULL DEFAULT 0.00,
  `debit` decimal(24,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(24,2) NOT NULL DEFAULT 0.00,
  `reference` varchar(255) DEFAULT NULL,
  `transaction_type` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_point_transactions`
--

LOCK TABLES `loyalty_point_transactions` WRITE;
/*!40000 ALTER TABLE `loyalty_point_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_point_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2014_10_12_100000_create_password_resets_table',1),
(2,'2016_06_01_000001_create_oauth_auth_codes_table',1),
(3,'2016_06_01_000002_create_oauth_access_tokens_table',1),
(4,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),
(5,'2016_06_01_000004_create_oauth_clients_table',1),
(6,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),
(7,'2019_12_14_000001_create_personal_access_tokens_table',1),
(8,'2022_02_28_094005_create_users_table',1),
(9,'2022_02_28_094802_create_roles_table',1),
(10,'2022_02_28_094823_create_user_roles_table',1),
(11,'2022_03_01_092248_create_modules_table',1),
(12,'2022_03_01_093500_create_role_modules_table',1),
(13,'2022_03_05_085155_create_zones_table',1),
(14,'2022_03_06_035439_create_categories_table',1),
(15,'2022_03_06_042053_create_category_zone_table',1),
(16,'2022_03_06_091813_create_discounts_table',1),
(17,'2022_03_06_092202_create_services_table',1),
(18,'2022_03_06_094413_create_variations_table',1),
(19,'2022_03_07_063157_create_discount_types_table',1),
(21,'2022_03_07_065305_create_provider_sub_category_table',1),
(22,'2022_03_07_090055_create_coupons_table',1),
(23,'2022_03_07_110744_create_campaigns_table',1),
(24,'2022_03_08_052530_create_banners_table',1),
(25,'2022_03_08_090735_create_transactions_table',1),
(26,'2022_03_10_074138_create_accounts_table',1),
(27,'2022_05_09_122054_add_variant_key_in_variation',2),
(28,'2022_05_12_100348_create_faqs_table',3),
(29,'2022_05_18_041330_discount_table_col_modify',4),
(30,'2022_05_21_035041_add_coupon_type',5),
(31,'2022_05_22_120123_add_banner_redirection_link',6),
(33,'2022_05_24_043332_remove_and_reformat_urder_table_col',8),
(34,'2022_03_07_064337_create_providers_table',9),
(35,'2022_05_25_054015_create_business_settings_table',10),
(36,'2022_06_05_061932_create_bookings_table',11),
(37,'2022_06_05_063828_create_booking_details_table',11),
(38,'2022_06_05_065027_create_booking_status_histories_table',11),
(39,'2022_06_05_065040_create_booking_schedule_histories_table',11),
(40,'2022_06_08_070555_add_status_col_toRole',12),
(41,'2022_06_11_074614_category_sub_added_booking',13),
(42,'2022_06_11_110610_create_user_zones_table',13),
(43,'2022_06_12_034552_create_user_addresses_table',13),
(44,'2022_06_13_120346_add_column_is_approved_to_provider_table',14),
(45,'2022_06_14_104816_create_bank_details_table',15),
(46,'2022_06_15_025832_role_table_customization',16),
(47,'2022_06_15_043227_create_subscribed_services_table',16),
(48,'2022_06_16_060054_tnx_add',17),
(49,'2022_06_16_060137_acc_add',18),
(51,'2022_06_18_052537_create_reviews_table',19),
(52,'2022_06_18_095222_create_withdraw_requests_table',20),
(53,'2022_06_16_094936_create_servicemen_table',21),
(54,'2022_06_19_063119_add_serviceman_col',22),
(55,'2022_06_20_085647_add_col_to_serviceman',23),
(56,'2022_06_22_082434_create_carts_table',24),
(57,'2022_06_22_121556_create_cart_service_infos_table',24),
(58,'2022_06_22_090257_column_add_to_withdraw_request_table',25),
(59,'2022_07_03_065118_add_zone_id_in_providers',26),
(61,'2022_07_17_064031_add_addres_type',27),
(62,'2022_07_17_071324_add_addres_type1',27),
(63,'2022_07_19_040550_change-col-name',28),
(64,'2022_07_03_095424_create_push_notifications_table',29),
(65,'2022_07_21_050907_pass_reset_table_col_add',30),
(66,'2022_07_21_054008_pass_reset_table_col_add1',30),
(67,'2022_07_21_104205_add_booking_id_col',31),
(68,'2022_07_24_051517_add_cus_col_in_review',32),
(69,'2022_07_31_093836_create_channel_lists_table',33),
(70,'2022_07_31_093916_create_channel_users_table',33),
(71,'2022_07_31_094036_create_channel_conversations_table',33),
(72,'2022_07_31_104246_create_conversation_files_table',33),
(73,'2022_07_31_113436_add_new_col_campaign',33),
(74,'2022_08_02_054322_update_col_type',34),
(75,'2022_08_06_031433_add_col_in_booking_table',35),
(76,'2022_08_06_031649_add_col_in_booking_details_table',35),
(77,'2022_08_06_045001_remove_col_from_user',36),
(78,'2022_08_21_031258_add_col_to_channel_list',37),
(79,'2022_08_21_033729_add_col_to_channel_user_table',37),
(80,'2022_08_23_060744_col_add_to_tnx_table',38),
(81,'2022_08_28_044249_col_change_to_business_settings_table',39),
(82,'2022_08_31_070329_col_add_to_booking_details_table',40),
(83,'2022_09_01_135800_create_user_verifications_table',41),
(84,'2022_09_12_062925_col_add_to_booking_table',42),
(85,'2022_09_17_185044_add_col_to_bank_destails',43),
(86,'2022_09_21_235326_col_add_to_withdraw_requests_table',44),
(87,'2022_10_03_175305_add_zone_id_in_address',44),
(88,'2022_11_21_175412_add_col_to_withdraw_requests_table',45),
(89,'2022_11_21_230747_create_withdrawal_methods_table',45),
(90,'2022_11_29_232809_create_booking_details_amounts_table',45),
(91,'2022_12_05_184417_col_add_to_services_table',45),
(92,'2022_12_06_002432_create_recent_views_table',45),
(93,'2022_12_08_201359_create_recent_searches_table',45),
(94,'2022_12_26_115139_add_col_to_accounts_table',45),
(95,'2023_01_16_152849_add_col_to_booking_details_amounts_table',45),
(96,'2023_01_24_230519_add_col_to_users_table',46),
(97,'2023_01_25_195038_add_col_to_transactions_table',46),
(98,'2023_01_26_174101_Create_loyalty_point_transactions_table',46),
(99,'2023_01_27_001826_add_col_to_categories_table',46),
(100,'2023_01_29_011739_create_tags_table',46),
(101,'2023_01_29_162753_create_table_service_tag',46),
(102,'2023_02_02_231012_create_service_requests_table',46),
(103,'2023_02_05_200352_create_added_to_carts_table',46),
(104,'2023_02_05_214409_create_visited_services_table',46),
(105,'2023_02_05_225314_create_searched_data_table',46),
(106,'2023_02_08_174014_add_provider_id_to_carts_table',46),
(107,'2023_04_29_185100_create_posts_table',47),
(108,'2023_04_29_185107_create_post_additional_instructions_table',47),
(109,'2023_04_29_185114_create_post_bids_table',47),
(110,'2023_04_29_185127_create_ignored_posts_table',47),
(111,'2023_05_08_161525_add_col_to_services_table',47),
(112,'2023_05_16_130004_add_col_to_providers_table',47),
(113,'2023_05_16_231127_create_coupon_customers_table',47),
(115,'2023_05_21_095745_add_col_to_users_table',47),
(116,'2023_05_21_101102_add_col_to_user_verifications_table',47),
(117,'2023_05_29_184809_add_col_to_posts_table',48),
(118,'2023_05_30_102205_add_additional_charge_col_to_bookings_table',48),
(119,'2023_05_31_103005_add_col_to_bookings_table',49),
(120,'2023_05_17_144146_add_col_to_posts_table',50),
(121,'2023_06_11_221500_add_removed_coupon_amount_col_in_booking_table',51),
(122,'2023_06_26_154947_add_column_to_bookings_table',51),
(123,'2023_07_12_105915_add_is_guest_column_to_carts_table',51),
(124,'2023_07_12_105941_add_is_guest_column_to_added_to_carts_table',51),
(125,'2023_07_12_110032_add_is_guest_column_to_bookings_table',51),
(126,'2023_07_13_094305_add_is_guest_column_to_transactions_table',51),
(127,'2023_07_13_094337_add_is_guest_column_to_booking_schedule_histories_table',51),
(128,'2023_07_13_094413_add_is_guest_column_to_booking_status_histories_table',51),
(129,'2023_07_13_105419_create_guests_table',51),
(130,'2023_07_13_180332_add_is_guest_column_to_added_to_user_addresses_table',51),
(131,'2023_07_17_142048_add_is_verified_col_to_bookings_table',51),
(132,'2023_07_17_184044_add_is_guest_col_to_posts_table',51),
(133,'2023_07_19_111811_add_house_and_street_col_in_user_addresses_table',51),
(134,'2023_07_29_133252_create_booking_partial_payments_table',51),
(135,'2023_08_06_152659_create_offline_payments_table',51),
(136,'2023_08_07_153312_create_booking_offline_payments_table',51),
(137,'2023_08_08_094402_create_bonuses_table',51),
(138,'2023_08_10_182955_add_fee_column_to_bookings_table',51),
(139,'2023_08_24_132317_create_provider_settings_table',51),
(140,'2023_10_31_171211_create_translations_table',52),
(141,'2023_11_07_182712_create_landing_page_features_table',52),
(142,'2023_11_08_092558_create_landing_page_specialities_table',52),
(143,'2023_11_08_094847_create_landing_page_testimonials_table',52),
(144,'2023_11_08_174249_add_current_language_to_users_table',52),
(145,'2023_11_08_174418_add_current_language_to_guests_table',52),
(146,'2023_11_16_110101_create_data_settings_table',52),
(147,'2023_11_19_112426_add_is_suspended_col_to_providers_table',52),
(148,'2023_11_19_155434_add_soft_deletes_to_providers_table',52),
(149,'2023_12_20_135725_add_service_availability_to_providers_table',53),
(150,'2024_01_28_080833_create_booking_additional_information_table',54),
(151,'2024_01_29_115651_create_post_additional_information_table',54),
(152,'2024_02_10_183058_rename_file_name_col_to_conversation_files_table',54),
(153,'2024_02_10_184243_add_original_file_name_col_to_conversation_files_table',54),
(154,'2024_02_15_143856_make_col_nullable_to_service_requests_table',54),
(155,'2024_02_29_140738_add_col_to_booking_offline_payments_table',54),
(156,'2024_03_20_053908_create_favorite_providers_table',55),
(157,'2024_03_20_134756_create_favorite_services_table',55),
(158,'2024_03_27_102042_add_total_referral_discount_amount_to_bookings_table',55),
(159,'2024_04_02_102509_create_push_notification_users_table',55),
(160,'2024_04_22_132349_create_advertisements_table',55),
(161,'2024_04_22_134754_create_advertisement_attachments_table',55),
(162,'2024_04_22_181536_create_advertisement_notes_table',55),
(163,'2024_04_25_160923_create_advertisement_settings_table',55),
(164,'2024_04_29_133239_create_role_accesses_table',55),
(165,'2024_04_29_135809_create_role_sections_table',55),
(166,'2024_05_02_114745_create_employee_role_sections_table',55),
(167,'2024_05_02_114900_create_employee_role_accesses_table',55),
(168,'2024_05_09_141125_drop_col_form_roles_tabel',55),
(169,'2024_05_09_142158_drop_col_form_employee_role_section_tabel',55),
(170,'2024_05_09_142555_drop_role_modules_tabel',55),
(171,'2024_05_09_142749_drop_user_roles_tabel',55),
(172,'2024_05_09_143102_drop_role_section_tabel',55),
(173,'2024_05_13_112445_add_is_updated_to_advertisements_table',55),
(174,'2024_05_13_155906_add_to_col_role_accesses_tabel',55),
(175,'2024_05_13_162125_add_to_col_employee_role_accesses_tabel',55),
(176,'2024_05_21_105847_create_subscription_packages_table',56),
(177,'2024_05_21_105930_create_subscription_package_features_table',56),
(178,'2024_05_21_105958_create_subscription_package_limits_table',56),
(179,'2024_05_22_152625_create_storages_table',56),
(180,'2024_05_26_100825_create_package_subscribers_table',56),
(181,'2024_05_26_100851_create_package_subscriber_features_table',56),
(182,'2024_05_26_100918_create_package_subscriber_limits_table',56),
(183,'2024_05_28_170817_create_package_subscriber_logs_table',56),
(184,'2024_06_02_173558_add_to_col_package_subscriber_table',56),
(185,'2024_06_04_142029_rename_col_package_subscriber_features_tabel',56),
(186,'2024_06_06_160149_add_to_col_transaction_id_to_package_subscriber_logs_tabel',56),
(187,'2024_06_11_115322_add_to_col_package_subscription_tabel',56),
(188,'2024_06_12_152132_add_is_notified_in_package_subscribers',56),
(189,'2024_06_25_113732_create_subscription_booking_types_table',56),
(190,'2024_07_11_130225_create_subscription_subscriber_bookings_table',57),
(191,'2024_08_01_085757_create_login_setups_table',58),
(192,'2024_08_04_171331_create_notification_setups_table',58),
(193,'2024_08_06_204700_create_provider_notification_setups_table',58),
(194,'2024_09_02_131527_create_review_replies_table',59),
(195,'2024_09_02_132320_add_to_col_readable_id_in_review_table',59),
(196,'2024_09_05_173819_create_seo_settings_table',59),
(197,'2024_09_07_132218_create_error_logs_table',59),
(198,'2024_09_21_145743_create_cron_jobs_table',59),
(199,'2024_09_25_133132_add_to_col_cron_jobs_table',59);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` char(36) NOT NULL,
  `module_name` varchar(191) DEFAULT NULL,
  `module_display_name` varchar(191) DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_setups`
--

DROP TABLE IF EXISTS `notification_setups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_setups` (
  `id` char(36) NOT NULL,
  `user_type` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_setups`
--

LOCK TABLES `notification_setups` WRITE;
/*!40000 ALTER TABLE `notification_setups` DISABLE KEYS */;
INSERT INTO `notification_setups` VALUES
('10b69552-ad4f-45ed-9b90-5cf6a4faa567','provider','Terms & Conditions','Choose how the provider will get notified of Terms & Conditions Update by the admin','terms_&_conditions_update','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('13af7141-50e0-49f7-9f5d-4817868f7b74','provider','Verification','Choose how the provider will get notified of Email/Phone Verification and password recovery OTP sent via Email/Phone','verification','{\"email\":1,\"notification\":null,\"sms\":1}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('2a3c95eb-7a13-4a8a-8557-1a57b3e678c0','user','Refer & earn','Choose how the customer will get notified of refer code use, first booking completion, and get cashback as a reward','refer_earn','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('32aa144f-0d86-43c8-93d4-8c649ef0ae30','provider','System Update','Choose how the provider will get notified of System Updates by the admin','system_update','{\"email\":1,\"notification\":null,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('3b56cfeb-7e9b-454f-8fad-813fb255b6d7','provider','Transaction','Choose how the provider will get notified of suspend on exceeding cash in hand balance','transaction','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('3c1757b1-21fd-42ab-9371-71a9ed4c27a6','user','Verification','Choose how the customer will get notified of Email/Phone Verification and password recovery OTP sent via Email/Phone','verification','{\"email\":1,\"notification\":null,\"sms\":1}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('525804e0-4985-4ff5-8d14-dc12c72636c5','user','Privacy policy update','Choose how the customer will get notified of Privacy policy updates by the admin','privacy_policy_update','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('55e98f67-b05c-4419-9ba7-fd2451b346cb','user','Loyalty point','Choose how the customer will get notified of earning loyalty points as a reward','loyality_point','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('57afaffe-b68d-48ed-9494-a7af0000620c','provider','Booking','Choose how the providers will get notified of new bookings, Booking Edits, Booking Status updates, Schedule time changes, and withdrawal request','booking','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('59c019e4-1f65-42e3-a1ec-ff1b0e7ae408','user','Wallet','Choose how the customer will get notified of getting a bonus & Wallet balance from admin or add funds by himself','wallet','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('628c0ac6-9339-48de-8ea7-03ee57333fca','serviceman','Booking','Choose how the serviceman will get notified of new booking assign, Booking Edits, Booking Status updates, Schedule time changes','booking','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('64b779e6-835d-429c-9ad3-854e5b504385','user','Chatting','Choose how the customer will get notified of message reply, attachment received','chatting','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('69545df6-cf1a-4021-84b3-be6ed84bd294','provider','Registration','Choose how the provider will get notified of new registration approval or deny','registration','{\"email\":1,\"notification\":null,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('8754b5d8-00a7-4926-bf4e-c993c84162ce','user','Terms & Conditions','Choose how the customer will get notified of Terms & Conditions Update by the admin','terms_&_conditions_update','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('8dd14f5b-331a-4b84-8721-f3d26e8d7c18','provider','Subscription','Choose how the provider will get notified of the Subscription plan subscribe, shifted, renewed, canceled & updated.','subscription','{\"email\":1,\"notification\":null,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('8fe761a7-7201-4942-9bf5-2797f22e37d2','user','Registration','Choose how the customer will get notified when the admin registers the customer to the system','registration','{\"email\":1,\"notification\":null,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('9090438b-a017-4175-a97a-cc969c8c4f27','provider','Chatting','Choose how the provider will get notified of message reply, attachment received','chatting','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('9a074e1a-e3b3-4b8f-b7c4-2cc142e66170','serviceman','Verification','Choose how the serviceman will get notified of password recovery OTP sent via Email/Phone','verification','{\"email\":1,\"notification\":null,\"sms\":1}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('a094b687-cafb-47d2-855e-8ec70f87aa67','provider','Advertisement','Choose how the provider will get notified of advertisement requests accept, deny, run ads, expire ads, etc.','advertisement','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('b01ecf87-2912-4227-90c5-9a99c4f632db','serviceman','Privacy policy update','Choose how the serviceman  will get notified of Privacy policy updates by the admin','privacy_policy_update','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('d9e4cc60-afe8-4160-b536-9eecda300b92','serviceman','Terms & Conditions Update','Choose how the serviceman will get notified of Terms & Conditions Update by the admin','terms_&_conditions_update','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('ed11392c-cbba-468e-aeec-a6fdc28f1f5c','provider','Privacy policy update','Choose how the provider will get notified of Privacy policy updates by the admin','privacy_policy_update','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('edaadfd7-864e-4070-a71f-527f676df127','serviceman','Chatting','Choose how the serviceman will get notified of message reply, attachment received','chatting','{\"email\":null,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01'),
('f2e260a1-325b-4471-af26-cdc7cb43f899','user','Booking','Choose how the customer will get notified of all the bookings they placed in the system','booking','{\"email\":1,\"notification\":1,\"sms\":null}','2024-08-25 14:24:01','2024-08-25 14:24:01');
/*!40000 ALTER TABLE `notification_setups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `client_id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
INSERT INTO `oauth_access_tokens` VALUES
('12eb65ed95a8c880ca7ca3252690addca0e6ed79e0071ea738061c2257e5d848f8abb994c73c103b','ba1b42a7-d2e6-4a62-84d6-2f804341664b','95faaac6-c1d2-4d4c-beb1-04196dd2fa8e','AccessToCustomer','[]',0,'2024-12-12 16:17:21','2024-12-12 16:17:21','2025-12-12 16:17:21'),
('333d2b3e6d466bafa56771760d4929a5176f840d161a54057fc416ab142300d5de3a8e51adc7dfc1','8bd675db-2e78-46e9-8b1c-516f0728c2e8','95faaac6-c1d2-4d4c-beb1-04196dd2fa8e','AccessToCustomer','[]',0,'2024-12-09 13:17:58','2024-12-09 13:17:58','2025-12-09 13:17:58'),
('592a585883a98b7f90926d2fb6994e5e89a42dcd8a86e6ca5ab1f940bdcd82919e04d7787e6f20f2','813240f0-88a5-4d07-93ca-ad6592204768','95faaac6-c1d2-4d4c-beb1-04196dd2fa8e','AccessToCustomer','[]',0,'2024-12-26 19:06:38','2024-12-26 19:06:38','2025-12-26 19:06:38'),
('623128dbead572898bf1d69dbacf22f06959010c791f03ec5cdb1f0965cf1f3881c468b8a166804e','c40a44fe-7292-4620-822f-7ee5b69b78a9','95faaac6-c1d2-4d4c-beb1-04196dd2fa8e','AccessToCustomer','[]',0,'2024-12-10 17:17:38','2024-12-10 17:17:38','2025-12-10 17:17:38'),
('846b079d5d28ce0ca82f0d4cbdac281fd7c1c86e99fc79b0f94b9307cd6aafa08a8908b0dffc7d5f','b511c056-1b6f-447c-89e0-13a49eb7adcd','95faaac6-c1d2-4d4c-beb1-04196dd2fa8e','AccessToCustomer','[]',0,'2024-12-08 01:08:08','2024-12-08 01:08:08','2025-12-08 01:08:08'),
('d2f0d3161d694d767ffe1ce54ca165aa7f19d7311875aa3633935b9d5281e53092e8eb2b3987713f','b4e84651-b572-4a42-96c7-7d1a0cf89918','95faaac6-c1d2-4d4c-beb1-04196dd2fa8e','AccessToCustomer','[]',0,'2025-01-02 16:02:58','2025-01-02 16:02:58','2026-01-02 16:02:58'),
('fc096d6335b5444bf68bbb5b0856c5600a245d130a202f0bd7bc190a17f471bf4b4f56ff33b08bdd','70d1a7c8-14f0-486f-b4d3-26e8f2fadd7d','95faaac6-c1d2-4d4c-beb1-04196dd2fa8e','AccessToCustomer','[]',0,'2024-12-18 14:09:19','2024-12-18 14:09:19','2025-12-18 14:09:19');
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` char(36) NOT NULL,
  `client_id` char(36) NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` char(36) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES
('95faaac6-c1d2-4d4c-beb1-04196dd2fa8e',NULL,'Laravel Personal Access Client','75kQskqekdipFpesfWZZv85qPo2cT8aMsyWgsIrQ',NULL,'http://localhost',1,0,0,'2022-04-04 02:13:15','2022-04-04 02:13:15'),
('95faaac6-c56a-4873-a880-79d252d65ab1',NULL,'Laravel Password Grant Client','hnFqAvObupsF3BXW4T6MxD4IhvKCZPRzyIqEFciB','users','http://localhost',0,1,0,'2022-04-04 02:13:15','2022-04-04 02:13:15');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES
(1,'95faaac6-c1d2-4d4c-beb1-04196dd2fa8e','2022-04-04 02:13:15','2022-04-04 02:13:15');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_payments`
--

DROP TABLE IF EXISTS `offline_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_payments` (
  `id` char(36) NOT NULL,
  `method_name` varchar(255) NOT NULL,
  `payment_information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `customer_information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_payments`
--

LOCK TABLES `offline_payments` WRITE;
/*!40000 ALTER TABLE `offline_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `offline_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_subscriber_features`
--

DROP TABLE IF EXISTS `package_subscriber_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_subscriber_features` (
  `id` char(36) NOT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `package_subscriber_log_id` char(36) DEFAULT NULL,
  `feature` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_subscriber_features`
--

LOCK TABLES `package_subscriber_features` WRITE;
/*!40000 ALTER TABLE `package_subscriber_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_subscriber_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_subscriber_limits`
--

DROP TABLE IF EXISTS `package_subscriber_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_subscriber_limits` (
  `id` char(36) NOT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `subscription_package_id` char(36) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `is_limited` tinyint(1) NOT NULL DEFAULT 1,
  `limit_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_subscriber_limits`
--

LOCK TABLES `package_subscriber_limits` WRITE;
/*!40000 ALTER TABLE `package_subscriber_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_subscriber_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_subscriber_logs`
--

DROP TABLE IF EXISTS `package_subscriber_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_subscriber_logs` (
  `id` char(36) NOT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `subscription_package_id` char(36) DEFAULT NULL,
  `package_name` varchar(255) DEFAULT NULL,
  `package_price` decimal(24,2) NOT NULL DEFAULT 0.00,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `vat_percentage` double(8,2) NOT NULL DEFAULT 0.00,
  `vat_amount` double(8,2) NOT NULL DEFAULT 0.00,
  `payment_id` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `primary_transaction_id` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_subscriber_logs`
--

LOCK TABLES `package_subscriber_logs` WRITE;
/*!40000 ALTER TABLE `package_subscriber_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_subscriber_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_subscribers`
--

DROP TABLE IF EXISTS `package_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_subscribers` (
  `id` char(36) NOT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `subscription_package_id` char(36) DEFAULT NULL,
  `package_subscriber_log_id` char(36) DEFAULT NULL,
  `package_name` varchar(255) DEFAULT NULL,
  `package_price` decimal(24,2) NOT NULL DEFAULT 0.00,
  `package_start_date` timestamp NULL DEFAULT NULL,
  `package_end_date` timestamp NULL DEFAULT NULL,
  `trial_duration` int(11) NOT NULL DEFAULT 0,
  `vat_percentage` double(8,2) NOT NULL DEFAULT 0.00,
  `vat_amount` double(8,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_canceled` tinyint(4) NOT NULL DEFAULT 0,
  `payment_id` char(36) DEFAULT NULL,
  `is_notified` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_subscribers`
--

LOCK TABLES `package_subscribers` WRITE;
/*!40000 ALTER TABLE `package_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) DEFAULT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_requests`
--

DROP TABLE IF EXISTS `payment_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_requests` (
  `id` char(36) NOT NULL,
  `payer_id` varchar(64) DEFAULT NULL,
  `receiver_id` varchar(64) DEFAULT NULL,
  `payment_amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `gateway_callback_url` varchar(191) DEFAULT NULL,
  `success_hook` varchar(100) DEFAULT NULL,
  `failure_hook` varchar(100) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `currency_code` varchar(20) NOT NULL DEFAULT 'USD',
  `payment_method` varchar(50) DEFAULT NULL,
  `additional_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `payer_information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `external_redirect_link` varchar(255) DEFAULT NULL,
  `receiver_information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `attribute_id` varchar(64) DEFAULT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `payment_platform` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_requests`
--

LOCK TABLES `payment_requests` WRITE;
/*!40000 ALTER TABLE `payment_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_additional_information`
--

DROP TABLE IF EXISTS `post_additional_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_additional_information` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` char(36) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_additional_information`
--

LOCK TABLES `post_additional_information` WRITE;
/*!40000 ALTER TABLE `post_additional_information` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_additional_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_additional_instructions`
--

DROP TABLE IF EXISTS `post_additional_instructions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_additional_instructions` (
  `id` char(36) NOT NULL,
  `details` text DEFAULT NULL,
  `post_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_additional_instructions`
--

LOCK TABLES `post_additional_instructions` WRITE;
/*!40000 ALTER TABLE `post_additional_instructions` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_additional_instructions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_bids`
--

DROP TABLE IF EXISTS `post_bids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_bids` (
  `id` char(36) NOT NULL,
  `offered_price` decimal(24,2) NOT NULL DEFAULT 0.00,
  `provider_note` text DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `post_id` char(36) NOT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_bids`
--

LOCK TABLES `post_bids` WRITE;
/*!40000 ALTER TABLE `post_bids` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_bids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` char(36) NOT NULL,
  `service_description` text DEFAULT NULL,
  `booking_schedule` datetime DEFAULT NULL,
  `is_booked` tinyint(1) NOT NULL DEFAULT 0,
  `is_checked` tinyint(1) NOT NULL DEFAULT 0,
  `customer_user_id` char(36) NOT NULL,
  `service_id` char(36) DEFAULT NULL,
  `category_id` char(36) DEFAULT NULL,
  `sub_category_id` char(36) DEFAULT NULL,
  `service_address_id` char(36) DEFAULT NULL,
  `zone_id` char(36) DEFAULT NULL,
  `booking_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_notification_setups`
--

DROP TABLE IF EXISTS `provider_notification_setups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_notification_setups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` char(36) DEFAULT NULL,
  `notification_setup_id` char(36) DEFAULT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_notification_setups`
--

LOCK TABLES `provider_notification_setups` WRITE;
/*!40000 ALTER TABLE `provider_notification_setups` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_notification_setups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_settings`
--

DROP TABLE IF EXISTS `provider_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_settings` (
  `id` char(36) NOT NULL,
  `provider_id` char(36) NOT NULL,
  `key_name` varchar(191) DEFAULT NULL,
  `live_values` longtext DEFAULT NULL,
  `test_values` longtext DEFAULT NULL,
  `settings_type` varchar(255) DEFAULT NULL,
  `mode` varchar(20) NOT NULL DEFAULT 'live',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_settings`
--

LOCK TABLES `provider_settings` WRITE;
/*!40000 ALTER TABLE `provider_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_sub_category`
--

DROP TABLE IF EXISTS `provider_sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_sub_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` char(36) NOT NULL,
  `sub_category_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_sub_category`
--

LOCK TABLES `provider_sub_category` WRITE;
/*!40000 ALTER TABLE `provider_sub_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_sub_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` char(36) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `company_name` varchar(191) DEFAULT NULL,
  `company_phone` varchar(25) DEFAULT NULL,
  `company_address` varchar(191) DEFAULT NULL,
  `company_email` varchar(191) DEFAULT NULL,
  `logo` varchar(191) DEFAULT NULL,
  `contact_person_name` varchar(191) DEFAULT NULL,
  `contact_person_phone` varchar(25) DEFAULT NULL,
  `contact_person_email` varchar(191) DEFAULT NULL,
  `order_count` int(10) unsigned NOT NULL DEFAULT 0,
  `service_man_count` int(10) unsigned NOT NULL DEFAULT 0,
  `service_capacity_per_day` int(10) unsigned NOT NULL DEFAULT 0,
  `rating_count` int(10) unsigned NOT NULL DEFAULT 0,
  `avg_rating` double(8,4) NOT NULL DEFAULT 0.0000,
  `commission_status` tinyint(1) NOT NULL DEFAULT 0,
  `commission_percentage` double(8,4) NOT NULL DEFAULT 0.0000,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `zone_id` char(36) DEFAULT NULL,
  `coordinates` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `service_availability` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES
('4ed13cd8-5dca-44db-b2e6-6fcaadba9d62','27dfaf27-c88f-4c34-82f6-6b27e3436873','Test by Leo Koesters','+4915123158983','Franz-Liszt-Straße 9','leo.koesters@yahoo.com','2024-12-08-6755f380db5f7.png','Leo Koesters','+4915123158983','leo.koesters@yahoo.com',0,0,0,0,0.0000,0,0.0000,1,'2024-12-08 20:29:04','2024-12-08 20:34:58',1,'a1614dbe-4732-11ee-9702-dee6e8d77be4','{\"latitude\":\"23.80513499255771\",\"longitude\":\"90.36070836511229\"}',0,NULL,1),
('75643e0d-0be5-4e50-b55f-be171e6f6d3a','38796f59-825e-4f25-ac9f-ddfc61effa61','Leo Koesters','+4915123158983','Franz-Liszt-Straße 9','leo.koesters@yahoo.com','2024-12-08-6755def8073de.png','Leo Koesters','+4915123158983','leo.koesters@yahoo.com',0,0,0,0,0.0000,0,0.0000,1,'2024-12-08 19:01:28','2024-12-08 19:16:36',1,'a1614dbe-4732-11ee-9702-dee6e8d77be4','{\"latitude\":\"23.820994329717895\",\"longitude\":\"90.38654340234373\"}',0,'2024-12-08 19:16:36',1),
('a79734ea-28bf-4bec-8dcf-ed0913221b1f','ee31292a-0476-4374-a840-ed7ed8bc48c5','Beyond-You.net','+494564563456342','Franz-Liszt-Straße 9','chi_x007@icloud.com','2024-12-03-674efbe0eb13a.png','Leonard Kösters','+493452345324','chi_x007@icloud.com',0,0,0,0,0.0000,0,0.0000,1,'2024-12-03 13:38:57','2024-12-03 13:40:04',1,'5a596937-448f-412c-87bc-f9a26655a46e','{\"latitude\":\"50.93505919773536\",\"longitude\":\"6.951280494532535\"}',0,NULL,1);
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notification_users`
--

DROP TABLE IF EXISTS `push_notification_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_notification_users` (
  `id` char(36) NOT NULL,
  `push_notification_id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notification_users`
--

LOCK TABLES `push_notification_users` WRITE;
/*!40000 ALTER TABLE `push_notification_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_notification_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notifications`
--

DROP TABLE IF EXISTS `push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_notifications` (
  `id` char(36) NOT NULL,
  `title` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `zone_ids` text NOT NULL,
  `to_users` varchar(255) NOT NULL DEFAULT '["customer"]',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notifications`
--

LOCK TABLES `push_notifications` WRITE;
/*!40000 ALTER TABLE `push_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recent_searches`
--

DROP TABLE IF EXISTS `recent_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recent_searches` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recent_searches`
--

LOCK TABLES `recent_searches` WRITE;
/*!40000 ALTER TABLE `recent_searches` DISABLE KEYS */;
/*!40000 ALTER TABLE `recent_searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recent_views`
--

DROP TABLE IF EXISTS `recent_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recent_views` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `service_id` char(36) DEFAULT NULL,
  `total_service_view` int(11) NOT NULL DEFAULT 0,
  `category_id` char(36) DEFAULT NULL,
  `total_category_view` int(11) NOT NULL DEFAULT 0,
  `sub_category_id` char(36) DEFAULT NULL,
  `total_sub_category_view` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recent_views`
--

LOCK TABLES `recent_views` WRITE;
/*!40000 ALTER TABLE `recent_views` DISABLE KEYS */;
INSERT INTO `recent_views` VALUES
('23f5eadd-548a-4a60-a0ae-227498590d21','813240f0-88a5-4d07-93ca-ad6592204768','f4d44b69-9b28-4c3c-8956-1c223367dd3a',1,NULL,0,NULL,0,NULL,'2024-12-26 19:07:07','2024-12-26 19:07:07');
/*!40000 ALTER TABLE `recent_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_replies`
--

DROP TABLE IF EXISTS `review_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_replies` (
  `id` char(36) NOT NULL,
  `readable_id` bigint(20) DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `review_id` char(36) DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_replies`
--

LOCK TABLES `review_replies` WRITE;
/*!40000 ALTER TABLE `review_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` char(36) NOT NULL,
  `readable_id` bigint(20) NOT NULL,
  `booking_id` char(36) DEFAULT NULL,
  `service_id` char(36) DEFAULT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `review_rating` int(11) NOT NULL DEFAULT 1,
  `review_comment` text DEFAULT NULL,
  `review_images` text DEFAULT NULL,
  `booking_date` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `customer_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_accesses`
--

DROP TABLE IF EXISTS `role_accesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_accesses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` char(36) NOT NULL,
  `section_name` varchar(255) NOT NULL,
  `can_view` tinyint(4) NOT NULL DEFAULT 1,
  `can_add` tinyint(4) NOT NULL DEFAULT 0,
  `can_update` tinyint(4) NOT NULL DEFAULT 0,
  `can_delete` tinyint(4) NOT NULL DEFAULT 0,
  `can_export` tinyint(4) NOT NULL DEFAULT 0,
  `can_manage_status` tinyint(4) NOT NULL DEFAULT 0,
  `can_approve_or_deny` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `can_assign_serviceman` tinyint(4) NOT NULL DEFAULT 0,
  `can_give_feedback` tinyint(4) NOT NULL DEFAULT 0,
  `can_take_backup` tinyint(4) NOT NULL DEFAULT 0,
  `can_change_status` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_accesses`
--

LOCK TABLES `role_accesses` WRITE;
/*!40000 ALTER TABLE `role_accesses` DISABLE KEYS */;
INSERT INTO `role_accesses` VALUES
(1,'1a527bd2-d307-4d84-b36c-6aa72c406946','dashboard',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(2,'1a527bd2-d307-4d84-b36c-6aa72c406946','booking',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(3,'1a527bd2-d307-4d84-b36c-6aa72c406946','transaction',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(4,'1a527bd2-d307-4d84-b36c-6aa72c406946','addon',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(5,'1a527bd2-d307-4d84-b36c-6aa72c406946','discount',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(6,'1a527bd2-d307-4d84-b36c-6aa72c406946','coupon',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(7,'1a527bd2-d307-4d84-b36c-6aa72c406946','bonus',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(8,'1a527bd2-d307-4d84-b36c-6aa72c406946','campaign',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(9,'1a527bd2-d307-4d84-b36c-6aa72c406946','advertisement',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(10,'1a527bd2-d307-4d84-b36c-6aa72c406946','banner',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(11,'1a527bd2-d307-4d84-b36c-6aa72c406946','push_notification',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(12,'1a527bd2-d307-4d84-b36c-6aa72c406946','onboarding_request',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(13,'1a527bd2-d307-4d84-b36c-6aa72c406946','provider',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(14,'1a527bd2-d307-4d84-b36c-6aa72c406946','withdraw',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(15,'1a527bd2-d307-4d84-b36c-6aa72c406946','zone',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(16,'1a527bd2-d307-4d84-b36c-6aa72c406946','category',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(17,'1a527bd2-d307-4d84-b36c-6aa72c406946','service',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(18,'1a527bd2-d307-4d84-b36c-6aa72c406946','customer',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(19,'1a527bd2-d307-4d84-b36c-6aa72c406946','wallet',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(20,'1a527bd2-d307-4d84-b36c-6aa72c406946','point',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(21,'1a527bd2-d307-4d84-b36c-6aa72c406946','role',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(22,'1a527bd2-d307-4d84-b36c-6aa72c406946','employee',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(23,'1a527bd2-d307-4d84-b36c-6aa72c406946','report',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(24,'1a527bd2-d307-4d84-b36c-6aa72c406946','analytics',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(25,'1a527bd2-d307-4d84-b36c-6aa72c406946','business',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(26,'1a527bd2-d307-4d84-b36c-6aa72c406946','landing',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(27,'1a527bd2-d307-4d84-b36c-6aa72c406946','configuration',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(28,'1a527bd2-d307-4d84-b36c-6aa72c406946','page',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(29,'1a527bd2-d307-4d84-b36c-6aa72c406946','gallery',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(30,'1a527bd2-d307-4d84-b36c-6aa72c406946','backup',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(31,'1a527bd2-d307-4d84-b36c-6aa72c406946','subscription_package',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(32,'1a527bd2-d307-4d84-b36c-6aa72c406946','subscriber',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0),
(33,'1a527bd2-d307-4d84-b36c-6aa72c406946','subscription_settings',1,1,1,1,1,1,1,'2024-11-27 06:04:40','2024-11-27 06:04:40',1,1,1,0);
/*!40000 ALTER TABLE `role_accesses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` char(36) NOT NULL,
  `role_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
('1a527bd2-d307-4d84-b36c-6aa72c406946','Chief Executive Officer','2024-11-27 06:04:40','2024-11-27 06:04:40',1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searched_data`
--

DROP TABLE IF EXISTS `searched_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searched_data` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `zone_id` char(36) NOT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `attribute_id` char(36) DEFAULT NULL,
  `response_data_count` int(11) NOT NULL DEFAULT 0,
  `volume` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searched_data`
--

LOCK TABLES `searched_data` WRITE;
/*!40000 ALTER TABLE `searched_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `searched_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_settings`
--

DROP TABLE IF EXISTS `seo_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo_settings` (
  `id` char(36) NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `page_name` varchar(255) DEFAULT NULL,
  `page_url` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_image` varchar(255) DEFAULT NULL,
  `canonicals_url` varchar(255) DEFAULT NULL,
  `index` varchar(255) DEFAULT NULL,
  `no_follow` varchar(255) DEFAULT NULL,
  `no_image_index` varchar(255) DEFAULT NULL,
  `no_archive` varchar(255) DEFAULT NULL,
  `no_snippet` varchar(255) DEFAULT NULL,
  `max_snippet` varchar(255) DEFAULT NULL,
  `max_snippet_value` varchar(255) DEFAULT NULL,
  `max_video_preview` varchar(255) DEFAULT NULL,
  `max_video_preview_value` varchar(255) DEFAULT NULL,
  `max_image_preview` varchar(255) DEFAULT NULL,
  `max_image_preview_value` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_settings`
--

LOCK TABLES `seo_settings` WRITE;
/*!40000 ALTER TABLE `seo_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_requests`
--

DROP TABLE IF EXISTS `service_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_requests` (
  `id` char(36) NOT NULL,
  `category_id` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  `service_name` varchar(255) NOT NULL,
  `service_description` text NOT NULL,
  `status` varchar(20) NOT NULL COMMENT 'pending,accepted,denied',
  `admin_feedback` text DEFAULT NULL,
  `user_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_requests`
--

LOCK TABLES `service_requests` WRITE;
/*!40000 ALTER TABLE `service_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_tag`
--

DROP TABLE IF EXISTS `service_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_tag` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` char(36) NOT NULL,
  `tag_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_tag`
--

LOCK TABLES `service_tag` WRITE;
/*!40000 ALTER TABLE `service_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicemen`
--

DROP TABLE IF EXISTS `servicemen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicemen` (
  `id` char(36) NOT NULL,
  `provider_id` char(36) DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicemen`
--

LOCK TABLES `servicemen` WRITE;
/*!40000 ALTER TABLE `servicemen` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicemen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` char(36) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `cover_image` varchar(191) DEFAULT NULL,
  `thumbnail` varchar(191) DEFAULT NULL,
  `category_id` char(36) DEFAULT NULL,
  `sub_category_id` char(36) DEFAULT NULL,
  `tax` decimal(24,3) NOT NULL DEFAULT 0.000,
  `order_count` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `rating_count` int(10) unsigned NOT NULL DEFAULT 0,
  `avg_rating` double(8,4) NOT NULL DEFAULT 0.0000,
  `min_bidding_price` decimal(24,3) NOT NULL DEFAULT 0.000,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES
('f4d44b69-9b28-4c3c-8956-1c223367dd3a','CBT (Cognitive Behavior Therapy)d','Cognitive Behavioral Therapy (CBT) is a structured, goal-oriented form of psychotherapy that helps individuals identify and change negative thought patterns and behaviors to improve emotional well-being.','<p>Cognitive Behavioral Therapy (CBT) is a proven approach that helps you understand how your thoughts, feelings, and actions are connected. With CBT, you&rsquo;ll learn to identify unhelpful patterns and replace them with healthier ways of thinking and behaving. It&rsquo;s designed to help you feel better and gain practical tools to manage challenges in your daily life.</p>','2023-08-31-64ef3a3e696a2.png','2023-08-31-64ef3a3e6d6c0.png','5e5c0fdb-9ad7-4075-bcc1-d7523efde8c6','b4fcd6d4-ba80-4e20-9ee2-f07a8b1466c6',10.000,0,1,0,0.0000,25.000,NULL,'2023-08-30 19:46:54','2024-12-07 23:42:12');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storages`
--

DROP TABLE IF EXISTS `storages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storages` (
  `id` char(36) NOT NULL,
  `model` varchar(255) NOT NULL,
  `model_id` char(36) NOT NULL,
  `model_column` varchar(255) NOT NULL,
  `storage_type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `storages_model_id_index` (`model_id`),
  KEY `storages_model_column_index` (`model_column`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storages`
--

LOCK TABLES `storages` WRITE;
/*!40000 ALTER TABLE `storages` DISABLE KEYS */;
/*!40000 ALTER TABLE `storages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscribed_services`
--

DROP TABLE IF EXISTS `subscribed_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribed_services` (
  `id` char(36) NOT NULL,
  `provider_id` char(36) NOT NULL,
  `category_id` char(36) NOT NULL,
  `sub_category_id` char(36) NOT NULL,
  `is_subscribed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscribed_services`
--

LOCK TABLES `subscribed_services` WRITE;
/*!40000 ALTER TABLE `subscribed_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscribed_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_booking_types`
--

DROP TABLE IF EXISTS `subscription_booking_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_booking_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` char(36) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_booking_types`
--

LOCK TABLES `subscription_booking_types` WRITE;
/*!40000 ALTER TABLE `subscription_booking_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_booking_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_package_features`
--

DROP TABLE IF EXISTS `subscription_package_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_package_features` (
  `id` char(36) NOT NULL,
  `subscription_package_id` char(36) DEFAULT NULL,
  `feature` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_package_features`
--

LOCK TABLES `subscription_package_features` WRITE;
/*!40000 ALTER TABLE `subscription_package_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_package_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_package_limits`
--

DROP TABLE IF EXISTS `subscription_package_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_package_limits` (
  `id` char(36) NOT NULL,
  `subscription_package_id` char(36) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `is_limited` tinyint(1) NOT NULL DEFAULT 1,
  `limit_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_package_limits`
--

LOCK TABLES `subscription_package_limits` WRITE;
/*!40000 ALTER TABLE `subscription_package_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_package_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_packages`
--

DROP TABLE IF EXISTS `subscription_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_packages` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(24,2) NOT NULL DEFAULT 0.00,
  `duration` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_packages`
--

LOCK TABLES `subscription_packages` WRITE;
/*!40000 ALTER TABLE `subscription_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_subscriber_bookings`
--

DROP TABLE IF EXISTS `subscription_subscriber_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_subscriber_bookings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` char(36) DEFAULT NULL,
  `booking_id` char(36) DEFAULT NULL,
  `package_subscriber_log_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_subscriber_bookings`
--

LOCK TABLES `subscription_subscriber_bookings` WRITE;
/*!40000 ALTER TABLE `subscription_subscriber_bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_subscriber_bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tag` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` char(36) NOT NULL,
  `ref_trx_id` char(36) DEFAULT NULL,
  `booking_id` char(36) DEFAULT NULL,
  `trx_type` varchar(255) DEFAULT NULL,
  `debit` decimal(24,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(24,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(24,2) NOT NULL DEFAULT 0.00,
  `from_user_id` char(36) DEFAULT NULL,
  `to_user_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `from_user_account` varchar(255) DEFAULT NULL,
  `to_user_account` varchar(255) DEFAULT NULL,
  `reference_note` varchar(100) DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `translationable_type` varchar(255) NOT NULL,
  `translationable_id` char(36) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `translations_translationable_id_index` (`translationable_id`),
  KEY `translations_locale_index` (`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations`
--

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
INSERT INTO `translations` VALUES
(1,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','42a986a9-831b-4789-9ae4-26b8284a2017','en','top_title',NULL),
(2,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','f4df4ad8-96be-4f99-a14e-6dc7c82035f8','en','top_description',NULL),
(3,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','af772e44-2cea-4396-bb82-9dbc13eb8691','en','top_sub_title',NULL),
(4,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','f6516965-15da-4fd6-805d-7788c0121a5f','en','mid_title',NULL),
(5,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','f4e72cf5-7e3f-40e0-a7b0-1185c62a65fa','en','about_us_title',NULL),
(6,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','c60d816a-3100-4d3e-8aba-013a0ef13639','en','about_us_description',NULL),
(7,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','875a27cc-5456-4573-a4af-cdf9d2e15c16','en','registration_title',NULL),
(8,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','95b1d2d7-b656-4ea6-9347-79909a94e7dd','en','registration_description',NULL),
(9,'Modules\\BusinessSettingsModule\\Entities\\BusinessSettings','0689bba0-0de2-4820-902a-5b4840af7fe9','en','bottom_title',NULL),
(10,'Modules\\BusinessSettingsModule\\Entities\\DataSetting','7f249215-5ee0-4a39-872e-3b3bd2634278','en','about_us',NULL),
(11,'Modules\\BusinessSettingsModule\\Entities\\DataSetting','c1f90ba8-3432-4478-8f35-7c992fa10aaf','en','privacy_policy',NULL),
(12,'Modules\\CategoryManagement\\Entities\\Category','7e37386e-5374-4b89-a92b-4181fbead9f1','en','name','Meditation'),
(13,'Modules\\CategoryManagement\\Entities\\Category','3c699893-51e2-4a43-b5e3-6c1f26643f76','en','name','Yoga'),
(14,'Modules\\CategoryManagement\\Entities\\Category','b3be2897-7b5a-4197-8070-ac5faa88fef3','en','name','Coaching'),
(16,'Modules\\CategoryManagement\\Entities\\Category','5e5c0fdb-9ad7-4075-bcc1-d7523efde8c6','en','name','Psychotherapy'),
(17,'Modules\\ZoneManagement\\Entities\\Zone','5a596937-448f-412c-87bc-f9a26655a46e','en','zone_name','Cologne'),
(18,'Modules\\ServiceManagement\\Entities\\Service','f4d44b69-9b28-4c3c-8956-1c223367dd3a','en','name','CBT (Cognitive Behavior Therapy)d'),
(19,'Modules\\ServiceManagement\\Entities\\Service','f4d44b69-9b28-4c3c-8956-1c223367dd3a','en','short_description','This is a fake short description for the test service.'),
(20,'Modules\\ServiceManagement\\Entities\\Service','f4d44b69-9b28-4c3c-8956-1c223367dd3a','en','description','<p>Test description.</p>');
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_addresses`
--

DROP TABLE IF EXISTS `user_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT NULL,
  `lat` varchar(191) DEFAULT NULL,
  `lon` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `street` varchar(191) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `address_type` varchar(255) DEFAULT NULL,
  `contact_person_name` varchar(255) DEFAULT NULL,
  `contact_person_number` varchar(255) DEFAULT NULL,
  `address_label` varchar(255) DEFAULT NULL,
  `zone_id` char(36) DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  `house` varchar(255) DEFAULT NULL,
  `floor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_addresses`
--

LOCK TABLES `user_addresses` WRITE;
/*!40000 ALTER TABLE `user_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_verifications`
--

DROP TABLE IF EXISTS `user_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_verifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `identity` varchar(255) NOT NULL,
  `identity_type` varchar(255) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `otp` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `hit_count` tinyint(4) NOT NULL DEFAULT 0,
  `is_temp_blocked` tinyint(1) NOT NULL DEFAULT 0,
  `temp_block_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_verifications`
--

LOCK TABLES `user_verifications` WRITE;
/*!40000 ALTER TABLE `user_verifications` DISABLE KEYS */;
INSERT INTO `user_verifications` VALUES
(1,'leo.koesters@beyond-you.net','email',NULL,'808147','2024-12-21 04:58:08','2024-12-21 04:55:08','2024-11-28 22:49:19',0,0,NULL),
(2,'chi_x007@icloud.com','email',NULL,'988409','2024-12-03 13:43:21','2024-12-03 13:40:21','2024-12-03 13:40:21',0,0,NULL),
(3,'leo.koesters@yahoo.com','email',NULL,'596485','2024-12-16 21:58:05','2024-12-16 21:55:05','2024-12-08 19:07:39',0,0,NULL);
/*!40000 ALTER TABLE `user_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_zones`
--

DROP TABLE IF EXISTS `user_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_zones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT NULL,
  `zone_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_zones`
--

LOCK TABLES `user_zones` WRITE;
/*!40000 ALTER TABLE `user_zones` DISABLE KEYS */;
INSERT INTO `user_zones` VALUES
(1,'38796f59-825e-4f25-ac9f-ddfc61effa61','a1614dbe-4732-11ee-9702-dee6e8d77be4',NULL,NULL);
/*!40000 ALTER TABLE `user_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `identification_number` varchar(191) DEFAULT NULL,
  `identification_type` varchar(191) NOT NULL DEFAULT 'nid',
  `identification_image` varchar(255) NOT NULL DEFAULT '[]',
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(191) NOT NULL DEFAULT 'male',
  `profile_image` varchar(191) NOT NULL DEFAULT 'default.png',
  `fcm_token` varchar(191) DEFAULT NULL,
  `is_phone_verified` tinyint(1) NOT NULL DEFAULT 0,
  `is_email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `user_type` varchar(191) NOT NULL DEFAULT 'customer',
  `remember_token` varchar(100) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `wallet_balance` decimal(24,3) NOT NULL DEFAULT 0.000,
  `loyalty_point` decimal(24,3) NOT NULL DEFAULT 0.000,
  `ref_code` varchar(50) DEFAULT NULL,
  `referred_by` char(36) DEFAULT NULL,
  `login_hit_count` tinyint(4) NOT NULL DEFAULT 0,
  `is_temp_blocked` tinyint(1) NOT NULL DEFAULT 0,
  `temp_block_time` timestamp NULL DEFAULT NULL,
  `current_language_key` varchar(255) DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
('27dfaf27-c88f-4c34-82f6-6b27e3436873',NULL,NULL,'leo.koesters@yahoo.com','+4915123158983','xyz','passport','[{\"image\":\"2024-12-08-6755f380da937.png\",\"storage\":\"public\"}]',NULL,'male','default.png',NULL,0,0,NULL,NULL,'$2y$10$DjARKvjuH8PDWh2LcMtd8eOWGnM8JV4ec18MxmrwBU2NtSX2IqY8.',1,'provider-admin',NULL,NULL,'2024-12-08 20:29:04','2024-12-08 20:34:17',0.000,0.000,'UTXSOLWQVX',NULL,0,0,NULL,'en'),
('285b9aa7-a211-4887-b91e-346f0406259a','Leo','Koesters','leo.koesters@beyond-you.net','+4915142023402',NULL,'nid','[]',NULL,'male','2024-12-16-67609eab87a0a.png',NULL,0,0,NULL,NULL,'$2y$10$8b/xs1wQx.zRP.r6kmZejuiLmlDp3byfJCHt542LOfwWm6PnzBIi6',1,'customer',NULL,NULL,'2024-12-16 22:42:03','2024-12-21 04:55:06',0.000,0.000,'5J1BQJFGLV',NULL,4,0,NULL,'en'),
('32412c11-ca45-47e4-905d-27e05d69c1b5','Leo','Koesters','leo.koesters@beyond-you.net','+4915142023402',NULL,'nid','[]',NULL,'male','default.png',NULL,0,0,NULL,NULL,'$2y$10$X872LZ.q06FjbhUL0aMTG.q2IxXmRwutmZzZJj/7QMYdrF0/2Ojue',1,'customer',NULL,'2024-12-08 01:06:19','2024-11-24 18:44:03','2024-12-08 01:06:19',0.000,0.000,'OFPYIRDIOE',NULL,4,0,NULL,'en'),
('38796f59-825e-4f25-ac9f-ddfc61effa61',NULL,NULL,'leo.koesters@yahoo.com','+4915123158983','xyz','passport','[]',NULL,'male','default.png',NULL,0,0,NULL,NULL,'$2y$10$5F2xMUTJRZ1k6Ghp2oc.9uwz2/hJY8agDlR6sPl/fRfj3ql3p50OS',1,'provider-admin',NULL,'2024-12-08 19:16:36','2024-12-08 19:01:28','2024-12-08 19:16:36',0.000,0.000,'W04FFWSGL0',NULL,5,1,'2024-12-08 19:11:28','en'),
('70d1a7c8-14f0-486f-b4d3-26e8f2fadd7d','Florian','Uhlmann','ulliu3@hotmail.de','+4917644401267',NULL,'nid','[]',NULL,'male','default.png','erP3t6F66b1KGxR8X8t8nN:APA91bE2r6gkml24d8nBOBcZLmRYmNZY7A0Z_U8Nvj-izXy3g7acPtB_lOHgWvYEDWcU3Lf8Qc71fdYU0FEL9G9-r-g2rVrC-RelJFnkl0BJl_VEFCus7L4',1,0,NULL,NULL,'$2y$10$FUUtHrVXhCVilS46gUCfr.CPPbcUlBFJtyFzVieCTRCKVWcdygyye',1,'customer',NULL,NULL,'2024-12-18 14:08:49','2024-12-18 14:09:27',0.000,0.000,'SOL9FWSTG6',NULL,0,0,NULL,'en'),
('813240f0-88a5-4d07-93ca-ad6592204768','Lucas','Bertels','Bertels.lucas@gmail.com','+491734218130',NULL,'nid','[]',NULL,'male','default.png','cDOF_0bGR1G-r1dhBiz5Qd:APA91bHXVI2wgQHh8Ue3W2gtG9omgbv6p8eahdMeCeveotywdSxps5H9ZaN41YDtpWId39Bq8uDlmTa8ubeIA5p5Z_9i2Hd-SUqZrqTLULIMfUkfDo6slJo',1,0,NULL,NULL,'$2y$10$RcLcAg2Hyf0HuYw4vYnaZuITq/SW20/NZTU9rfR1WHYxpyrgpLjwu',1,'customer',NULL,NULL,'2024-12-26 19:05:55','2024-12-26 19:06:38',0.000,0.000,'1XFHNRI48F',NULL,0,0,NULL,'en'),
('85be7d65-be37-4565-96f8-bd74857b6cfe','Jephthah','Roberts','robotzsoftwares@gmail.com','15123158983',NULL,'nid','[]',NULL,'male','default.png',NULL,0,0,NULL,NULL,'$2y$10$c0Gj1fD8L3AOskkQA0TTiOROSMfqFgK4v9OGFuutFQCPtS04iSPSS',1,'super-admin',NULL,NULL,'2024-11-16 10:34:17','2024-11-16 10:34:17',0.000,0.000,'9AKDE5ZUDC',NULL,0,0,NULL,'en'),
('8bd675db-2e78-46e9-8b1c-516f0728c2e8','Jakob','Arsin','beyond-you.net@calibrium.xyz','+491638683062',NULL,'nid','[]',NULL,'male','default.png','@',1,0,NULL,NULL,'$2y$10$F4cCx1aFTjXOiwJ5zmFM0eHQ7olwJF8.MlCFwri5oOh9tNOU.aqT.',1,'customer',NULL,NULL,'2024-12-09 13:17:31','2024-12-09 13:18:07',0.000,0.000,'JGSINC3R4S',NULL,0,0,NULL,'en'),
('b4e84651-b572-4a42-96c7-7d1a0cf89918','Jana','Volter','j-volter@web.de','+4915121952171',NULL,'nid','[]',NULL,'male','default.png','@',1,0,NULL,NULL,'$2y$10$m8HMgV11OYzeNGDAmPoOaOrF.t6qhMSL3TtdqNtLcak7LveNptCI2',1,'customer',NULL,NULL,'2025-01-02 16:00:07','2025-01-02 16:02:59',0.000,0.000,'ZBOLFT5I7U',NULL,0,0,NULL,'en'),
('b511c056-1b6f-447c-89e0-13a49eb7adcd','Leo','Koesters','leo.koesters@beyond-you.net','+4915142023402',NULL,'nid','[]',NULL,'male','default.png','fjJm0_WPQv6uMu7-_jNDgH:APA91bFQs1vCu1f4ujgYbzBY9TM0ODgre5p4boug_GGKlx8kd9s2aHORTRPWmdMbxecGUSJ6h5bRfFyXBUu7vKgJu9UgZgXPYXtMoeOb56ea3HxpFXpPcAs',1,0,NULL,NULL,'$2y$10$pLyqZAleg8I/wxX9JfvOBu.Z4vJVqUNXTEf2B/PqGULtEGmi.o7pK',1,'customer',NULL,'2024-12-16 22:09:45','2024-12-08 01:07:38','2024-12-16 22:09:45',0.000,0.000,'MIOD79DHGT',NULL,0,0,NULL,'en'),
('ba1b42a7-d2e6-4a62-84d6-2f804341664b','Martin','Martin Schirmer','martinschirmer1@gmx.de','+4915731677658',NULL,'nid','[]',NULL,'male','default.png','e2K5HGwsxXALeS-9Q6jb6f:APA91bFRrjM3jojCfZ80TuGfFwzWQiguuDD3Narz3rOjADyWkHR-74nrDDMHc3ArF83hgJ-__enIekAQbm-Ep-3Vf8sbvA-9DMCZEq0gf6JkK_272RL0rvc',1,0,NULL,NULL,'$2y$10$b/bPN1I4SfeY96leZKXlYuQbMS53Qq0G81QfpaZeOUGppjL2dfAxi',1,'customer',NULL,NULL,'2024-12-12 16:17:04','2024-12-12 16:17:26',0.000,0.000,'1I5SBMGWEX',NULL,0,0,NULL,'en'),
('c40a44fe-7292-4620-822f-7ee5b69b78a9','Jendrik','Deile','jendrikderdeile@gmail.com','+491772257203',NULL,'nid','[]',NULL,'male','default.png','cRIIlmiLRh-MwHPDeVc8hN:APA91bEzntIAtIt5wPPYM5jftiivrLR4MDVVMYqHFGuvr-ZYf6fHE2z7LiymB36nvG5JoipYTCZFIRfPwIPzkWc2TBqDReepVCyzCblNI--yPUX8nMnnRWE',1,0,NULL,NULL,'$2y$10$JfCbE379CwoC12R2K6CdIeosh.uDJ38WH0gDbGg/7D7GgmTnlZHJW',1,'customer',NULL,NULL,'2024-12-10 17:17:18','2024-12-10 17:17:38',0.000,0.000,'JQGPWRUNAW',NULL,0,0,NULL,'en'),
('ee31292a-0476-4374-a840-ed7ed8bc48c5',NULL,NULL,'chi_x007@icloud.com','+494564563456342','L7461T2NH','passport','[{\"image\":\"2024-12-03-674efbe0e95e3.png\",\"storage\":\"public\"}]',NULL,'male','default.png',NULL,0,0,NULL,NULL,'$2y$10$9g1hdkLcMKM9XIGGWOCDceppb279GV5jzuZxbKyuQcGs9wmu2NYeC',1,'provider-admin',NULL,NULL,'2024-12-03 13:38:57','2024-12-03 13:40:04',0.000,0.000,'QIHGR66ALD',NULL,0,0,NULL,'en');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variations`
--

DROP TABLE IF EXISTS `variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `variant` varchar(191) DEFAULT NULL,
  `variant_key` varchar(191) NOT NULL,
  `service_id` char(36) NOT NULL,
  `zone_id` char(36) NOT NULL,
  `price` decimal(24,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variations`
--

LOCK TABLES `variations` WRITE;
/*!40000 ALTER TABLE `variations` DISABLE KEYS */;
INSERT INTO `variations` VALUES
(4,'Variant-1','Variant-1','f4d44b69-9b28-4c3c-8956-1c223367dd3a','5a596937-448f-412c-87bc-f9a26655a46e',0.000,'2024-12-07 23:42:12','2024-12-07 23:42:12'),
(5,'Variant-1','Variant-1','f4d44b69-9b28-4c3c-8956-1c223367dd3a','a1614dbe-4732-11ee-9702-dee6e8d77be4',100.000,'2024-12-07 23:42:12','2024-12-07 23:42:12');
/*!40000 ALTER TABLE `variations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visited_services`
--

DROP TABLE IF EXISTS `visited_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visited_services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) NOT NULL,
  `service_id` char(36) NOT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visited_services`
--

LOCK TABLES `visited_services` WRITE;
/*!40000 ALTER TABLE `visited_services` DISABLE KEYS */;
INSERT INTO `visited_services` VALUES
(1,'813240f0-88a5-4d07-93ca-ad6592204768','f4d44b69-9b28-4c3c-8956-1c223367dd3a',1,'2024-12-26 19:07:07','2024-12-26 19:07:07');
/*!40000 ALTER TABLE `visited_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_requests`
--

DROP TABLE IF EXISTS `withdraw_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraw_requests` (
  `id` char(36) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `request_updated_by` char(36) DEFAULT NULL,
  `amount` decimal(24,2) NOT NULL DEFAULT 0.00,
  `request_status` varchar(255) NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT 0,
  `note` varchar(255) DEFAULT NULL,
  `admin_note` varchar(255) DEFAULT NULL,
  `withdrawal_method_id` char(36) DEFAULT NULL,
  `withdrawal_method_fields` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_requests`
--

LOCK TABLES `withdraw_requests` WRITE;
/*!40000 ALTER TABLE `withdraw_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraw_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdrawal_methods`
--

DROP TABLE IF EXISTS `withdrawal_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdrawal_methods` (
  `id` char(36) NOT NULL,
  `method_name` varchar(255) NOT NULL,
  `method_fields` text NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdrawal_methods`
--

LOCK TABLES `withdrawal_methods` WRITE;
/*!40000 ALTER TABLE `withdrawal_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdrawal_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zones`
--

DROP TABLE IF EXISTS `zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zones` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `coordinates` polygon DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `zones_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zones`
--

LOCK TABLES `zones` WRITE;
/*!40000 ALTER TABLE `zones` DISABLE KEYS */;
INSERT INTO `zones` VALUES
('5a596937-448f-412c-87bc-f9a26655a46e','Cologne','\0\0\0\0\0\0\0\0\0\0\0\0\0����#�@4]	�plI@������@|�	��xI@���ћ�@.5�ˆI@�����\Z@^�_ﴂI@����#�@4]	�plI@',1,'2024-12-03 13:33:21','2024-12-03 13:33:21'),
('a1614dbe-4732-11ee-9702-dee6e8d77be4','All over the World','\0\0\0\0\0\0\0\0\0\0%\0\0\0�WyV�Ef�_�(G�Q@�WyV�e������P@�WyV\"we�T٥.Z�P@�WyV<e�Y��̈P@�WyV:_e�Ş��cP@�WyV\Z�e�����A\ZP@�WyVB�e�WT�+S>P@�WyV\nCf��0y��jP@�WyV�>f�k�`�d�P@\"���f@D���ߑP@\"����sf@ao��@P@\"����bf@\'��PZPO@�1S��5d@��c~NL@�1S�b�b@$?��K\Z��1S��f@���Q�NC��1S�-e@�	��G��1S�\"�a@n<q� CB�c��]@<�^s�@���L-�cF@ua&��q8�<��Z+4@���d��@�1�Y�1Q�H��xK�1�Y�z�R��}�4)�H�1�Y�z&Q�Ă\n3�1�Y麧S�+�H	-� ��Y�tY���YL6�2@�Y�:�^���ݝʦC@uάt�c�.��AM@uάt]�d��s�T�gP@uάt��d�����\r(Q@uάt��c��)�$T�Q@�Y�z�_�\\��sQ@1�Y�:�S����o��T@<��Z9@^�|��S@��L-�>M@)GGU��R@c��OZ@\nC�Y��R@�1S�b�a@R{���Q@�WyV�Ef�_�(G�Q@',1,'2023-08-30 12:41:41','2023-08-30 12:41:41');
/*!40000 ALTER TABLE `zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'admin_'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-11  9:17:54
